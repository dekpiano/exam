<?php

namespace App\Controllers;

use App\Models\SettingModel;
use App\Models\QuestionModel;
use App\Models\StudentModel;
use App\Models\ExamResultModel;
use App\Models\ErrorLogModel;
use CodeIgniter\API\ResponseTrait;

class AdminController extends BaseController
{
    use ResponseTrait;

    protected $session;

    public function __construct()
    {
        $this->session = \Config\Services::session();
        $this->checkDatabaseSchema();
    }

    private function checkDatabaseSchema()
    {
        try {
            $db = \Config\Database::connect();
            if (!$db->fieldExists('exam_round', 'exams')) {
                $db->query("ALTER TABLE exams ADD COLUMN exam_round VARCHAR(100) DEFAULT '1' COMMENT 'รอบการสอบปัจจุบัน' AFTER num_questions");
            }
            if (!$db->fieldExists('exam_round', 'exam_results')) {
                $db->query("ALTER TABLE exam_results ADD COLUMN exam_round VARCHAR(100) DEFAULT '1' COMMENT 'รอบการสอบที่บันทึกผล' AFTER attempt_number");
            }
            if (!$db->fieldExists('student_code', 'students')) {
                $db->query("ALTER TABLE students ADD COLUMN student_code VARCHAR(50) DEFAULT '' COMMENT 'เลขประจำตัวนักเรียน' AFTER name");
            }
            if (!$db->fieldExists('student_code', 'exam_results')) {
                $db->query("ALTER TABLE exam_results ADD COLUMN student_code VARCHAR(50) DEFAULT '' COMMENT 'เลขประจำตัวนักเรียน' AFTER name");
            }
            if (!$db->fieldExists('exam_duration', 'exams')) {
                $db->query("ALTER TABLE exams ADD COLUMN exam_duration INT DEFAULT 0 COMMENT 'เวลาทำข้อสอบทั้งหมด (นาที) 0 = ไม่จำกัด' AFTER time_limit_writing");
            }
            if (!$db->fieldExists('started_at', 'exams')) {
                $db->query("ALTER TABLE exams ADD COLUMN started_at DATETIME NULL COMMENT 'เวลาที่กดเริ่มการสอบ' AFTER exam_status");
            }
            if (!$db->fieldExists('join_policy', 'exams')) {
                $db->query("ALTER TABLE exams ADD COLUMN join_policy VARCHAR(100) DEFAULT 'anytime' COMMENT 'นโยบายการเข้าร่วมสอบ: anytime = เริ่มตอนไหนก็ได้, lobby_first = ต้องรอในห้องพักคอยก่อนเริ่ม' AFTER exam_duration");
            }
        } catch (\Exception $e) {
            // Log or ignore schema check error
        }
    }

    public function index()
    {
        if ($this->session->get('admin_logged_in')) {
            return redirect()->to('/teacher/dashboard');
        }

        $settingModel = new SettingModel();
        $settings = $settingModel->getSettings();

        $data = [
            'websiteName' => $settings['Website Name'] ?? 'ระบบข้อสอบออนไลน์',
            'logoUrl'     => $settings['Logo URL'] ?? '',
            'googleClientId' => $settings['Google Client ID'] ?? '',
        ];

        return view('admin/login', $data);
    }

    public function dashboard()
    {
        if (!$this->session->get('admin_logged_in')) {
            return redirect()->to('/teacher');
        }

        $settingModel = new SettingModel();
        $settings = $settingModel->getSettings();

        $data = [
            'websiteName' => $settings['Website Name'] ?? 'ระบบข้อสอบออนไลน์',
            'logoUrl'     => $settings['Logo URL'] ?? '',
            'teacherName' => $this->session->get('teacher_name') ?? ($settings['Teacher Name'] ?? 'ผู้ดูแลระบบ'),
            'teacherEmail' => $this->session->get('teacher_email') ?? '',
            'teacherLearning' => $this->session->get('teacher_learning') ?? '',
            'examType'    => $settings['Exam Type'] ?? 'ข้อสอบกลางภาค',
        ];

        return view('admin/dashboard', $data);
    }

    public function questions()
    {
        if (!$this->session->get('admin_logged_in')) {
            return redirect()->to('/teacher');
        }

        $examId = $this->request->getGet('exam_id');
        if (empty($examId)) {
            return redirect()->to('/teacher/dashboard');
        }

        $settingModel = new SettingModel();
        $settings = $settingModel->getSettings();

        $data = [
            'websiteName' => $settings['Website Name'] ?? 'ระบบข้อสอบออนไลน์',
            'logoUrl'     => $settings['Logo URL'] ?? '',
            'teacherName' => $this->session->get('teacher_name') ?? ($settings['Teacher Name'] ?? 'ผู้ดูแลระบบ'),
            'teacherEmail' => $this->session->get('teacher_email') ?? '',
            'teacherLearning' => $this->session->get('teacher_learning') ?? '',
            'examType'    => $settings['Exam Type'] ?? 'ข้อสอบกลางภาค',
            'activeExamId' => $examId,
            'currentTab'   => 'questions',
            'isInWorkspace' => true,
        ];

        return view('admin/dashboard', $data);
    }

    public function monitor()
    {
        if (!$this->session->get('admin_logged_in')) {
            return redirect()->to('/teacher');
        }

        $examId = $this->request->getGet('exam_id');
        if (empty($examId)) {
            return redirect()->to('/teacher/dashboard');
        }

        $settingModel = new SettingModel();
        $settings = $settingModel->getSettings();

        $data = [
            'websiteName' => $settings['Website Name'] ?? 'ระบบข้อสอบออนไลน์',
            'logoUrl'     => $settings['Logo URL'] ?? '',
            'teacherName' => $this->session->get('teacher_name') ?? ($settings['Teacher Name'] ?? 'ผู้ดูแลระบบ'),
            'teacherEmail' => $this->session->get('teacher_email') ?? '',
            'teacherLearning' => $this->session->get('teacher_learning') ?? '',
            'examType'    => $settings['Exam Type'] ?? 'ข้อสอบกลางภาค',
            'activeExamId' => $examId,
            'currentTab'   => 'monitor',
            'isInWorkspace' => true,
        ];

        return view('admin/dashboard', $data);
    }

    public function results()
    {
        if (!$this->session->get('admin_logged_in')) {
            return redirect()->to('/teacher');
        }

        $examId = $this->request->getGet('exam_id');
        if (empty($examId)) {
            return redirect()->to('/teacher/dashboard');
        }

        $settingModel = new SettingModel();
        $settings = $settingModel->getSettings();

        $data = [
            'websiteName' => $settings['Website Name'] ?? 'ระบบข้อสอบออนไลน์',
            'logoUrl'     => $settings['Logo URL'] ?? '',
            'teacherName' => $this->session->get('teacher_name') ?? ($settings['Teacher Name'] ?? 'ผู้ดูแลระบบ'),
            'teacherEmail' => $this->session->get('teacher_email') ?? '',
            'teacherLearning' => $this->session->get('teacher_learning') ?? '',
            'examType'    => $settings['Exam Type'] ?? 'ข้อสอบกลางภาค',
            'activeExamId' => $examId,
            'currentTab'   => 'results',
            'isInWorkspace' => true,
        ];

        return view('admin/dashboard', $data);
    }

    public function logs()
    {
        if (!$this->session->get('admin_logged_in')) {
            return redirect()->to('/teacher');
        }

        $examId = $this->request->getGet('exam_id') ?: '';
        $settingModel = new SettingModel();
        $settings = $settingModel->getSettings();

        $data = [
            'websiteName' => $settings['Website Name'] ?? 'ระบบข้อสอบออนไลน์',
            'logoUrl'     => $settings['Logo URL'] ?? '',
            'teacherName' => $this->session->get('teacher_name') ?? ($settings['Teacher Name'] ?? 'ผู้ดูแลระบบ'),
            'teacherEmail' => $this->session->get('teacher_email') ?? '',
            'teacherLearning' => $this->session->get('teacher_learning') ?? '',
            'examType'    => $settings['Exam Type'] ?? 'ข้อสอบกลางภาค',
            'activeExamId' => $examId,
            'currentTab'   => 'logs',
            'isInWorkspace' => !empty($examId),
        ];

        return view('admin/dashboard', $data);
    }

    public function settings()
    {
        if (!$this->session->get('admin_logged_in')) {
            return redirect()->to('/teacher');
        }

        $settingModel = new SettingModel();
        $settings = $settingModel->getSettings();

        $data = [
            'websiteName' => $settings['Website Name'] ?? 'ระบบข้อสอบออนไลน์',
            'logoUrl'     => $settings['Logo URL'] ?? '',
            'teacherName' => $this->session->get('teacher_name') ?? ($settings['Teacher Name'] ?? 'ผู้ดูแลระบบ'),
            'teacherEmail' => $this->session->get('teacher_email') ?? '',
            'teacherLearning' => $this->session->get('teacher_learning') ?? '',
            'examType'    => $settings['Exam Type'] ?? 'ข้อสอบกลางภาค',
            'activeExamId' => 'global',
            'currentTab'   => 'settings',
            'isInWorkspace' => true,
        ];

        return view('admin/dashboard', $data);
    }

    public function examSettings()
    {
        if (!$this->session->get('admin_logged_in')) {
            return redirect()->to('/teacher');
        }

        $examId = $this->request->getGet('exam_id');
        if (empty($examId)) {
            return redirect()->to('/teacher/dashboard');
        }

        $settingModel = new SettingModel();
        $settings = $settingModel->getSettings();

        $data = [
            'websiteName' => $settings['Website Name'] ?? 'ระบบข้อสอบออนไลน์',
            'logoUrl'     => $settings['Logo URL'] ?? '',
            'teacherName' => $this->session->get('teacher_name') ?? ($settings['Teacher Name'] ?? 'ผู้ดูแลระบบ'),
            'teacherEmail' => $this->session->get('teacher_email') ?? '',
            'teacherLearning' => $this->session->get('teacher_learning') ?? '',
            'examType'    => $settings['Exam Type'] ?? 'ข้อสอบกลางภาค',
            'activeExamId' => $examId,
            'currentTab'   => 'exam-settings',
            'isInWorkspace' => true,
        ];

        return view('admin/dashboard', $data);
    }

    // --- Admin APIs ---

    public function login()
    {
        $password = $this->request->getPost('password') ?? '';

        $settingModel = new SettingModel();
        $settings = $settingModel->getSettings();
        $storedPassword = $settings['Admin Password'] ?? 'admin1234';

        if (trim($password) === trim($storedPassword)) {
            $this->session->set('admin_logged_in', true);
            $this->session->set('teacher_name', $settings['Teacher Name'] ?? 'ผู้ดูแลระบบ');
            return $this->respond(['success' => true, 'message' => 'เข้าสู่ระบบสำเร็จ']);
        }

        return $this->respond(['success' => false, 'message' => 'รหัสผ่านไม่ถูกต้อง'], 401);
    }

    public function googleLogin()
    {
        $idToken = $this->request->getPost('credential') ?? '';
        if (empty($idToken)) {
            return $this->respond(['success' => false, 'message' => 'ไม่พบข้อมูล Google Token'], 400);
        }

        // Verify ID Token with Google API via cURL
        $url = "https://oauth2.googleapis.com/tokeninfo?id_token=" . urlencode($idToken);
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            return $this->respond(['success' => false, 'message' => 'การตรวจสอบ Google Token ล้มเหลว'], 401);
        }

        $tokenInfo = json_decode($response, true);
        $email = strtolower($tokenInfo['email'] ?? '');
        $emailVerified = $tokenInfo['email_verified'] ?? 'false';

        if (empty($email) || $emailVerified !== 'true') {
            return $this->respond(['success' => false, 'message' => 'อีเมลยังไม่ได้รับการยืนยันจาก Google'], 400);
        }

        if (substr($email, -10) !== '@skj.ac.th') {
            return $this->respond(['success' => false, 'message' => 'อนุญาตเฉพาะอีเมลโรงเรียน (@skj.ac.th) เท่านั้น'], 400);
        }

        // Query cross-database: skjacth_personnel.tb_personnel
        $db = \Config\Database::connect();
        $query = $db->query("SELECT * FROM skjacth_personnel.tb_personnel WHERE LOWER(pers_username) = ? LIMIT 1", [$email]);
        $teacher = $query->getRowArray();

        if (!$teacher) {
            return $this->respond([
                'success' => false, 
                'message' => "ไม่พบข้อมูลบัญชีบุคลากรที่ตรงกับอีเมล: {$email} ในระบบ"
            ], 403);
        }

        // Successful login
        $displayName = $teacher['pers_prefix'] . $teacher['pers_firstname'] . ' ' . $teacher['pers_lastname'];

        // Resolve learning area code (e.g. lear_003) to Thai name from skjacth_skj.tb_learning
        $learningName = '';
        $learCode = $teacher['pers_learning'] ?? '';
        if (!empty($learCode)) {
            $learQuery = $db->query("SELECT lear_namethai FROM skjacth_skj.tb_learning WHERE lear_id = ? LIMIT 1", [$learCode]);
            $learRow = $learQuery->getRowArray();
            if ($learRow) {
                $learningName = trim($learRow['lear_namethai']);
            }
        }

        $this->session->set([
            'admin_logged_in' => true,
            'teacher_name'    => $displayName,
            'teacher_email'   => $email,
            'teacher_img'     => $teacher['pers_img'] ?? '',
            'teacher_learning'=> $learningName,
        ]);

        return $this->respond(['success' => true, 'message' => 'เข้าสู่ระบบบุคลากรสำเร็จ']);
    }

    public function logout()
    {
        $this->session->remove('admin_logged_in');
        $this->session->remove('teacher_name');
        $this->session->remove('teacher_email');
        $this->session->remove('teacher_img');
        return $this->respond(['success' => true, 'message' => 'ออกจากระบบสำเร็จ']);
    }

    private function checkAuth()
    {
        if (!$this->session->get('admin_logged_in')) {
            throw new \Exception('Unauthorized', 401);
        }
    }

    public function getSettings()
    {
        try {
            $this->checkAuth();
            $settingModel = new SettingModel();
            return $this->respond(['success' => true, 'settings' => $settingModel->getSettings()]);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], $e->getCode() ?: 500);
        }
    }

    public function saveSettings()
    {
        try {
            $this->checkAuth();
            $settings = $this->request->getPost('settings');
            if (is_string($settings)) {
                $settings = json_decode($settings, true);
            }

            if (empty($settings)) {
                return $this->respond(['success' => false, 'message' => 'ข้อมูลการตั้งค่าว่างเปล่า'], 400);
            }

            $settingModel = new SettingModel();
            $settingModel->updateSettings($settings);

            // If exam status is set to Waiting, clear the student lobby
            if (isset($settings['Exam Status']) && $settings['Exam Status'] === 'Waiting') {
                $studentModel = new StudentModel();
                $studentModel->truncate(); // Clear lobby list
            }

            return $this->respond(['success' => true, 'message' => 'บันทึกการตั้งค่าเรียบร้อยแล้ว']);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], $e->getCode() ?: 500);
        }
    }

    public function getExams()
    {
        try {
            $this->checkAuth();
            $examModel = new \App\Models\ExamModel();
            
            $isSuperAdmin = empty($this->session->get('teacher_email'));
            $teacherEmail = $this->session->get('teacher_email');

            $db = \Config\Database::connect();
            
            $sql = "SELECT e.*, 
                    (SELECT COUNT(*) FROM questions WHERE exam_id = e.id COLLATE utf8mb4_general_ci AND type = 'choice') as choice_count,
                    (SELECT COUNT(*) FROM questions WHERE exam_id = e.id COLLATE utf8mb4_general_ci AND type = 'writing') as writing_count
                    FROM exams e";

            if (!$isSuperAdmin && !empty($teacherEmail)) {
                $query = $db->query($sql . " WHERE e.teacher_email = ? OR e.teacher_email IS NULL ORDER BY e.subject_code ASC", [$teacherEmail]);
                $exams = $query->getResultArray();
            } else {
                $query = $db->query($sql . " ORDER BY e.subject_code ASC");
                $exams = $query->getResultArray();
            }
            return $this->respond(['success' => true, 'exams' => $exams]);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function saveExam()
    {
        try {
            $this->checkAuth();
            $id = $this->request->getPost('id') ?: null;
            $subjectCode = $this->request->getPost('subject_code') ?? '';
            $subjectName = $this->request->getPost('subject_name') ?? '';
            $academicYear = $this->request->getPost('academic_year') ?? '';
            $semester = $this->request->getPost('semester') ?? '';
            $learningArea = $this->request->getPost('learning_area') ?? 'ทั่วไป';
            $teacherName = $this->request->getPost('teacher_name') ?? '';
            $examType = $this->request->getPost('exam_type') ?? 'สอบกลางภาค';
            $examStatus = $this->request->getPost('exam_status') ?? 'Waiting';
            $maxAttempts = (int)($this->request->getPost('max_attempts') ?? 1);
            $passingPercentage = (int)($this->request->getPost('passing_percentage') ?? 50);
            $timeLimitChoice = (int)($this->request->getPost('time_limit_choice') ?? 60);
            $timeLimitWriting = (int)($this->request->getPost('time_limit_writing') ?? 300);
            $numQuestions = (int)($this->request->getPost('num_questions') ?? 20);
            $examRound = $this->request->getPost('exam_round') ?: '1';

            $examDuration = (int)($this->request->getPost('exam_duration') ?? 0);

            if (empty($subjectCode) || empty($subjectName)) {
                return $this->respond(['success' => false, 'message' => 'กรุณากรอกรหัสวิชาและชื่อวิชา'], 400);
            }

            $examModel = new \App\Models\ExamModel();

            $isSuperAdmin = empty($this->session->get('teacher_email'));
            $teacherEmail = $this->session->get('teacher_email');

            if (!$isSuperAdmin && !empty($teacherEmail)) {
                // If it is an edit, check that the exam belongs to this teacher
                if (!empty($id)) {
                    $existingExam = $examModel->find($id);
                    if ($existingExam && !empty($existingExam['teacher_email']) && $existingExam['teacher_email'] !== $teacherEmail) {
                        return $this->respond(['success' => false, 'message' => 'คุณไม่มีสิทธิ์แก้ไขรายวิชานี้'], 403);
                    }
                }
                $teacherEmailToSave = $teacherEmail;
                $teacherNameToSave = $this->session->get('teacher_name') ?: $teacherName;
            } else {
                $teacherEmailToSave = $this->request->getPost('teacher_email') ?: null;
                $teacherNameToSave = $teacherName;
            }

            if (empty($id)) {
                $id = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                    mt_rand(0, 0xffff), mt_rand(0, 0xffff),
                    mt_rand(0, 0xffff),
                    mt_rand(0, 0x0fff) | 0x4000,
                    mt_rand(0, 0x3fff) | 0x8000,
                    mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
                );
            }

            $data = [
                'id' => $id,
                'subject_code' => $subjectCode,
                'subject_name' => $subjectName,
                'academic_year' => $academicYear,
                'semester' => $semester,
                'learning_area' => $learningArea,
                'teacher_name' => $teacherNameToSave,
                'teacher_email' => $teacherEmailToSave,
                'exam_type' => $examType,
                'exam_status' => $examStatus,
                'max_attempts' => $maxAttempts,
                'passing_percentage' => $passingPercentage,
                'time_limit_choice' => $timeLimitChoice,
                'time_limit_writing' => $timeLimitWriting,
                'exam_duration' => $examDuration,
                'num_questions' => $numQuestions,
                'exam_round' => $examRound
            ];

            if ($examStatus === 'Started') {
                $existing = $examModel->find($id);
                if (!$existing || empty($existing['started_at'])) {
                    $data['started_at'] = date('Y-m-d H:i:s');
                } else {
                    $data['started_at'] = $existing['started_at'];
                }
            } else if ($examStatus === 'Waiting') {
                $data['started_at'] = null;
            }

            // If exam status is set to Waiting, clear the student lobby for this exam
            if ($examStatus === 'Waiting') {
                $studentModel = new StudentModel();
                $studentModel->where('exam_id', $id)->delete();
            }

            $examModel->save($data);
            return $this->respond(['success' => true, 'message' => 'บันทึกรายวิชาเรียบร้อยแล้ว']);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function updateExamStatus()
    {
        try {
            $this->checkAuth();
            $id = $this->request->getPost('id');
            $status = $this->request->getPost('status');

            if (empty($id) || empty($status)) {
                return $this->respond(['success' => false, 'message' => 'Missing parameters'], 400);
            }

            $examModel = new \App\Models\ExamModel();
            $exam = $examModel->find($id);
            if (!$exam) {
                return $this->respond(['success' => false, 'message' => 'ไม่พบวิชาสอบนี้'], 404);
            }

            $updateData = ['exam_status' => $status];
            if ($status === 'Started') {
                $updateData['started_at'] = date('Y-m-d H:i:s');
            } else if ($status === 'Waiting') {
                $updateData['started_at'] = null;
            }
            $examModel->update($id, $updateData);

            // Clear students queue if status is Waiting
            if ($status === 'Waiting') {
                $studentModel = new StudentModel();
                $studentModel->where('exam_id', $id)->delete();
            }

            return $this->respond(['success' => true, 'message' => 'ปรับปรุงสถานะสอบแล้ว']);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function updateJoinPolicy()
    {
        try {
            $this->checkAuth();
            $id = $this->request->getPost('id');
            $policy = $this->request->getPost('join_policy');

            if (empty($id) || empty($policy)) {
                return $this->respond(['success' => false, 'message' => 'Missing parameters'], 400);
            }

            $examModel = new \App\Models\ExamModel();
            $exam = $examModel->find($id);
            if (!$exam) {
                return $this->respond(['success' => false, 'message' => 'ไม่พบวิชาสอบนี้'], 404);
            }

            $examModel->update($id, ['join_policy' => $policy]);
            return $this->respond(['success' => true, 'message' => 'ปรับปรุงนโยบายการเข้าร่วมสอบแล้ว']);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function deleteExam()
    {
        try {
            $this->checkAuth();
            $id = $this->request->getPost('id');
            if (empty($id)) {
                return $this->respond(['success' => false, 'message' => 'Missing exam ID'], 400);
            }

            $examModel = new \App\Models\ExamModel();
            $examModel->delete($id);

            // Cascade delete related records
            $questionModel = new QuestionModel();
            $questionModel->where('exam_id', $id)->delete();

            $resultModel = new ExamResultModel();
            $resultModel->where('exam_id', $id)->delete();

            $studentModel = new StudentModel();
            $studentModel->where('exam_id', $id)->delete();

            return $this->respond(['success' => true, 'message' => 'ลบรายวิชาและข้อมูลที่เกี่ยวข้องสำเร็จ']);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function getQuestions()
    {
        try {
            $this->checkAuth();
            $examId = $this->request->getGet('exam_id');
            $questionModel = new QuestionModel();
            if ($examId) {
                $questions = $questionModel->where('exam_id', $examId)->findAll();
            } else {
                $questions = $questionModel->findAll();
            }
            return $this->respond(['success' => true, 'questions' => $questions]);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], $e->getCode() ?: 500);
        }
    }

    public function saveQuestion()
    {
        try {
            $this->checkAuth();
            $id = $this->request->getPost('id') ?: null;
            $examId = $this->request->getPost('exam_id');
            $questionText = $this->request->getPost('question') ?? '';
            $type = $this->request->getPost('type') ?? 'choice';
            $points = (int)($this->request->getPost('points') ?? 1);
            $imageUrl = $this->request->getPost('image_url') ?? '';

            if (empty($examId)) {
                return $this->respond(['success' => false, 'message' => 'กรุณาระบุรายวิชาสอบ'], 400);
            }

            $options = $this->request->getPost('options');
            if (is_string($options)) {
                $options = json_decode($options, true);
            }

            $answer = $this->request->getPost('answer') ?? '';

            if (empty($questionText)) {
                return $this->respond(['success' => false, 'message' => 'กรุณากรอกโจทย์คำถาม'], 400);
            }

            $questionModel = new QuestionModel();

            if (empty($id)) {
                $id = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                    mt_rand(0, 0xffff), mt_rand(0, 0xffff),
                    mt_rand(0, 0xffff),
                    mt_rand(0, 0x0fff) | 0x4000,
                    mt_rand(0, 0x3fff) | 0x8000,
                    mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
                );
            }

            $data = [
                'id'             => $id,
                'exam_id'        => $examId,
                'question_text'  => $questionText,
                'type'           => $type,
                'points'         => $points,
                'correct_answer' => $answer,
                'image_url'      => $imageUrl,
                'option_a'       => $type === 'choice' ? ($options[0] ?? '') : null,
                'option_b'       => $type === 'choice' ? ($options[1] ?? '') : null,
                'option_c'       => $type === 'choice' ? ($options[2] ?? '') : null,
                'option_d'       => $type === 'choice' ? ($options[3] ?? '') : null,
            ];

            $questionModel->save($data);
            return $this->respond(['success' => true, 'message' => 'บันทึกข้อสอบเรียบร้อย']);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], $e->getCode() ?: 500);
        }
    }

    public function deleteQuestion()
    {
        try {
            $this->checkAuth();
            $id = $this->request->getPost('id');
            if (empty($id)) {
                return $this->respond(['success' => false, 'message' => 'Missing question ID'], 400);
            }

            $questionModel = new QuestionModel();
            $questionModel->delete($id);
            return $this->respond(['success' => true, 'message' => 'ลบข้อสอบเรียบร้อย']);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], $e->getCode() ?: 500);
        }
    }

    public function clearAllQuestions()
    {
        try {
            $this->checkAuth();
            $examId = $this->request->getPost('exam_id');
            if (empty($examId)) {
                return $this->respond(['success' => false, 'message' => 'Missing exam ID'], 400);
            }

            $questionModel = new QuestionModel();
            $questionModel->where('exam_id', $examId)->delete();
            return $this->respond(['success' => true, 'message' => 'ล้างคลังข้อสอบของรายวิชานี้เรียบร้อยแล้ว']);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], $e->getCode() ?: 500);
        }
    }

    public function updateQuestionPoints()
    {
        try {
            $this->checkAuth();
            $id = $this->request->getPost('id');
            $points = $this->request->getPost('points');

            if (empty($id) || $points === null || $points === '') {
                return $this->respond(['success' => false, 'message' => 'Missing parameters'], 400);
            }

            $db = \Config\Database::connect();
            $db->query("UPDATE questions SET points = ? WHERE id = ?", [(float)$points, $id]);

            return $this->respond(['success' => true, 'message' => 'อัปเดตคะแนนเรียบร้อย']);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function importQuestions()
    {
        try {
            $this->checkAuth();
            $examId = $this->request->getPost('exam_id');
            $rows = $this->request->getPost('rows');
            $clearExisting = filter_var($this->request->getPost('clearExisting'), FILTER_VALIDATE_BOOLEAN);

            if (empty($examId)) {
                return $this->respond(['success' => false, 'message' => 'Missing exam ID'], 400);
            }

            if (is_string($rows)) {
                $rows = json_decode($rows, true);
            }

            if (empty($rows)) {
                return $this->respond(['success' => false, 'message' => 'ไม่มีข้อมูลให้นำเข้า'], 400);
            }

            $questionModel = new QuestionModel();
            if ($clearExisting) {
                $questionModel->where('exam_id', $examId)->delete();
            }

            $count = 0;
            foreach ($rows as $row) {
                if (count($row) >= 6 && !empty($row[0])) {
                    $id = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
                        mt_rand(0, 0xffff),
                        mt_rand(0, 0x0fff) | 0x4000,
                        mt_rand(0, 0x3fff) | 0x8000,
                        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
                    );

                    $type = (!empty($row[6]) && trim(strtolower($row[6])) === 'writing') ? 'writing' : 'choice';
                    $points = (!empty($row[7])) ? (int)$row[7] : 1;

                    $questionModel->insert([
                        'id'             => $id,
                        'exam_id'        => $examId,
                        'question_text'  => $row[0],
                        'option_a'       => $type === 'choice' ? ($row[1] ?? '') : null,
                        'option_b'       => $type === 'choice' ? ($row[2] ?? '') : null,
                        'option_c'       => $type === 'choice' ? ($row[3] ?? '') : null,
                        'option_d'       => $type === 'choice' ? ($row[4] ?? '') : null,
                        'correct_answer' => $row[5] ?? '',
                        'type'           => $type,
                        'points'         => $points,
                    ]);
                    $count++;
                }
            }

            return $this->respond(['success' => true, 'count' => $count]);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], $e->getCode() ?: 500);
        }
    }

    public function uploadImage()
    {
        try {
            $this->checkAuth();
            $base64Data = $this->request->getPost('image') ?? '';
            $fileName = $this->request->getPost('fileName') ?? 'upload_' . time() . '.png';

            if (empty($base64Data)) {
                return $this->respond(['success' => false, 'message' => 'No image data'], 400);
            }

            if (preg_match('/^data:image\/(\w+);base64,/', $base64Data, $type)) {
                $data = substr($base64Data, strpos($base64Data, ',') + 1);
                $type = strtolower($type[1]);

                if (!in_array($type, ['jpg', 'jpeg', 'gif', 'png', 'webp'])) {
                    return $this->respond(['success' => false, 'message' => 'Invalid image type'], 400);
                }

                $data = base64_decode($data);
                if ($data === false) {
                    return $this->respond(['success' => false, 'message' => 'Base64 decode failed'], 400);
                }
            } else {
                return $this->respond(['success' => false, 'message' => 'Invalid data URI format'], 400);
            }

            $uploadDir = ROOTPATH . 'public/uploads/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $cleanFileName = sanitize_filename($fileName);
            $uniqueFileName = time() . '_' . $cleanFileName;
            $filePath = $uploadDir . $uniqueFileName;

            if (file_put_contents($filePath, $data)) {
                $url = '/uploads/' . $uniqueFileName;
                return $this->respond(['success' => true, 'url' => $url, 'fileName' => $uniqueFileName]);
            }

            return $this->respond(['success' => false, 'message' => 'Failed to save file'], 500);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function getResults()
    {
        try {
            $this->checkAuth();
            $examId = $this->request->getGet('exam_id');
            $resultModel = new ExamResultModel();
            
            if ($examId) {
                $results = $resultModel->where('exam_id', $examId)->orderBy('submitted_at', 'DESC')->findAll();
            } else {
                $results = $resultModel->orderBy('submitted_at', 'DESC')->findAll();
            }
            return $this->respond(['success' => true, 'results' => $results]);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], $e->getCode() ?: 500);
        }
    }

    public function deleteResult()
    {
        try {
            $this->checkAuth();
            $id = $this->request->getPost('id');
            if (empty($id)) {
                return $this->respond(['success' => false, 'message' => 'Missing result ID'], 400);
            }

            $resultModel = new ExamResultModel();
            $resultModel->delete($id);
            return $this->respond(['success' => true, 'message' => 'ลบผลการสอบสำเร็จ']);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], $e->getCode() ?: 500);
        }
    }

    public function updateScore()
    {
        try {
            $this->checkAuth();
            $id = $this->request->getPost('id');
            $totalScore = (int)$this->request->getPost('totalScore');
            $writingScores = $this->request->getPost('writingScores');

            if (is_string($writingScores)) {
                $writingScores = json_decode($writingScores, true);
            }

            if (empty($id)) {
                return $this->respond(['success' => false, 'message' => 'Missing parameters'], 400);
            }

            $resultModel = new ExamResultModel();
            $result = $resultModel->find($id);

            if (!$result) {
                return $this->respond(['success' => false, 'message' => 'ไม่พบข้อมูลการสอบนี้'], 404);
            }

            $answers = json_decode($result['answers_json'], true);

            foreach ($answers as &$ans) {
                $qId = $ans['questionId'];
                if ($ans['type'] === 'writing' && isset($writingScores[$qId])) {
                    $ans['isCorrect'] = $writingScores[$qId];
                }
            }

            $resultModel->update($id, [
                'score'        => $totalScore,
                'answers_json' => json_encode($answers, JSON_UNESCAPED_UNICODE)
            ]);

            return $this->respond(['success' => true, 'message' => 'อัปเดตคะแนนสำเร็จ!']);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], $e->getCode() ?: 500);
        }
    }

    public function updateScoreDirect()
    {
        try {
            $this->checkAuth();
            $id = $this->request->getPost('id');
            $score = $this->request->getPost('score');

            if (empty($id) || $score === null) {
                return $this->respond(['success' => false, 'message' => 'Missing parameters'], 400);
            }

            $resultModel = new ExamResultModel();
            $result = $resultModel->find($id);

            if (!$result) {
                return $this->respond(['success' => false, 'message' => 'ไม่พบข้อมูลการสอบนี้'], 404);
            }

            $resultModel->update($id, [
                'score' => (float)$score
            ]);

            return $this->respond(['success' => true, 'message' => 'อัปเดตคะแนนเรียบร้อยแล้ว']);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function getMonitor()
    {
        try {
            $this->checkAuth();
            $examId = $this->request->getGet('exam_id');
            $studentModel = new StudentModel();
            
            $timeThreshold = date('Y-m-d H:i:s', time() - 120);
            $query = $studentModel->where('last_active >=', $timeThreshold);
            if ($examId) {
                $query = $query->where('exam_id', $examId);
            }
            $students = $query->orderBy('name', 'ASC')->findAll();

            $joinPolicy = 'anytime';
            $examStatus = 'Waiting';
            if ($examId) {
                $examModel = new \App\Models\ExamModel();
                $exam = $examModel->find($examId);
                if ($exam) {
                    $examStatus = $exam['exam_status'];
                    $joinPolicy = $exam['join_policy'] ?? 'anytime';
                }
            }
                                     
            $lobbyMode = 'game';
            $settingModel = new \App\Models\SettingModel();
            $settingsData = $settingModel->getSettings();
            if (isset($settingsData['Lobby Mode'])) {
                $lobbyMode = $settingsData['Lobby Mode'];
            }
                                     
            return $this->respond([
                'success' => true, 
                'students' => $students,
                'exam_status' => $examStatus,
                'lobby_mode' => $lobbyMode,
                'join_policy' => $joinPolicy
            ]);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], $e->getCode() ?: 500);
        }
    }

    public function deleteStudent()
    {
        try {
            $this->checkAuth();
            $email = $this->request->getPost('email');
            $examId = $this->request->getPost('exam_id');
            if (empty($email) || empty($examId)) {
                return $this->respond(['success' => false, 'message' => 'Missing email or exam ID'], 400);
            }

            $studentModel = new StudentModel();
            $studentModel->where('email', $email)->where('exam_id', $examId)->delete();
            return $this->respond(['success' => true, 'message' => 'เอาชื่อนักเรียนออกสำเร็จ']);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], $e->getCode() ?: 500);
        }
    }

    public function getLogs()
    {
        try {
            $this->checkAuth();
            $errorLogModel = new ErrorLogModel();
            
            // Note: error_logs don't store exam_id, but we can match student email to exam_id if required.
            // For now, get all logs ordered by timestamp.
            $logs = $errorLogModel->orderBy('timestamp', 'DESC')->findAll();
            return $this->respond(['success' => true, 'logs' => $logs]);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], $e->getCode() ?: 500);
        }
    }

    public function clearLogs()
    {
        try {
            $this->checkAuth();
            $errorLogModel = new ErrorLogModel();
            $errorLogModel->truncate();
            return $this->respond(['success' => true, 'message' => 'ล้างบันทึกความเสี่ยงทั้งหมดสำเร็จ']);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], $e->getCode() ?: 500);
        }
    }

    public function aiGrade()
    {
        try {
            $this->checkAuth();
            $question = $this->request->getPost('question');
            $studentAnswer = $this->request->getPost('studentAnswer');
            $correctAnswer = $this->request->getPost('correctAnswer');
            $maxPoints = (float)($this->request->getPost('maxPoints') ?: 1);

            $settingModel = new \App\Models\SettingModel();
            $settings = $settingModel->getSettings();
            $apiKey = $settings['Gemini API Key'] ?? '';

            if (empty($apiKey)) {
                return $this->respond(['success' => false, 'message' => 'ไม่ได้ตั้งค่า Gemini API Key ในระบบ'], 400);
            }

            $cleanKey = trim($apiKey);
            $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" . $cleanKey;

            $prompt = "คุณคือครูผู้ช่วยตรวจข้อสอบอัตนัย (ข้อเขียน)\n" .
                      "โจทย์: \"{$question}\"\n" .
                      "เฉลยแนวทาง: \"{$correctAnswer}\"\n" .
                      "คำตอบของนักเรียน: \"{$studentAnswer}\"\n" .
                      "คะแนนเต็มของข้อนี้: {$maxPoints} คะแนน\n\n" .
                      "กติกา:\n" .
                      "- ประเมินความถูกต้องและเนื้อหาของคำตอบนักเรียนเทียบกับเฉลยแนวทางอย่างเป็นธรรม\n" .
                      "- ให้คะแนนเป็นตัวเลขทศนิยมระหว่าง 0 ถึง {$maxPoints} (เช่น 0, 0.5, 1, 1.5, 2, ...)\n" .
                      "- ตอบกลับเป็น JSON เท่านั้นในรูปแบบ:\n" .
                      "{\n" .
                      "  \"score\": ตัวเลขคะแนนที่ได้,\n" .
                      "  \"explanation\": \"อธิบายเหตุผลสั้นๆ เป็นภาษาไทย\"\n" .
                      "}";

            $payload = [
                'contents' => [
                    ['parts' => [['text' => $prompt]]]
                ]
            ];

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
            curl_setopt($ch, CURLOPT_TIMEOUT, 15);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode !== 200) {
                return $this->respond(['success' => false, 'message' => "AI Error (HTTP {$httpCode})"], 500);
            }

            $result = json_decode($response, true);
            if (isset($result['candidates'][0]['content']['parts'][0]['text'])) {
                $aiText = $result['candidates'][0]['content']['parts'][0]['text'];
                $aiText = preg_replace('/```json/', '', $aiText);
                $aiText = preg_replace('/```/', '', $aiText);
                $aiText = trim($aiText);

                $aiResponse = json_decode($aiText, true);
                $score = isset($aiResponse['score']) ? (float)$aiResponse['score'] : 0.0;
                $explanation = $aiResponse['explanation'] ?? 'ตรวจโดย AI สำเร็จ';

                // Cap the score between 0 and maxPoints
                if ($score < 0) $score = 0.0;
                if ($score > $maxPoints) $score = $maxPoints;

                return $this->respond([
                    'success' => true,
                    'score' => $score,
                    'explanation' => $explanation
                ]);
            }

            return $this->respond(['success' => false, 'message' => 'AI ตอบกลับมาในรูปแบบที่ตรวจไม่ได้'], 500);
        } catch (\Exception $e) {
            return $this->respond(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }
}
