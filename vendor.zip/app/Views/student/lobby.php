<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>ห้องพักคอยการสอบ | <?= esc($websiteName) ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=K2D:wght@400;600;700;800&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    html { scroll-behavior: smooth; }
    * { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
    body {
      font-family: 'K2D', sans-serif;
      background: #090d16;
      min-height: 100vh;
      color: #f8fafc;
      overflow-x: hidden;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 1rem;
    }
    .bg-animation {
      position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; z-index: -1;
      overflow: hidden; pointer-events: none; background: radial-gradient(circle at center, #111827 0%, #090d16 100%);
    }
    .blob {
      position: absolute; border-radius: 50%; filter: blur(60px); opacity: 0.3;
      animation: move 15s infinite alternate ease-in-out;
    }
    .blob-1 { width: 300px; height: 300px; background: #ec4899; top: -10%; left: -10%; }
    .blob-2 { width: 400px; height: 400px; background: #0ea5e9; bottom: -10%; right: -10%; animation-delay: -5s; }
    @keyframes move { from { transform: translate(0, 0) scale(1); } to { transform: translate(40px, 40px) scale(1.2); } }

    .glass-card {
      background: rgba(255, 255, 255, 0.03);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 32px;
      padding: 2rem;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
      animation: slideIn 0.6s cubic-bezier(0.16, 1, 0.3, 1);
    }
    @keyframes slideIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }

    /* Waiting Room Pulse */
    .pulse-box { width: 100px; height: 100px; background: rgba(236, 72, 153, 0.15); border-radius: 50%; margin: 2rem auto; display: flex; align-items: center; justify-content: center; position: relative; }
    .pulse-ring { position: absolute; inset: 0; border: 2px solid #ec4899; border-radius: 50%; animation: ripple-effect 2s infinite; }
    @keyframes ripple-effect { from { transform: scale(1); opacity: 0.8; } to { transform: scale(1.8); opacity: 0; } }

    /* Clock */
    .digital-clock-container {
      margin: 2rem 0;
      padding: 1.5rem;
      background: rgba(255, 255, 255, 0.03);
      border: 1px solid rgba(255, 255, 255, 0.05);
      border-radius: 24px;
      display: inline-block;
      min-width: 260px;
    }
    .digital-time {
      font-size: 3.5rem;
      font-weight: 900;
      font-family: monospace;
      background: linear-gradient(135deg, #ec4899, #0ea5e9);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      line-height: 1;
      letter-spacing: -2px;
    }
    .waiting-duration {
      font-size: 0.75rem;
      font-weight: 800;
      color: #94a3b8;
      text-transform: uppercase;
      letter-spacing: 0.2em;
      margin-top: 0.5rem;
    }

    #waitingRoomOverlay {
      display: none;
      position: fixed;
      top: 0; left: 0;
      width: 100vw; height: 100vh;
      background: #090d16;
      z-index: 9000;
      overflow: hidden;
      touch-action: none;
      user-select: none;
    }
    #waitingRoomOverlay.active { display: block; }
    
    .game-hud-tl {
      position: absolute; top: 12px; left: 12px;
      z-index: 10; pointer-events: none;
      display: flex; flex-direction: column; gap: 4px;
    }
    .hud-chip {
      background: rgba(0,0,0,0.75);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 20px;
      padding: 5px 12px;
      font-family: monospace;
      font-size: 12px;
      color: #ec4899;
      text-shadow: 0 0 8px #ec4899;
      white-space: nowrap;
    }

    .game-hud-tc {
      position: absolute; top: 12px;
      left: 50%; transform: translateX(-50%);
      z-index: 10; pointer-events: none;
      max-width: calc(100% - 180px);
    }
    .hud-title {
      background: rgba(0,0,0,0.75);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: 20px;
      padding: 6px 16px;
      font-size: 12px;
      font-weight: 800;
      color: #e2e8f0;
      display: flex; align-items: center; gap: 6px;
      white-space: nowrap;
    }
    .hud-pulse-dot {
      width: 7px; height: 7px; background: #ec4899;
      border-radius: 50%; animation: pulseDot 1.5s infinite;
    }
    @keyframes pulseDot { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.4;transform:scale(0.7)} }

    #countdownOverlay {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(9, 13, 22, 0.95);
      backdrop-filter: blur(24px);
      z-index: 99999;
      align-items: center;
      justify-content: center;
      flex-direction: column;
    }
    #countdownOverlay.active { display: flex; }
    .countdown-num {
      font-size: 10rem;
      font-weight: 900; line-height: 1;
      background: linear-gradient(135deg, #ec4899, #0ea5e9);
      -webkit-background-clip: text;
      background-clip: text;
      -webkit-text-fill-color: transparent;
      filter: drop-shadow(0 0 50px rgba(236,72,153,0.5));
      animation: countdownPop 1s ease;
    }
    @keyframes countdownPop {
      0%   { transform: scale(1.8); opacity: 0; }
      40%  { transform: scale(0.9); opacity: 1; }
      70%  { transform: scale(1.05); }
      100% { transform: scale(1); }
    }
  </style>
</head>
<body>
  <div class="bg-animation"><div class="blob blob-1"></div><div class="blob blob-2"></div></div>

  <div class="w-full max-w-[480px]">
    <div class="glass-card text-center py-6">
      <div id="mobileWaitingContent">
        <div class="pulse-box"><div class="pulse-ring"></div><span class="text-4xl">⏳</span></div>
        <h2 class="text-2xl font-black text-white mb-1"><?= esc($subjectName) ?></h2>
        <p class="text-xs text-sky-400 font-extrabold mb-2">รหัสวิชา: <?= esc($subjectCode) ?> &nbsp;|&nbsp; ครูผู้สอน: <?= esc($teacherName) ?></p>
        <p class="text-slate-400 text-sm leading-relaxed mb-6 font-bold">กรุณาสแตนด์บายรอสักครู่...<br>ระบบจะเริ่มสอบพร้อมกันเมื่อคุณครูสั่งเริ่ม</p>
        
        <div class="digital-clock-container">
          <div id="mobileDigitalTime" class="digital-time">00:00:00</div>
          <div id="mobileWaitingTime" class="waiting-duration">รอมาแล้ว: 0 นาที 0 วินาที</div>
        </div>

        <div class="mt-8">
          <div class="inline-block px-6 py-2 bg-pink-500/10 border border-pink-500/20 rounded-full text-pink-500 font-bold text-sm">
            📱 กำลังเชื่อมต่อระบบสอบ...
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Game overlay for PC -->
  <div id="waitingRoomOverlay">
    <canvas id="gameCanvas"></canvas>
    
    <!-- HUD Top Left -->
    <div class="game-hud-tl">
      <div class="hud-chip">🚀 ASTEROIDS BLASTED: <span id="pixelsCollected">0</span></div>
      <div class="hud-chip" style="font-size:11px;color:#94a3b8;text-shadow:none;">👤 <?= esc($studentName) ?></div>
      <div class="hud-chip" style="font-size:10px;color:#38bdf8;text-shadow:none;border-color:rgba(56,189,248,0.2);">🎮 WASD/Arrows: Move | Space/Click: Fire</div>
    </div>

    <!-- HUD Top Center -->
    <div class="game-hud-tc">
      <div class="hud-title">
        <span class="hud-pulse-dot"></span>
        เข้าห้องพักคอยแล้ว &nbsp;|&nbsp; รอคุณครูสั่งเริ่มสอบ...
      </div>
    </div>

    <!-- Leaderboard Panel -->
    <div id="liveLeaderboardPanel" class="absolute top-3 right-3 w-60 bg-black/75 backdrop-blur-md border border-white/10 rounded-2xl p-4 text-white z-10 font-bold max-h-[70vh] overflow-y-auto">
      <div class="text-xs font-black text-pink-500 mb-3 flex items-center justify-between border-b border-white/10 pb-2 uppercase tracking-wider">
        <span>🏆 Leaderboard</span>
        <span class="text-[10px] text-sky-400 animate-pulse">● Live</span>
      </div>
      <div id="leaderboardList" class="space-y-1.5 text-xs font-semibold">
        <!-- populated dynamically -->
      </div>
    </div>

    <!-- Simple Lobby Panel (Classic Text Mode) -->
    <div id="simpleLobbyPanel" class="hidden absolute inset-0 flex items-center justify-center p-6 bg-[#090d16]/98 backdrop-blur-xl overflow-y-auto z-20">
      <div class="glass-card w-full max-w-2xl p-8 rounded-[32px] text-center border border-white/5 space-y-6 shadow-2xl">
        <div>
          <span class="px-3 py-1 bg-pink-500/10 text-pink-500 border border-pink-500/20 text-[10px] font-bold rounded-full uppercase tracking-wider">⏳ ห้องพักคอยสอบ (โหมดเรียบง่าย)</span>
          <h2 class="text-2xl font-black text-white mt-4"><?= esc($subjectName) ?></h2>
          <p class="text-xs text-sky-400 font-extrabold mt-1">รหัสวิชา: <?= esc($subjectCode) ?> &nbsp;|&nbsp; ครูผู้สอน: <?= esc($teacherName) ?></p>
        </div>

        <!-- Timer / Clock info -->
        <div class="bg-white/5 p-4 border border-white/5 rounded-2xl max-w-sm mx-auto flex flex-col items-center">
          <div id="simpleDigitalTime" class="text-4xl font-black text-white font-mono leading-none tracking-tight">00:00:00</div>
          <div id="simpleWaitingTime" class="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-1.5">รอมาแล้ว: 0 นาที 0 วินาที</div>
        </div>

        <!-- Waiting list -->
        <div class="space-y-3">
          <h3 class="text-xs font-extrabold text-slate-400 flex items-center justify-center gap-1.5">
            <span>👥 รายชื่อผู้รอสอบทั้งหมด (<span id="simplePlayerCount">1</span> คน)</span>
          </h3>
          <div id="simplePlayersGrid" class="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-[30vh] overflow-y-auto p-3 border border-white/5 rounded-2xl bg-black/30">
            <div class="px-3 py-2 bg-pink-500/10 text-pink-400 border border-pink-500/20 rounded-xl text-xs font-bold truncate flex items-center gap-1.5 justify-center">
              <span>👑</span> <span class="truncate"><?= esc($studentName) ?> (ฉัน)</span>
            </div>
          </div>
        </div>

<!-- Mode is managed by teacher -->
      </div>
    </div>
  </div>

  <!-- Countdown Overlay -->
  <div id="countdownOverlay">
    <div class="text-center">
      <p class="text-sm font-black text-amber-500 uppercase tracking-[0.3em] mb-4">เตรียมตัว!</p>
      <div id="countdownNum" class="countdown-num">5</div>
      <p class="text-sm font-bold text-slate-500 mt-4 tracking-wider">ข้อสอบกำลังจะเริ่ม...</p>
    </div>
  </div>

  <script>
    const studentEmail = "<?= esc($studentEmail) ?>";
    const studentName = "<?= esc($studentName) ?>";
    var waitingStartTime = new Date();
    var waitingPollingInterval;
    var syncInterval;

    var currentLobbyMode = 'game';

    window.onload = () => {
        startWaitingMode();
    };

    function toggleLobbyMode(mode) {
        currentLobbyMode = mode;
        const simplePanel = document.getElementById('simpleLobbyPanel');
        const liveLeaderboard = document.getElementById('liveLeaderboardPanel');
        const gameCanvas = document.getElementById('gameCanvas');

        if (mode === 'simple') {
            if (simplePanel) simplePanel.classList.remove('hidden');
            if (liveLeaderboard) liveLeaderboard.classList.add('hidden');
            if (gameCanvas) gameCanvas.style.visibility = 'hidden';
            updateSimpleClock();
        } else {
            if (simplePanel) simplePanel.classList.add('hidden');
            if (liveLeaderboard) liveLeaderboard.classList.remove('hidden');
            if (gameCanvas) gameCanvas.style.visibility = 'visible';
        }
    }

    function updateSimpleClock() {
        const now = new Date();
        const timeStr = now.toLocaleTimeString('th-TH', { hour12: false });
        const timeEl = document.getElementById('simpleDigitalTime');
        if (timeEl) timeEl.textContent = timeStr;

        const diff = Math.floor((now - waitingStartTime) / 1000);
        const mins = Math.floor(diff / 60);
        const secs = diff % 60;
        const durationEl = document.getElementById('simpleWaitingTime');
        if (durationEl) durationEl.textContent = `รอมาแล้ว: ${mins} นาที ${secs} วินาที`;
    }

    function startWaitingMode() {
        const isMobileDevice = ('ontouchstart' in window || navigator.maxTouchPoints > 0) && window.innerWidth < 1024;
        const overlay = document.getElementById('waitingRoomOverlay');
        const mobileContent = document.getElementById('mobileWaitingContent');

        if (isMobileDevice) {
            if (mobileContent) mobileContent.style.display = 'block';
            overlay.classList.remove('active');
            document.body.style.overflow = '';
            updateMobileClock();
        } else {
            if (mobileContent) mobileContent.style.display = 'none';
            overlay.classList.add('active');
            document.body.style.overflow = 'hidden';
            initAdventureGame();
        }

        let pollingActive = true;
        waitingPollingInterval = setInterval(async () => {
            if (!pollingActive) return;
            if (isMobileDevice) {
                updateMobileClock();
            } else if (currentLobbyMode === 'simple') {
                updateSimpleClock();
            }

            try {
                const response = await fetch('/api/exam/status?examId=<?= $examId ?>');
                const res = await response.json();
                if (res.examStatus === 'Started' && pollingActive) {
                    pollingActive = false;
                    clearInterval(waitingPollingInterval);
                    startCountdown(5, () => {
                        stopAdventureGame();
                        window.location.href = '/exam';
                    });
                }
            } catch (err) {
                console.error("Failed to check status", err);
            }
        }, 1000);
    }

    function updateMobileClock() {
        const now = new Date();
        const timeStr = now.toLocaleTimeString('th-TH', { hour12: false });
        const timeEl = document.getElementById('mobileDigitalTime');
        if (timeEl) timeEl.textContent = timeStr;

        const diff = Math.floor((now - waitingStartTime) / 1000);
        const mins = Math.floor(diff / 60);
        const secs = diff % 60;
        const durationEl = document.getElementById('mobileWaitingTime');
        if (durationEl) durationEl.textContent = `รอมาแล้ว: ${mins} นาที ${secs} วินาที`;
    }

    function startCountdown(seconds, callback) {
        const el = document.getElementById('countdownOverlay');
        const numEl = document.getElementById('countdownNum');
        el.classList.add('active');
        let left = seconds;
        numEl.textContent = left;

        const tick = setInterval(() => {
            left--;
            if (left <= 0) {
                clearInterval(tick);
                el.classList.remove('active');
                callback();
                return;
            }
            numEl.textContent = left;
        }, 1000);
    }

    // Game Logic
    let canvas, ctx, animationId;
    let player = { 
        x: 100, y: 100, 
        vx: 0, vy: 0, 
        angle: 0, 
        size: 20, 
        speed: 0.35, 
        friction: 0.96, 
        color: '#ec4899' 
    };
    let otherPlayers = {};
    let bullets = [];
    let asteroids = [];
    let particles = [];
    let stars = [];
    let score = 0;
    let keys = {};
    let lastFireTime = 0;
    const FIRE_COOLDOWN = 180; // ms

    function initAdventureGame() {
        canvas = document.getElementById('gameCanvas');
        if (!canvas) return;
        ctx = canvas.getContext('2d');

        function doResize() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            initStars();
        }
        doResize();
        window.addEventListener('resize', doResize);

        player.x = Math.random() * (canvas.width - 200) + 100;
        player.y = Math.random() * (canvas.height - 200) + 100;

        window.addEventListener('keydown', e => { keys[e.code] = true; });
        window.addEventListener('keyup', e => { keys[e.code] = false; });
        
        // Shoot on mouse click
        window.addEventListener('mousedown', () => { fireBullet(); });

        syncWithServer();
        syncInterval = setInterval(syncWithServer, 500);

        spawnAsteroids(8);
        gameLoop();
    }

    function initStars() {
        stars = [];
        const count = Math.floor((canvas.width * canvas.height) / 8000);
        for (let i = 0; i < count; i++) {
            stars.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                size: Math.random() * 2,
                twinkleSpeed: 0.02 + Math.random() * 0.05,
                alpha: Math.random()
            });
        }
    }

    function spawnAsteroids(count) {
        for (let i = 0; i < count; i++) {
            asteroids.push(createAsteroid());
        }
    }

    function createAsteroid(x, y, radius) {
        const rad = radius || 20 + Math.random() * 30;
        return {
            x: x !== undefined ? x : (Math.random() < 0.5 ? -rad : canvas.width + rad),
            y: y !== undefined ? y : Math.random() * canvas.height,
            vx: (Math.random() - 0.5) * 1.5,
            vy: (Math.random() - 0.5) * 1.5,
            radius: rad,
            points: Math.floor(rad / 5),
            angle: Math.random() * Math.PI * 2,
            rotSpeed: (Math.random() - 0.5) * 0.02,
            vertices: Math.floor(8 + Math.random() * 5)
        };
    }

    function createExplosion(x, y, color, count = 12) {
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = 1 + Math.random() * 4;
            particles.push({
                x: x,
                y: y,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                radius: 1.5 + Math.random() * 2,
                color: color,
                alpha: 1,
                decay: 0.015 + Math.random() * 0.02
            });
        }
    }

    function fireBullet() {
        const now = Date.now();
        if (now - lastFireTime < FIRE_COOLDOWN) return;
        lastFireTime = now;

        // Fire in direction player is facing (derived from velocity, default pointing up)
        let fireAngle = player.angle;
        
        const bulletSpeed = 10;
        bullets.push({
            x: player.x,
            y: player.y,
            vx: Math.cos(fireAngle) * bulletSpeed + player.vx * 0.5,
            vy: Math.sin(fireAngle) * bulletSpeed + player.vy * 0.5,
            radius: 2.5,
            color: '#38bdf8',
            life: 60
        });
    }

    async function syncWithServer() {
        const formData = new FormData();
        formData.append('x', Math.floor(player.x));
        formData.append('y', Math.floor(player.y));
        formData.append('score', score);

        try {
            const response = await fetch('/api/lobby/sync', {
                method: 'POST',
                body: formData
            });
            const res = await response.json();
            
            if (res.redirect) {
                clearInterval(syncInterval);
                if (typeof waitingPollingInterval !== 'undefined') clearInterval(waitingPollingInterval);
                stopAdventureGame();
                window.location.href = '/';
                return;
            }

            // Sync Lobby Mode dynamically from teacher's setting
            if (res.success && res.lobby_mode) {
                if (res.lobby_mode !== currentLobbyMode) {
                    toggleLobbyMode(res.lobby_mode);
                }
            }

            if (res.success && res.players) {
                const newPlayersMap = {};
                res.players.forEach(p => {
                    if (p.email !== studentEmail) {
                        const existing = otherPlayers[p.email];
                        let history = existing && existing.history ? existing.history : [];
                        
                        // Push new position if it changed or history is empty
                        const lastEntry = history[history.length - 1];
                        if (!lastEntry || lastEntry.x !== p.x || lastEntry.y !== p.y) {
                            history.push({ x: p.x, y: p.y, time: Date.now() });
                            if (history.length > 8) {
                                history.shift();
                            }
                        }
                        
                        newPlayersMap[p.email] = {
                            name: p.name,
                            targetX: p.x,
                            targetY: p.y,
                            x: existing ? existing.x : p.x,
                            y: existing ? existing.y : p.y,
                            angle: existing ? existing.angle : 0,
                            history: history
                        };
                    }
                });
                otherPlayers = newPlayersMap;

                // Update Simple Mode List
                const simpleGrid = document.getElementById('simplePlayersGrid');
                const simpleCount = document.getElementById('simplePlayerCount');
                if (simpleGrid && simpleCount) {
                    simpleCount.textContent = res.players.length;
                    
                    let simpleHtml = `
                        <div class="px-3 py-2 bg-pink-500/10 text-pink-400 border border-pink-500/20 rounded-xl text-xs font-bold truncate flex items-center gap-1.5 justify-center">
                          <span>👑</span> <span class="truncate">${studentName} (ฉัน)</span>
                        </div>
                    `;
                    res.players.forEach(p => {
                        if (p.name !== studentName) {
                            simpleHtml += `
                                <div class="px-3 py-2 bg-white/5 text-slate-350 border border-white/5 rounded-xl text-xs font-bold truncate flex items-center gap-1.5 justify-center">
                                  <span>👤</span> <span class="truncate">${p.name} (ม.${p.room || ''})</span>
                                </div>
                            `;
                        }
                    });
                    simpleGrid.innerHTML = simpleHtml;
                }
            }

            // Render Leaderboard
            if (res.success && res.leaderboard) {
                const boardContainer = document.getElementById('leaderboardList');
                if (boardContainer) {
                    let html = '';
                    res.leaderboard.forEach((item, index) => {
                        const rank = index + 1;
                        let rankBadge = `${rank}`;
                        if (rank === 1) rankBadge = '🥇';
                        else if (rank === 2) rankBadge = '🥈';
                        else if (rank === 3) rankBadge = '🥉';

                        const selfClass = item.isSelf ? 'text-pink-400 bg-pink-500/10 border border-pink-500/20' : 'text-slate-300 bg-white/5 border border-transparent';
                        
                        html += `
                            <div class="flex items-center justify-between px-2.5 py-1.5 rounded-lg ${selfClass} transition-all">
                                <div class="flex items-center gap-1.5 truncate">
                                    <span class="w-5 text-center">${rankBadge}</span>
                                    <span class="truncate">${item.name}</span>
                                </div>
                                <span class="font-mono text-sky-400 text-[10px]">${item.score} pts</span>
                            </div>
                        `;
                    });
                    boardContainer.innerHTML = html || '<div class="text-center text-slate-500 py-4">ไม่มีผู้เล่นขณะนี้</div>';
                }
            }
        } catch (err) {
            console.error("Sync error", err);
        }
    }

    function stopAdventureGame() {
        cancelAnimationFrame(animationId);
        clearInterval(syncInterval);
        document.getElementById('waitingRoomOverlay').classList.remove('active');
        document.body.style.overflow = '';
    }

    function gameLoop() {
        update();
        draw();
        animationId = requestAnimationFrame(gameLoop);
    }

    function update() {
        // Spaceship movement inputs
        let ax = 0;
        let ay = 0;
        if (keys['ArrowUp'] || keys['KeyW']) {
            ax = Math.cos(player.angle) * player.speed;
            ay = Math.sin(player.angle) * player.speed;
            // Spawn engine thruster particles
            if (Math.random() < 0.4) {
                particles.push({
                    x: player.x - Math.cos(player.angle) * 12,
                    y: player.y - Math.sin(player.angle) * 12,
                    vx: -Math.cos(player.angle) * 2 + (Math.random() - 0.5),
                    vy: -Math.sin(player.angle) * 2 + (Math.random() - 0.5),
                    radius: 2 + Math.random() * 2,
                    color: '#f43f5e',
                    alpha: 0.8,
                    decay: 0.03
                });
            }
        }
        
        // Rotation inputs
        if (keys['ArrowLeft'] || keys['KeyA']) player.angle -= 0.07;
        if (keys['ArrowRight'] || keys['KeyD']) player.angle += 0.07;

        if (keys['Space']) {
            fireBullet();
        }

        // Apply acceleration & physics friction
        player.vx += ax;
        player.vy += ay;
        player.vx *= player.friction;
        player.vy *= player.friction;
        player.x += player.vx;
        player.y += player.vy;

        // Screen boundary wrapping for spaceship
        if (player.x < 0) player.x = canvas.width;
        if (player.x > canvas.width) player.x = 0;
        if (player.y < 0) player.y = canvas.height;
        if (player.y > canvas.height) player.y = 0;

        // Update Bullets
        bullets.forEach((b, index) => {
            b.x += b.vx;
            b.y += b.vy;
            b.life--;
            if (b.life <= 0) {
                bullets.splice(index, 1);
            }
        });

        // Update Asteroids
        asteroids.forEach((ast, index) => {
            ast.x += ast.vx;
            ast.y += ast.vy;
            ast.angle += ast.rotSpeed;

            // Wrap around edges
            if (ast.x < -ast.radius) ast.x = canvas.width + ast.radius;
            if (ast.x > canvas.width + ast.radius) ast.x = -ast.radius;
            if (ast.y < -ast.radius) ast.y = canvas.height + ast.radius;
            if (ast.y > canvas.height + ast.radius) ast.y = -ast.radius;

            // Collision check with bullets
            bullets.forEach((bullet, bIndex) => {
                const dx = bullet.x - ast.x;
                const dy = bullet.y - ast.y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                if (dist < ast.radius) {
                    // Remove bullet
                    bullets.splice(bIndex, 1);
                    
                    // Trigger explosion particles
                    createExplosion(ast.x, ast.y, '#f59e0b', 15);

                    // Break into smaller ones
                    if (ast.radius > 15) {
                        asteroids.push(createAsteroid(ast.x, ast.y, ast.radius * 0.5));
                        asteroids.push(createAsteroid(ast.x, ast.y, ast.radius * 0.5));
                    }
                    
                    // Remove asteroid and add score
                    asteroids.splice(index, 1);
                    score += 10;
                    document.getElementById('pixelsCollected').textContent = score;

                    // Ensure minimum count
                    if (asteroids.length < 5) {
                        spawnAsteroids(1);
                    }
                }
            });
        });

        // Update Particles
        particles.forEach((p, index) => {
            p.x += p.vx;
            p.y += p.vy;
            p.alpha -= p.decay;
            if (p.alpha <= 0) {
                particles.splice(index, 1);
            }
        });

        // Update Stars
        stars.forEach(s => {
            s.alpha += s.twinkleSpeed;
            if (s.alpha > 1 || s.alpha < 0.1) {
                s.twinkleSpeed = -s.twinkleSpeed;
            }
        });

        // Update Other Players (Smooth movement + calculate angle)
        const renderTime = Date.now() - 700; // Render 700ms in the past (slightly more than 500ms sync interval)
        for (let email in otherPlayers) {
            let p = otherPlayers[email];
            const oldX = p.x;
            const oldY = p.y;
            let interpolated = false;

            if (p.history && p.history.length >= 2) {
                // Find two points A and B where A.time <= renderTime < B.time
                let a = null;
                let b = null;
                for (let i = 0; i < p.history.length - 1; i++) {
                    if (p.history[i].time <= renderTime && p.history[i+1].time > renderTime) {
                        a = p.history[i];
                        b = p.history[i+1];
                        break;
                    }
                }

                if (a && b) {
                    // Prevent crazy interpolation across screen boundaries (edge wrapping)
                    if (Math.abs(b.x - a.x) > canvas.width / 2 || Math.abs(b.y - a.y) > canvas.height / 2) {
                        p.x = b.x;
                        p.y = b.y;
                    } else {
                        const t = (renderTime - a.time) / (b.time - a.time);
                        p.x = a.x + (b.x - a.x) * t;
                        p.y = a.y + (b.y - a.y) * t;
                    }
                    interpolated = true;
                } else if (p.history[p.history.length - 1].time <= renderTime) {
                    // Fallback to lerping if buffer is starved
                    p.x += (p.targetX - p.x) * 0.1;
                    p.y += (p.targetY - p.y) * 0.1;
                    interpolated = true;
                }
            }

            if (!interpolated) {
                p.x += (p.targetX - p.x) * 0.1;
                p.y += (p.targetY - p.y) * 0.1;
            }
            
            // Wrap ship boundaries
            if (p.x < 0) p.x = canvas.width;
            if (p.x > canvas.width) p.x = 0;
            if (p.y < 0) p.y = canvas.height;
            if (p.y > canvas.height) p.y = 0;

            const dx = p.x - oldX;
            const dy = p.y - oldY;
            if (Math.sqrt(dx*dx + dy*dy) > 0.5) {
                p.angle = Math.atan2(dy, dx);
            }
        }
    }

    function draw() {
        // Deep space background
        ctx.fillStyle = '#080c14';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Draw Stars
        stars.forEach(s => {
            ctx.fillStyle = `rgba(255, 255, 255, ${s.alpha})`;
            ctx.fillRect(s.x, s.y, s.size, s.size);
        });

        // Draw Asteroids
        asteroids.forEach(ast => {
            ctx.strokeStyle = '#94a3b8';
            ctx.lineWidth = 2;
            ctx.fillStyle = '#1e293b';
            ctx.beginPath();
            
            for (let i = 0; i < ast.vertices; i++) {
                const angle = ast.angle + (i / ast.vertices) * Math.PI * 2;
                const offset = (Math.sin(i * 1.7) * 0.15 + 0.85); // Crater irregularity
                const r = ast.radius * offset;
                const x = ast.x + Math.cos(angle) * r;
                const y = ast.y + Math.sin(angle) * r;
                if (i === 0) ctx.moveTo(x, y);
                else ctx.lineTo(x, y);
            }
            ctx.closePath();
            ctx.fill();
            ctx.stroke();
        });

        // Draw Bullets
        bullets.forEach(b => {
            ctx.shadowColor = b.color;
            ctx.shadowBlur = 8;
            ctx.fillStyle = b.color;
            ctx.beginPath();
            ctx.arc(b.x, b.y, b.radius, 0, Math.PI * 2);
            ctx.fill();
        });
        ctx.shadowBlur = 0; // Reset shadow

        // Draw Particles
        particles.forEach(p => {
            ctx.fillStyle = p.color;
            ctx.globalAlpha = p.alpha;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
            ctx.fill();
        });
        ctx.globalAlpha = 1.0; // Reset alpha

        // Draw Other Players
        for (let email in otherPlayers) {
            let p = otherPlayers[email];
            drawSpaceship(p.x, p.y, p.angle, '#0ea5e9', p.name);
        }

        // Draw My Spaceship
        drawSpaceship(player.x, player.y, player.angle, player.color, 'ME');
    }

    function drawSpaceship(x, y, angle, color, label) {
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(angle);

        // Glowing Engine flame if thrusting (handled color-wise)
        ctx.shadowColor = color;
        ctx.shadowBlur = 12;

        // Draw Spaceship Triangle Shape
        ctx.fillStyle = color;
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(12, 0);       // Nose
        ctx.lineTo(-8, -8);     // Bottom Left
        ctx.lineTo(-4, 0);      // Inner back
        ctx.lineTo(-8, 8);      // Bottom Right
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        ctx.restore();

        // Draw Label above ship
        ctx.save();
        const lw = ctx.measureText(label).width + 12;
        ctx.fillStyle = 'rgba(0,0,0,0.6)';
        ctx.fillRect(x - lw/2, y - 28, lw, 16);
        ctx.fillStyle = 'white';
        ctx.font = 'bold 11px K2D, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(label, x, y - 16);
        ctx.restore();
    }
  </script>
</body>
</html>
