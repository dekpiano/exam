<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>หน้าแรก | <?= esc($websiteName) ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=K2D:wght@400;600;700;800&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            skjPink: '#ec4899',
            skjBlue: '#0ea5e9',
          }
        }
      }
    }
  </script>
  <style>
    html { scroll-behavior: smooth; }
    * { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
    body {
      font-family: 'K2D', sans-serif;
      background: #090d16;
      min-height: 100vh;
      color: #f8fafc;
      overflow-x: hidden;
    }
    .bg-animation {
      position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; z-index: -1;
      overflow: hidden; pointer-events: none;
      background: radial-gradient(circle at center, #111827 0%, #090d16 100%);
    }
    .blob {
      position: absolute; border-radius: 50%; filter: blur(80px); opacity: 0.35;
      animation: move 20s infinite alternate ease-in-out;
    }
    .blob-1 { width: 350px; height: 350px; background: #ec4899; top: -10%; left: -10%; }
    .blob-2 { width: 450px; height: 450px; background: #0ea5e9; bottom: -10%; right: -10%; animation-delay: -7s; }
    @keyframes move { from { transform: translate(0, 0) scale(1); } to { transform: translate(60px, 60px) scale(1.15); } }

    .glass-card {
      background: rgba(255, 255, 255, 0.03);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border: 1px solid rgba(255, 255, 255, 0.08);
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.6);
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .glass-card:hover {
      background: rgba(255, 255, 255, 0.06);
      border-color: rgba(255, 255, 255, 0.15);
      transform: translateY(-4px);
    }

    .input-box {
      width: 100%; background: rgba(0,0,0,0.3); border: 1.5px solid rgba(255,255,255,0.1);
      border-radius: 16px; padding: 0.85rem 1.1rem; color: #fff; font-size: 1rem;
      transition: all 0.3s; outline: none;
    }
    .input-box:focus { border-color: #0ea5e9; background: rgba(0,0,0,0.5); box-shadow: 0 0 0 4px rgba(14, 165, 233, 0.15); }
    
    .btn-pink-blue {
      background: linear-gradient(135deg, #ec4899, #0ea5e9);
      color: white;
      transition: all 0.3s;
      box-shadow: 0 4px 15px rgba(236, 72, 153, 0.3);
    }
    .btn-pink-blue:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(236, 72, 153, 0.5);
    }
    .btn-pink-blue:active {
      transform: scale(0.98);
    }

    /* Modal Animation */
    .modal-overlay {
      transition: opacity 0.3s ease-in-out;
      pointer-events: none;
      opacity: 0;
    }
    .modal-overlay.active {
      pointer-events: auto;
      opacity: 1;
    }
    .modal-content {
      transform: scale(0.9) translateY(20px);
      transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    }
    .modal-overlay.active .modal-content {
      transform: scale(1) translateY(0);
    }
  </style>
</head>
<body class="py-8 px-4 sm:px-6 lg:px-8 relative">
  <div class="bg-animation"><div class="blob blob-1"></div><div class="blob blob-2"></div></div>

  <!-- Teacher Entry Button (Top Right) -->
  <div class="absolute top-4 right-4 sm:top-6 sm:right-8 z-40">
    <a href="/teacher" class="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-xs font-bold text-slate-300 hover:text-white transition-all flex items-center gap-1.5 backdrop-blur-md">
      👨‍🏫 สำหรับครูผู้สอน
    </a>
  </div>

  <!-- Container -->
  <div class="max-w-7xl mx-auto">
    
    <!-- Top Header -->
    <header class="flex flex-col items-center text-center mb-12 animate-fadeIn">
      <?php if (!empty($logoUrl)): ?>
        <img src="<?= esc($logoUrl) ?>" alt="logo" class="h-20 mb-4 drop-shadow-[0_0_15px_rgba(14,165,233,0.3)]">
      <?php else: ?>
        <div class="h-20 w-20 rounded-full bg-gradient-to-tr from-skjPink to-skjBlue flex items-center justify-center text-white text-3xl font-black mb-4 shadow-lg shadow-skjPink/20">SKJ</div>
      <?php endif; ?>
      <h1 class="text-3xl sm:text-4xl font-extrabold tracking-tight bg-gradient-to-r from-skjPink via-purple-400 to-skjBlue bg-clip-text text-transparent mb-2"><?= esc($websiteName) ?></h1>
      <p class="text-slate-400 text-sm sm:text-base max-w-xl">ยินดีต้อนรับเข้าสู่ระบบทดสอบออนไลน์ โรงเรียนสวนกุหลาบวิทยาลัย จิรประวัติ นครสวรรค์ กรุณาเลือกรายวิชาด้านล่างเพื่อเริ่มทำข้อสอบ</p>
    </header>

    <!-- Filters Section -->
    <section class="mb-8 space-y-4">
      <div class="flex flex-col md:flex-row gap-4 justify-between items-center bg-white/5 border border-white/10 p-4 rounded-3xl backdrop-blur-md">
        <!-- Search -->
        <div class="relative w-full md:max-w-md">
          <span class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <svg class="h-5 w-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
          </span>
          <input type="text" id="searchInput" oninput="filterExams()" class="w-full pl-10 pr-4 py-2.5 bg-black/30 border border-white/10 rounded-2xl text-sm focus:outline-none focus:border-skjBlue text-white placeholder-slate-500 transition-all" placeholder="ค้นหาชื่อวิชา, รหัสวิชา หรือชื่อครูผู้สอน...">
        </div>
        
        <!-- Learning Area Filters (Select / Desktop pills) -->
        <div class="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 scrollbar-none">
          <button onclick="setLearningArea('All')" class="area-btn active px-4 py-2 rounded-2xl text-xs font-bold transition-all border border-skjPink bg-skjPink text-white shadow-lg shadow-skjPink/15">ทั้งหมด</button>
          <?php 
          $areas = ['คณิตศาสตร์', 'วิทยาศาสตร์และเทคโนโลยี', 'ภาษาไทย', 'ภาษาต่างประเทศ', 'สังคมศึกษาฯ', 'สุขศึกษาฯ', 'ศิลปะ', 'การงานอาชีพ'];
          foreach ($areas as $a): 
          ?>
            <button onclick="setLearningArea('<?= $a ?>')" class="area-btn px-4 py-2 rounded-2xl text-xs font-bold transition-all border border-white/10 bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white"><?= $a ?></button>
          <?php endforeach; ?>
        </div>
      </div>
    </section>

    <!-- Exams Grid -->
    <main>
      <div id="examsGrid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php if (empty($exams)): ?>
          <div class="col-span-full text-center py-20 bg-white/5 border border-white/10 rounded-3xl">
            <span class="text-5xl">📭</span>
            <p class="text-slate-400 font-bold mt-4">ยังไม่มีรายวิชาเปิดสอบในขณะนี้</p>
          </div>
        <?php else: ?>
          <?php foreach ($exams as $exam): ?>
            <div class="exam-card glass-card rounded-[32px] p-6 flex flex-col justify-between" 
                 data-subject-name="<?= esc($exam['subject_name']) ?>"
                 data-subject-code="<?= esc($exam['subject_code']) ?>"
                 data-teacher-name="<?= esc($exam['teacher_name']) ?>"
                 data-learning-area="<?= esc($exam['learning_area']) ?>">
              
              <div>
                <!-- Badge Group -->
                <div class="flex justify-between items-center mb-4">
                  <span class="px-3 py-1 bg-white/5 border border-white/10 text-slate-300 rounded-full text-[10px] font-bold">
                    📚 <?= esc($exam['learning_area']) ?>
                  </span>
                  
                  <?php if ($exam['exam_status'] === 'Started'): ?>
                    <span class="flex items-center gap-1.5 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-full text-[10px] font-bold">
                      <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                      กำลังสอบ
                    </span>
                  <?php elseif ($exam['exam_status'] === 'Finished'): ?>
                    <span class="px-3 py-1 bg-rose-500/10 border border-rose-500/20 text-rose-400 rounded-full text-[10px] font-bold">
                      เสร็จสิ้นการสอบ
                    </span>
                  <?php else: ?>
                    <span class="px-3 py-1 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-full text-[10px] font-bold">
                      รอเข้าห้องสอบ
                    </span>
                  <?php endif; ?>
                </div>

                <!-- Subject Info -->
                <h3 class="text-lg font-black text-white leading-snug mb-1 line-clamp-2"><?= esc($exam['subject_name']) ?></h3>
                <p class="text-skjBlue font-extrabold text-xs mb-4">รหัสวิชา: <?= esc($exam['subject_code']) ?> &nbsp;|&nbsp; <?= esc($exam['exam_type']) ?><?php if(!empty($exam['academic_year']) || !empty($exam['semester'])): ?> &nbsp;|&nbsp; ปีการศึกษา: <?= esc($exam['academic_year']) ?>/<?= esc($exam['semester']) ?><?php endif; ?></p>
                
                <!-- Additional detail info -->
                <div class="space-y-1.5 border-t border-white/5 pt-4 mb-6">
                  <div class="flex items-center justify-between text-xs text-slate-400">
                    <span>👨‍🏫 ครูผู้สอน:</span>
                    <span class="font-bold text-slate-200"><?= esc($exam['teacher_name']) ?></span>
                  </div>
                  <div class="flex items-center justify-between text-xs text-slate-400">
                    <span>⏱️ เวลาทำปรนัย / อัตนัย:</span>
                    <span class="font-bold text-slate-200"><?= esc($exam['time_limit_choice']) ?> / <?= esc($exam['time_limit_writing']) ?> วินาที</span>
                  </div>
                  <div class="flex items-center justify-between text-xs text-slate-400">
                    <span>⏳ เวลาทำข้อสอบรวม:</span>
                    <span class="font-bold text-slate-200"><?= (empty($exam['exam_duration']) || (int)$exam['exam_duration'] === 0) ? 'ไม่จำกัดเวลา' : esc($exam['exam_duration']) . ' นาที' ?></span>
                  </div>
                  <div class="flex items-center justify-between text-xs text-slate-400">
                    <span>📝 จำนวนข้อสอบ:</span>
                    <span class="font-bold text-slate-200"><?= esc($exam['num_questions']) ?> ข้อ</span>
                  </div>
                </div>
              </div>

              <!-- Action Button -->
              <div>
                <?php if ($exam['exam_status'] === 'Finished'): ?>
                  <button disabled class="w-full py-3.5 bg-white/5 border border-white/5 text-slate-500 font-extrabold rounded-2xl text-sm cursor-not-allowed">
                    ปิดระบบเข้าสอบ 🔒
                  </button>
                <?php else: ?>
                  <div class="flex gap-2">
                    <button onclick="openRegisterModal('<?= esc($exam['id']) ?>', '<?= esc($exam['subject_name']) ?>', '<?= esc($exam['teacher_name']) ?>')" 
                            class="flex-1 py-3.5 btn-pink-blue font-extrabold rounded-2xl text-sm flex items-center justify-center gap-2">
                      เข้าห้องสอบ 🚀
                    </button>
                    <button onclick="openShareModal('<?= esc($exam['id']) ?>', '<?= esc($exam['subject_name']) ?>')" 
                            class="px-4 py-3.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-slate-350 hover:text-white transition-all flex items-center justify-center shadow-lg cursor-pointer"
                            title="แชร์ลิงก์ / QR Code">
                      🔗
                    </button>
                  </div>
                <?php endif; ?>
              </div>

            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </main>

  </div>

  <!-- Share Modal -->
  <div id="shareModal" class="modal-overlay fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
    <div class="modal-content glass-card w-full max-w-md rounded-[32px] p-8 border border-white/10 relative text-center">
      
      <!-- Close Button -->
      <button onclick="closeShareModal()" class="absolute top-6 right-6 text-slate-400 hover:text-white transition-colors cursor-pointer">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
      </button>

      <!-- Modal Header -->
      <div class="mb-4">
        <span class="px-3.5 py-1.5 bg-skjBlue/10 text-skjBlue rounded-full text-xs font-black uppercase tracking-widest border border-skjBlue/20 mb-3 inline-block">ลิงก์เข้าสอบ & QR Code</span>
        <h3 id="shareSubjectTitle" class="text-lg font-black text-white leading-tight">วิชา</h3>
      </div>

      <!-- QR Code Image -->
      <div class="bg-white p-4 rounded-3xl w-60 h-60 mx-auto flex items-center justify-center shadow-lg shadow-white/5 mb-4">
        <img id="shareQRCodeImg" src="" alt="QR Code" class="w-full h-full">
      </div>

      <!-- Link Box -->
      <div class="space-y-3">
        <input type="text" id="shareLinkField" class="input-box text-center font-mono text-xs select-all" readonly>
        
        <button onclick="copyShareLink()" class="w-full py-3.5 btn-pink-blue font-extrabold rounded-2xl text-sm flex items-center justify-center gap-2 cursor-pointer">
          📋 คัดลอกลิงก์ส่งให้นักเรียน
        </button>
      </div>

    </div>
  </div>

  <!-- Registration Modal -->
  <div id="registerModal" class="modal-overlay fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
    <div class="modal-content glass-card w-full max-w-md rounded-[32px] p-8 border border-white/10 relative">
      
      <!-- Close Button -->
      <button onclick="closeRegisterModal()" class="absolute top-6 right-6 text-slate-400 hover:text-white transition-colors">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
      </button>

      <!-- Modal Header -->
      <div class="text-center mb-6">
        <span class="px-3.5 py-1.5 bg-skjPink/10 text-skjPink rounded-full text-xs font-black uppercase tracking-widest border border-skjPink/20 mb-3 inline-block">กรอกข้อมูลผู้เข้าสอบ</span>
        <h3 id="modalSubjectTitle" class="text-xl font-black text-white leading-tight">คณิตศาสตร์พื้นฐาน</h3>
        <p id="modalTeacherName" class="text-xs text-slate-500 font-bold mt-1">ครูผู้สอน: ครูสมชาย ใจดี</p>
      </div>

      <!-- Registration Form -->
      <form id="studentInfoForm" action="/api/register" method="POST" class="space-y-4">
        <?= csrf_field() ?>
        <input type="hidden" id="examIdField" name="examId">
        
        <div>
          <label for="studentName" class="text-xs font-black text-skjBlue ml-1 mb-1.5 block uppercase tracking-wider">ชื่อ-นามสกุล</label>
          <input type="text" id="studentName" name="name" class="input-box" placeholder="กรอกชื่อ-นามสกุลของคุณ" required>
        </div>
        
        <div>
          <label for="studentCode" class="text-xs font-black text-skjBlue ml-1 mb-1.5 block uppercase tracking-wider">เลขประจำตัวนักเรียน</label>
          <input type="text" id="studentCode" name="studentCode" class="input-box" placeholder="กรอกเลขประจำตัวนักเรียน" required>
        </div>
        
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label for="studentId" class="text-xs font-black text-skjBlue ml-1 mb-1.5 block uppercase tracking-wider">เลขที่</label>
            <input type="text" id="studentId" name="studentId" class="input-box" placeholder="เช่น 1" required>
          </div>
          <div>
            <label for="studentRoom" class="text-xs font-black text-skjBlue ml-1 mb-1.5 block uppercase tracking-wider">ห้องเรียน</label>
            <input type="text" id="studentRoom" name="studentRoom" class="input-box" placeholder="เช่น 4/1" required>
          </div>
        </div>
        
        <div>
          <label for="studentEmail" class="text-xs font-black text-skjBlue ml-1 mb-1.5 block uppercase tracking-wider">อีเมลของโรงเรียน</label>
          <input type="email" id="studentEmail" name="email" class="input-box" placeholder="yourname@skj.ac.th" required>
        </div>
        
        <button type="submit" class="w-full py-4 btn-pink-blue font-extrabold rounded-2xl text-base shadow-lg mt-6 flex items-center justify-center gap-2">
          ยืนยันลงชื่อเข้าสอบ 🚀
        </button>
      </form>

    </div>
  </div>

  <script>
    let selectedArea = 'All';

    window.onload = () => {
      // Run initial filter to show search placeholder
      filterExams();

      const urlParams = new URLSearchParams(window.location.search);
      const examId = urlParams.get('exam_id');
      if (examId) {
        const cards = document.querySelectorAll('.exam-card');
        let foundCard = null;
        cards.forEach(card => {
          const btn = card.querySelector('button[onclick*="openRegisterModal"]');
          if (btn) {
            const onclickStr = btn.getAttribute('onclick');
            if (onclickStr && onclickStr.includes(examId)) {
              foundCard = card;
            }
          }
        });

        if (foundCard) {
          const subName = foundCard.getAttribute('data-subject-name');
          const teacherName = foundCard.getAttribute('data-teacher-name');
          openRegisterModal(examId, subName, teacherName);
        }
      }
    };

    function openShareModal(examId, subjectName) {
      const link = window.location.origin + '/?exam_id=' + examId;
      document.getElementById('shareSubjectTitle').textContent = subjectName;
      document.getElementById('shareLinkField').value = link;
      document.getElementById('shareQRCodeImg').src = 'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=' + encodeURIComponent(link);
      
      const modal = document.getElementById('shareModal');
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }

    function closeShareModal() {
      const modal = document.getElementById('shareModal');
      modal.classList.remove('active');
      document.body.style.overflow = '';
    }

    function copyShareLink() {
      const copyText = document.getElementById('shareLinkField');
      copyText.select();
      copyText.setSelectionRange(0, 99999);
      navigator.clipboard.writeText(copyText.value).then(() => {
        Swal.fire({
          icon: 'success',
          title: 'คัดลอกลิงก์สำเร็จ',
          text: 'คัดลอกลิงก์เรียบร้อย ส่งให้นักเรียนได้เลย',
          timer: 1500,
          showConfirmButton: false
        });
      }).catch(err => {
        Swal.fire({
          icon: 'error',
          title: 'ล้มเหลว',
          text: 'ไม่สามารถคัดลอกลิงก์ได้โดยอัตโนมัติ กรุณากดคลุมดำและคัดลอกด้วยตนเอง'
        });
      });
    }

    function setLearningArea(area) {
      selectedArea = area;
      
      // Update active button styling
      document.querySelectorAll('.area-btn').forEach(btn => {
        if (btn.textContent.trim() === area || (area === 'All' && btn.textContent.trim() === 'ทั้งหมด')) {
          btn.className = "area-btn px-4 py-2 rounded-2xl text-xs font-bold transition-all border border-skjPink bg-skjPink text-white shadow-lg shadow-skjPink/15";
        } else {
          btn.className = "area-btn px-4 py-2 rounded-2xl text-xs font-bold transition-all border border-white/10 bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white";
        }
      });
      
      filterExams();
    }

    function filterExams() {
      const searchVal = document.getElementById('searchInput').value.toLowerCase().trim();
      const cards = document.querySelectorAll('.exam-card');
      let visibleCount = 0;

      const isSearchActive = searchVal.length > 0 || selectedArea !== 'All';

      cards.forEach(card => {
        if (!isSearchActive) {
          card.style.display = 'none';
          return;
        }

        const subName = card.getAttribute('data-subject-name').toLowerCase();
        const subCode = card.getAttribute('data-subject-code').toLowerCase();
        const teacher = card.getAttribute('data-teacher-name').toLowerCase();
        const area = card.getAttribute('data-learning-area');

        const matchesSearch = subName.includes(searchVal) || subCode.includes(searchVal) || teacher.includes(searchVal);
        const matchesArea = selectedArea === 'All' || area === selectedArea || (selectedArea === 'สังคมศึกษาฯ' && area.includes('สังคมศึกษา')) || (selectedArea === 'วิทยาศาสตร์ฯ' && area.includes('วิทยาศาสตร์'));

        if (matchesSearch && matchesArea) {
          card.style.display = 'flex';
          visibleCount++;
        } else {
          card.style.display = 'none';
        }
      });
      
      // Handle empty filtered list state
      let emptyMsg = document.getElementById('emptyFilteredMessage');
      if (emptyMsg) emptyMsg.remove();

      if (!isSearchActive) {
        emptyMsg = document.createElement('div');
        emptyMsg.id = 'emptyFilteredMessage';
        emptyMsg.className = 'col-span-full text-center py-20 bg-white/3 border border-white/10 rounded-3xl backdrop-blur-md animate-fadeIn';
        emptyMsg.innerHTML = `
          <span class="text-5xl block mb-4">🔍</span>
          <h3 class="text-white font-black text-lg">ค้นหาวิชาสอบของคุณ</h3>
          <p class="text-slate-400 text-sm mt-1 max-w-sm mx-auto">กรุณาพิมพ์ค้นหารายวิชา รหัสวิชา หรือชื่อคุณครูผู้สอน หรือคลิกเลือกกลุ่มสาระการเรียนรู้เพื่อเริ่มสอบ</p>
        `;
        document.getElementById('examsGrid').appendChild(emptyMsg);
      } else if (visibleCount === 0) {
        emptyMsg = document.createElement('div');
        emptyMsg.id = 'emptyFilteredMessage';
        emptyMsg.className = 'col-span-full text-center py-20 bg-white/3 border border-white/10 rounded-3xl';
        emptyMsg.innerHTML = `
          <span class="text-5xl block mb-4">😿</span>
          <h3 class="text-white font-black text-lg">ไม่พบรายวิชาสอบ</h3>
          <p class="text-slate-400 text-sm mt-1">ไม่พบข้อมูลรายวิชาสอบที่ตรงกับคำค้นหาของคุณในขณะนี้</p>
        `;
        document.getElementById('examsGrid').appendChild(emptyMsg);
      }
    }

    // Modal control
    function openRegisterModal(examId, subjectName, teacherName) {
      document.getElementById('examIdField').value = examId;
      document.getElementById('modalSubjectTitle').textContent = subjectName;
      document.getElementById('modalTeacherName').textContent = `ครูผู้สอน: ${teacherName}`;
      
      const modal = document.getElementById('registerModal');
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }

    function closeRegisterModal() {
      const modal = document.getElementById('registerModal');
      modal.classList.remove('active');
      document.body.style.overflow = '';
    }

    // Submit handler
    document.getElementById('studentInfoForm').onsubmit = async (e) => {
        e.preventDefault();
        
        const form = e.target;
        const formData = new FormData(form);

        Swal.fire({
            title: 'กำลังลงทะเบียนเข้าสอบ...',
            allowOutsideClick: false,
            didOpen: () => Swal.showLoading()
        });

        try {
            const response = await fetch(form.action, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });

            const res = await response.json();
            Swal.close();

            if (res.success) {
                if (res.exam_status === 'Started' && res.join_policy === 'anytime') {
                    window.location.href = '/exam';
                } else {
                    window.location.href = '/lobby';
                }
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'ข้อผิดพลาด',
                    text: res.message || 'ไม่สามารถเข้าร่วมวิชาสอบนี้ได้',
                    confirmButtonColor: '#ec4899'
                });
            }
        } catch (error) {
            Swal.close();
            Swal.fire({
                icon: 'error',
                title: 'เกิดข้อผิดพลาด',
                text: 'ไม่สามารถเชื่อมต่อระบบได้ในขณะนี้',
                confirmButtonColor: '#ec4899'
            });
        }
    };
  </script>
</body>
</html>
