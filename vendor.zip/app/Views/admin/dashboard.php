<!DOCTYPE html>
<html lang="th">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ระบบจัดการข้อสอบสำหรับครู | <?= esc($websiteName) ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=K2D:wght@400;600;700;800&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    body {
      font-family: 'K2D', sans-serif;
      background: #090d16;
      color: #f8fafc;
      min-height: 100vh;
      overflow-x: hidden;
    }

    .bg-animation {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      z-index: -1;
      overflow: hidden;
      pointer-events: none;
      background: radial-gradient(circle at center, #111827 0%, #090d16 100%);
    }

    .blob {
      position: absolute;
      border-radius: 50%;
      filter: blur(80px);
      opacity: 0.25;
      animation: move 20s infinite alternate ease-in-out;
    }

    .blob-1 {
      width: 400px;
      height: 400px;
      background: #ec4899;
      top: -10%;
      left: -10%;
    }

    .blob-2 {
      width: 500px;
      height: 500px;
      background: #0ea5e9;
      bottom: -10%;
      right: -10%;
      animation-delay: -7s;
    }

    @keyframes move {
      from {
        transform: translate(0, 0) scale(1);
      }

      to {
        transform: translate(60px, 60px) scale(1.15);
      }
    }

    .glass-panel {
      background: rgba(255, 255, 255, 0.03);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border: 1px solid rgba(255, 255, 255, 0.08);
      box-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.5);
    }

    .active-tab {
      background: linear-gradient(135deg, rgba(236, 72, 153, 0.15), rgba(14, 165, 233, 0.15));
      border-left: 4px solid #ec4899;
      color: #ec4899;
    }

    ::-webkit-scrollbar {
      width: 6px;
      height: 6px;
    }

    ::-webkit-scrollbar-track {
      background: rgba(255, 255, 255, 0.02);
    }

    ::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.1);
      border-radius: 10px;
    }

    ::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.2);
    }
  </style>
</head>

<body class="pb-12">
  <div class="bg-animation">
    <div class="blob blob-1"></div>
    <div class="blob blob-2"></div>
  </div>

  <!-- Header -->
  <header class="glass-panel sticky top-0 z-50 px-6 py-4 flex justify-between items-center border-b border-white/5">
    <div class="flex items-center gap-3">
      <?php if (!empty($logoUrl)): ?>
        <img src="<?= esc($logoUrl) ?>" alt="logo" class="h-10">
      <?php else: ?>
        <div
          class="h-10 w-10 rounded-full bg-gradient-to-tr from-pink-500 to-sky-400 flex items-center justify-center text-white text-sm font-black shadow-lg shadow-pink-500/20">
          SKJ</div>
      <?php endif; ?>
      <div>
        <h1 class="font-extrabold text-lg bg-gradient-to-r from-pink-500 to-sky-400 bg-clip-text text-transparent">
          <?= esc($websiteName) ?>
        </h1>
        <p class="text-xs text-slate-400">ระบบจัดการข้อสอบสำหรับครูผู้ควบคุม (Teacher Portal)</p>
      </div>
    </div>
    <div class="flex items-center gap-4">
      <div class="text-right hidden sm:block">
        <p class="text-sm font-bold text-slate-200"><?= esc($teacherName) ?></p>
        <p class="text-[10px] text-sky-400 font-bold uppercase tracking-wider">ผู้ตรวจสอบระดับโรงเรียน</p>
      </div>
      <button onclick="logout()"
        class="px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 font-bold rounded-xl text-sm border border-red-500/20 transition-all">
        ออกจากระบบ 🚪
      </button>
    </div>
  </header>

  <main class="max-w-full mx-auto px-4 sm:px-8 lg:px-12 mt-8">

    <!-- TIER 1: LOBBY SCREEN (Subject Cards & Lobby overview) -->
    <div id="lobby-screen" class="space-y-6">
      <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 class="text-2xl font-black text-white">🏫 รายวิชาสอบทั้งหมดของคุณครู</h2>
          <p class="text-xs text-slate-400">เลือกการ์ดวิชาด้านล่างเพื่อเข้าสู่เมนู คลังข้อสอบ ล็อบบี้การสอบ
            หรือดูผลคะแนน</p>
        </div>
        <div class="flex gap-2 w-full sm:w-auto">
          <button onclick="openExamModal()"
            class="w-full sm:w-auto px-5 py-3 bg-pink-500 hover:bg-pink-600 text-white font-bold rounded-xl text-xs transition-all shadow-lg shadow-pink-500/20 flex items-center justify-center gap-2">
            ➕ เพิ่มวิชาสอบใหม่
          </button>
          <a href="/teacher/settings"
            class="w-full sm:w-auto px-5 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs transition-all border border-white/5 flex items-center justify-center gap-2">
            ⚙️ ตั้งค่าส่วนกลาง
          </a>
        </div>
      </div>

      <!-- Grid of Subject Cards -->
      <div id="exam-cards-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-4">
        <!-- Populated dynamically via JS -->
      </div>
    </div>

    <!-- TIER 2: WORKSPACE SCREEN (When a subject is selected) -->
    <div id="workspace-screen" class="hidden grid grid-cols-1 lg:grid-cols-6 gap-6">

      <!-- Left Navigation Menu -->
      <div class="lg:col-span-1">
        <div class="glass-panel rounded-2xl p-4 flex flex-col gap-2 border border-white/5">

          <!-- Active Subject Card Header -->
          <div
            class="p-4 mb-2 bg-gradient-to-tr from-pink-500/10 to-sky-400/10 border border-pink-500/10 rounded-xl relative">
            <span id="workspace-subject-code" class="text-xs text-pink-400 font-bold block">CODE</span>
            <h4 id="workspace-subject-name" class="text-sm font-bold text-white truncate">SUBJECT NAME</h4>
            <div class="flex items-center justify-between mt-2 pt-2 border-t border-white/5">
              <span id="workspace-subject-status"
                class="px-2 py-0.5 text-[10px] font-bold rounded bg-slate-500/10 text-slate-400 border border-slate-500/20">Waiting</span>
              <span id="workspace-subject-area" class="text-[10px] text-slate-400 font-bold">Area</span>
            </div>
          </div>

          <p class="text-[10px] font-black text-slate-500 uppercase tracking-widest px-3 mb-1">เมนูการจัดการ</p>
          <?php if (isset($activeExamId) && $activeExamId !== '' && $activeExamId !== 'global'): ?>
            <a href="/teacher/questions?exam_id=<?= esc($activeExamId) ?>" id="tab-btn-questions"
              class="w-full text-left px-4 py-3 rounded-xl font-bold text-sm text-slate-350 hover:bg-white/5 transition-all flex items-center gap-2">
              📝 คลังข้อสอบรายวิชา
            </a>
            <a href="/teacher/monitor?exam_id=<?= esc($activeExamId) ?>" id="tab-btn-monitor"
              class="w-full text-left px-4 py-3 rounded-xl font-bold text-sm text-slate-300 hover:bg-white/5 transition-all flex items-center gap-2">
              🖥️ จอภาพควบคุม (Lobby)
            </a>
            <a href="/teacher/results?exam_id=<?= esc($activeExamId) ?>" id="tab-btn-results"
              class="w-full text-left px-4 py-3 rounded-xl font-bold text-sm text-slate-300 hover:bg-white/5 transition-all flex items-center gap-2">
              📊 ผลสอบและตรวจอัตนัย
            </a>
            <a href="/teacher/logs?exam_id=<?= esc($activeExamId) ?>" id="tab-btn-logs"
              class="w-full text-left px-4 py-3 rounded-xl font-bold text-sm text-slate-300 hover:bg-white/5 transition-all flex items-center gap-2">
              🚨 บันทึกความเสี่ยง/ทุจริต
            </a>
            <a href="/teacher/exam-settings?exam_id=<?= esc($activeExamId) ?>" id="tab-btn-exam-settings"
              class="w-full text-left px-4 py-3 rounded-xl font-bold text-sm text-slate-300 hover:bg-white/5 transition-all flex items-center gap-2">
              ⚙️ ตั้งค่าวิชาสอบ
            </a>
          <?php else: ?>
            <a href="/teacher/settings" id="tab-btn-settings"
              class="w-full text-left px-4 py-3 rounded-xl font-bold text-sm text-slate-300 hover:bg-white/5 transition-all flex items-center gap-2">
              ⚙️ ตั้งค่าระบบส่วนกลาง
            </a>
          <?php endif; ?>

          <div class="border-t border-white/5 my-2 pt-2">
            <a href="/teacher/dashboard"
              class="w-full text-left px-4 py-3 bg-slate-900 hover:bg-slate-800 border border-white/5 text-slate-300 font-bold rounded-xl text-sm transition-all flex items-center justify-center gap-2">
              🔙 กลับไปเลือกวิชาอื่น
            </a>
          </div>
        </div>
      </div>

      <!-- Right Content Panel -->
      <div class="lg:col-span-5">

        <!-- SECTION 2: QUESTIONS -->
        <div id="section-questions" class="section-content hidden space-y-6">
          <!-- Header Panel -->
          <div
            class="glass-panel rounded-3xl p-6 border border-white/5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h2 class="text-xl font-black text-white flex items-center gap-2">📝 คลังข้อสอบของรายวิชา</h2>
              <p class="text-xs text-slate-400 mt-1">คลังคำถามแบ่งออกเป็นข้อสอบปรนัย (ตัวเลือก) และข้อสอบอัตนัย
                (เขียนตอบ)</p>
            </div>
            <div class="flex flex-wrap gap-2">
              <button onclick="openQuestionModal()"
                class="px-4 py-2 bg-pink-500 hover:bg-pink-600 text-white font-bold rounded-xl text-xs transition-all shadow-md shadow-pink-500/20">
                ➕ เพิ่มข้อสอบใหม่
              </button>
              <button onclick="openImportModal()"
                class="px-4 py-2 bg-sky-500/10 hover:bg-sky-500/20 text-sky-400 border border-sky-400/25 font-bold rounded-xl text-xs transition-all">
                📥 นำเข้าข้อสอบ
              </button>
              <button onclick="clearAllQuestions()"
                class="px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/25 font-bold rounded-xl text-xs transition-all">
                🗑️ ล้างคำถามทั้งหมด
              </button>
            </div>
          </div>

          <!-- Choice Questions Table Section -->
          <div class="glass-panel rounded-3xl p-6 border border-white/5 space-y-4">
            <h3 class="text-sm font-black text-pink-400 flex items-center gap-2 px-1">🔘 ข้อสอบประเภทปรนัย (Multiple
              Choice)</h3>
            <div class="overflow-x-auto">
              <table class="w-full text-left text-sm border-collapse">
                <thead>
                  <tr class="border-b border-white/10 text-slate-400 text-xs font-bold">
                    <th class="py-3 px-4">คำถาม (โจทย์) และตัวเลือก</th>
                    <th class="py-3 px-4">เฉลย</th>
                    <th class="py-3 px-4 w-24">คะแนน</th>
                    <th class="py-3 px-4 text-right w-36">การจัดการ</th>
                  </tr>
                </thead>
                <tbody id="choice-questions-list" class="divide-y divide-white/5">
                  <!-- Choice questions load here -->
                </tbody>
              </table>
            </div>
          </div>

          <!-- Writing Questions Table Section -->
          <div class="glass-panel rounded-3xl p-6 border border-white/5 space-y-4">
            <h3 class="text-sm font-black text-amber-400 flex items-center gap-2 px-1">📜 ข้อสอบประเภทอัตนัย (Writing /
              Essay)</h3>
            <div class="overflow-x-auto">
              <table class="w-full text-left text-sm border-collapse">
                <thead>
                  <tr class="border-b border-white/10 text-slate-400 text-xs font-bold">
                    <th class="py-3 px-4">คำถาม (โจทย์)</th>
                    <th class="py-3 px-4">แนวคำตอบเฉลย</th>
                    <th class="py-3 px-4 w-24">คะแนน</th>
                    <th class="py-3 px-4 text-right w-36">การจัดการ</th>
                  </tr>
                </thead>
                <tbody id="writing-questions-list" class="divide-y divide-white/5">
                  <!-- Writing questions load here -->
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <!-- SECTION 3: MONITOR -->
        <div id="section-monitor" class="section-content hidden">
          <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

            <!-- LEFT COLUMN: Waiting students list -->
            <div class="lg:col-span-2 glass-panel rounded-3xl p-6 border border-white/5 space-y-4">
              <div class="flex justify-between items-center border-b border-white/5 pb-4">
                <div>
                  <h2 class="text-xl font-black text-white flex items-center gap-2">🖥️ จอภาพควบคุมห้องพักคอย (Lobby)
                  </h2>
                  <p class="text-xs text-slate-400 mt-1">* รายชื่อผู้เข้าสอบที่เข้ามารอสแตนด์บายในห้องพักคอย</p>
                </div>
                <span id="active-players-count"
                  class="px-3 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-bold rounded-full">
                  0 คนกำลังพักคอย
                </span>
              </div>

              <div class="overflow-x-auto">
                <table class="w-full text-left text-sm border-collapse">
                  <thead>
                    <tr class="border-b border-white/10 text-slate-400 text-xs uppercase font-bold">
                      <th class="py-3 px-4">ชื่อ-นามสกุล</th>
                      <th class="py-3 px-4">เลขที่/ห้อง</th>
                      <th class="py-3 px-4">อีเมล</th>
                      <th class="py-3 px-4">สถานะ</th>
                      <th class="py-3 px-4 text-right">ดำเนินการ</th>
                    </tr>
                  </thead>
                  <tbody id="monitor-list" class="divide-y divide-white/5">
                    <!-- Dynamic content -->
                  </tbody>
                </table>
              </div>
            </div>

            <!-- RIGHT COLUMN: Control Cards -->
            <div class="lg:col-span-1 space-y-6">
              <!-- Card 1: Exam Control -->
              <div class="glass-panel rounded-3xl p-6 border border-white/5 space-y-6">
                <div>
                  <h3 class="text-base font-black text-white flex items-center gap-2">⚙️ แผงควบคุมระบบสอบ</h3>
                  <p class="text-xs text-slate-400 mt-1">ใช้ควบคุมสถานะการสอบของรายวิชา</p>
                </div>

                <!-- Status display -->
                <div class="bg-white/5 p-4 rounded-2xl border border-white/5 flex flex-col gap-2">
                  <span
                    class="text-[10px] text-slate-400 font-bold uppercase tracking-wider">สถานะการสอบปัจจุบัน:</span>
                  <div class="flex items-center">
                    <span id="monitor-status-badge"
                      class="px-3 py-1 text-xs font-black rounded-xl transition-all"></span>
                  </div>
                </div>

                <!-- Action Buttons Stack -->
                <div class="flex flex-col gap-3.5">
                  <button onclick="changeExamStatusDirect('Started')"
                    class="w-full py-4 px-6 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-650 active:scale-[0.98] text-white font-black rounded-2xl text-sm transition-all shadow-lg shadow-emerald-500/30 flex items-center justify-center gap-2 hover:scale-[1.02] cursor-pointer">
                    🚀 เริ่มการสอบ (ให้นักเรียนเข้าทำข้อสอบ)
                  </button>
                  <button onclick="changeExamStatusDirect('Finished')"
                    class="w-full py-4 px-6 bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-650 hover:to-rose-650 active:scale-[0.98] text-white font-black rounded-2xl text-sm transition-all shadow-lg shadow-red-500/25 flex items-center justify-center gap-2 hover:scale-[1.02] cursor-pointer">
                    🛑 ปิดการสอบ (ปิดสิทธิ์การเข้าทำข้อสอบ)
                  </button>
                  <button onclick="changeExamStatusDirect('Waiting')"
                    class="w-full py-4 px-6 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-650 active:scale-[0.98] text-white font-black rounded-2xl text-sm transition-all shadow-lg shadow-amber-500/30 flex items-center justify-center gap-2 hover:scale-[1.02] cursor-pointer">
                    ⏳ เปิดพักคอย (พักรอสอบในห้อง Lobby)
                  </button>
                </div>
              </div>

              <!-- Card 2: Lobby Mode Selection -->
              <div class="glass-panel rounded-3xl p-6 border border-white/5 space-y-6">
                <div>
                  <h3 class="text-base font-black text-white flex items-center gap-2">🎮 ตั้งค่าโหมดห้องพักคอย</h3>
                  <p class="text-xs text-slate-400 mt-1">สลับรูปแบบหน้าจอล็อบบี้ระหว่างมินิเกมหรือรายการปกติ</p>
                </div>

                <div class="flex flex-col gap-3.5">
                  <button id="btn-toggle-lobby-mode" onclick="toggleLobbyGameMode()"
                    class="w-full py-4 px-6 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-650 hover:to-rose-650 active:scale-[0.98] text-white font-black rounded-2xl text-sm transition-all shadow-lg shadow-pink-500/30 flex items-center justify-center gap-2 hover:scale-[1.02] cursor-pointer">
                    🎮 โหมดพักคอย: เกมยิงอุกกาบาต
                  </button>
                </div>
              </div>

              <!-- Card 3: Join Policy Selection -->
              <div class="glass-panel rounded-3xl p-6 border border-white/5 space-y-6">
                <div>
                  <h3 class="text-base font-black text-white flex items-center gap-2">🔒 นโยบายการเข้าทำข้อสอบ</h3>
                  <p class="text-xs text-slate-400 mt-1">กำหนดสิทธิ์และกติกาในการลงทะเบียนเข้าสอบของนักเรียน</p>
                </div>

                <div class="flex flex-col gap-3">
                  <button id="btn-policy-anytime" onclick="changeJoinPolicy('anytime')"
                    class="w-full py-3 px-4 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-350 font-bold rounded-2xl text-xs transition-all text-left flex flex-col gap-1 cursor-pointer">
                    <span class="font-extrabold text-white text-sm">⏱️ เริ่มสอบตอนไหนก็ได้ (Anytime)</span>
                    <span class="text-[10px] text-slate-400 font-medium font-sans">นักเรียนเข้าสอบได้ตลอดเวลา ตราบใดที่ระบบเปิดและเวลาสอบไม่หมด</span>
                  </button>
                  <button id="btn-policy-lobby" onclick="changeJoinPolicy('lobby_first')"
                    class="w-full py-3 px-4 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-350 font-bold rounded-2xl text-xs transition-all text-left flex flex-col gap-1 cursor-pointer">
                    <span class="font-extrabold text-white text-sm">🚪 ต้องเข้าห้องรอสอบก่อน (Lobby First)</span>
                    <span class="text-[10px] text-slate-400 font-medium font-sans">ต้องลงทะเบียนเข้ามาสแตนด์บายก่อนครูเริ่มระบบเท่านั้น หากครูกดเริ่มสอบแล้วเด็กใหม่จะเข้าไม่ได้</span>
                  </button>
                </div>
              </div>
            </div>

          </div>
        </div>

        <!-- SECTION 4: RESULTS -->
        <div id="section-results" class="section-content hidden">
          <div class="glass-panel rounded-3xl p-6 border border-white/5">
            <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
              <h2 class="text-xl font-black text-white flex items-center gap-2">📊 ผลการสอบและตรวจคำตอบอัตนัย</h2>
              <div class="flex items-center gap-3">
                <div class="flex items-center gap-2">
                  <span class="text-xs text-slate-400 font-bold">กรองรอบสอบ:</span>
                  <select id="results-filter-round" onchange="filterResultsByRound(this.value)"
                    class="bg-slate-800 border border-white/10 rounded-xl px-3 py-2 text-white font-bold text-xs outline-none focus:border-pink-500">
                    <option value="ALL">แสดงทุกรอบ</option>
                  </select>
                </div>
                <button onclick="printExamResults()"
                  class="px-4 py-2.5 bg-sky-500/10 hover:bg-sky-500 text-sky-400 hover:text-white border border-sky-500/25 hover:border-transparent font-bold rounded-xl text-xs transition-all duration-200 cursor-pointer flex items-center gap-1.5">
                  🖨️ พิมพ์ประกาศผลสอบ
                </button>
              </div>
            </div>

            <div class="overflow-x-auto">
              <table class="w-full text-left text-sm border-collapse">
                <thead>
                  <tr class="border-b border-white/10 text-slate-400 text-xs font-bold">
                    <th class="py-3 px-4">ผู้เข้าสอบ</th>
                    <th class="py-3 px-4">เลขที่/ห้อง</th>
                    <th class="py-3 px-4">คะแนนรวม</th>
                    <th class="py-3 px-4">รอบ</th>
                    <th class="py-3 px-4">เวลาที่ใช้</th>
                    <th class="py-3 px-4">ทุจริต/สลับหน้าจอ</th>
                    <th class="py-3 px-4 text-right">ดำเนินการ</th>
                  </tr>
                </thead>
                <tbody id="results-list" class="divide-y divide-white/5">
                  <!-- Dynamic content -->
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <!-- SECTION 5: LOGS -->
        <div id="section-logs" class="section-content hidden">
          <div class="glass-panel rounded-3xl p-6 border border-white/5">
            <div
              class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-4 border-b border-white/5 mb-6">
              <div>
                <h2 class="text-xl font-black text-white flex items-center gap-2">🚨
                  บันทึกพฤติกรรมเสี่ยงและกิจกรรมน่าสงสัย</h2>
                <p class="text-xs text-slate-400 mt-1">ประวัติการสลับหน้าจอ ออกจากหน้าต่าง หรือเหตุการณ์ผิดปกติอื่นๆ
                  ระหว่างการสอบ</p>
              </div>
              <button type="button" onclick="clearLogs()"
                class="px-4 py-2 bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white rounded-xl text-xs font-bold border border-red-500/20 hover:border-transparent transition-all duration-200 cursor-pointer flex items-center gap-1.5">
                🗑️ ล้างบันทึกความเสี่ยงทั้งหมด
              </button>
            </div>

            <div class="overflow-x-auto">
              <table class="w-full text-left text-sm border-collapse">
                <thead>
                  <tr class="border-b border-white/10 text-slate-400 text-xs font-bold">
                    <th class="py-3 px-4">เวลาประทับ</th>
                    <th class="py-3 px-4">อีเมลนักเรียน</th>
                    <th class="py-3 px-4">กิจกรรมที่เกิดขึ้น</th>
                    <th class="py-3 px-4">ความละเอียด/สเปคเครื่อง</th>
                  </tr>
                </thead>
                <tbody id="logs-list" class="divide-y divide-white/5">
                  <!-- Dynamic content -->
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <!-- SECTION 5.5: EXAM SETTINGS (WORKSPACE SPECIFIC) -->
        <div id="section-exam-settings" class="section-content hidden">
          <div class="glass-panel rounded-3xl p-6 border border-white/5 shadow-xl">
            <div class="mb-6">
              <h2 class="text-xl font-black text-white flex items-center gap-2">⚙️ ตั้งค่ารายวิชาสอบ</h2>
              <p class="text-xs text-slate-400 mt-1">ตั้งค่าชื่อวิชา รหัสวิชา จำนวนข้อสอบ สิทธิ์การทำสอบ
                และเกณฑ์ผ่านรายวิชานี้</p>
            </div>

            <form id="activeExamSettingsForm" class="space-y-6">
              <input type="hidden" name="id" id="workspace-e-id">

              <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label class="block text-xs font-bold text-slate-400 mb-2 uppercase">รหัสวิชา</label>
                  <input type="text" name="subject_code" id="workspace-e-code"
                    class="w-full bg-slate-800/50 border border-white/10 rounded-xl p-3 text-white font-bold outline-none focus:border-pink-500 transition-colors"
                    required placeholder="เช่น ค31101">
                </div>
                <div>
                  <label class="block text-xs font-bold text-slate-400 mb-2 uppercase">ชื่อวิชา</label>
                  <input type="text" name="subject_name" id="workspace-e-name"
                    class="w-full bg-slate-800/50 border border-white/10 rounded-xl p-3 text-white font-bold outline-none focus:border-pink-500 transition-colors"
                    required placeholder="เช่น คณิตศาสตร์พื้นฐาน 1">
                </div>
              </div>

              <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label class="block text-xs font-bold text-slate-400 mb-2 uppercase">ปีการศึกษา</label>
                  <input type="text" name="academic_year" id="workspace-e-year"
                    class="w-full bg-slate-800/50 border border-white/10 rounded-xl p-3 text-white font-bold outline-none focus:border-pink-500 transition-colors"
                    required placeholder="เช่น 2569">
                </div>
                <div>
                  <label class="block text-xs font-bold text-slate-400 mb-2 uppercase">ภาคเรียนที่ (เทอม)</label>
                  <input type="text" name="semester" id="workspace-e-semester"
                    class="w-full bg-slate-800/50 border border-white/10 rounded-xl p-3 text-white font-bold outline-none focus:border-pink-500 transition-colors"
                    required placeholder="เช่น 1 หรือ ฤดูร้อน">
                </div>
              </div>

              <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label class="block text-xs font-bold text-slate-400 mb-2 uppercase">กลุ่มสาระการเรียนรู้</label>
                  <select name="learning_area" id="workspace-e-area"
                    class="w-full bg-slate-800/50 border border-white/10 rounded-xl p-3 text-white font-bold outline-none focus:border-pink-500">
                    <option value="ภาษาไทย">ภาษาไทย</option>
                    <option value="คณิตศาสตร์">คณิตศาสตร์</option>
                    <option value="วิทยาศาสตร์และเทคโนโลยี">วิทยาศาสตร์และเทคโนโลยี</option>
                    <option value="สังคมศึกษา ศาสนา และวัฒนธรรม">สังคมศึกษา ศาสนา และวัฒนธรรม</option>
                    <option value="สุขศึกษา และพลศึกษา">สุขศึกษา และพลศึกษา</option>
                    <option value="ศิลปะ">ศิลปะ</option>
                    <option value="การงานอาชีพ">การงานอาชีพ</option>
                    <option value="ภาษาต่างประเทศ">ภาษาต่างประเทศ</option>
                    <option value="แนะแนว">แนะแนว</option>
                  </select>
                </div>
                <div>
                  <label class="block text-xs font-bold text-slate-400 mb-2 uppercase">สถานะสอบ</label>
                  <select name="exam_status" id="workspace-e-status"
                    class="w-full bg-slate-800/50 border border-white/10 rounded-xl p-3 text-white font-bold outline-none focus:border-pink-500">
                    <option value="Waiting">Waiting (เปิดห้องพักคอย)</option>
                    <option value="Started">Started (เริ่มสอบ/ห้ามลงทะเบียนเพิ่ม)</option>
                    <option value="Finished">Finished (ปิดระบบ/เสร็จสิ้นการสอบ)</option>
                  </select>
                </div>
              </div>

              <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label class="block text-xs font-bold text-slate-400 mb-2 uppercase">จำนวนข้อสอบที่สุ่ม (ข้อ)</label>
                  <input type="number" name="num_questions" id="workspace-e-num"
                    class="w-full bg-slate-800/50 border border-white/10 rounded-xl p-3 text-white font-bold outline-none focus:border-pink-500 transition-colors"
                    required value="20">
                </div>
                <div>
                  <label class="block text-xs font-bold text-slate-400 mb-2 uppercase">สิทธิ์สอบสูงสุด (ครั้ง)</label>
                  <input type="number" name="max_attempts" id="workspace-e-attempts"
                    class="w-full bg-slate-800/50 border border-white/10 rounded-xl p-3 text-white font-bold outline-none focus:border-pink-500 transition-colors"
                    required value="1">
                </div>
                <div>
                  <label class="block text-xs font-bold text-slate-400 mb-2 uppercase">เกณฑ์ผ่าน (%)</label>
                  <input type="number" name="passing_percentage" id="workspace-e-pass"
                    class="w-full bg-slate-800/50 border border-white/10 rounded-xl p-3 text-white font-bold outline-none focus:border-pink-500 transition-colors"
                    required value="50">
                </div>
              </div>

              <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div>
                  <label class="block text-xs font-bold text-slate-400 mb-2 uppercase">เวลาจำกัด ปรนัย
                    (วินาที/ข้อ)</label>
                  <input type="number" name="time_limit_choice" id="workspace-e-time-c"
                    class="w-full bg-slate-800/50 border border-white/10 rounded-xl p-3 text-white font-bold outline-none focus:border-pink-500 transition-colors"
                    required value="60">
                </div>
                <div>
                  <label class="block text-xs font-bold text-slate-400 mb-2 uppercase">เวลาจำกัด อัตนัย
                    (วินาที/ข้อ)</label>
                  <input type="number" name="time_limit_writing" id="workspace-e-time-w"
                    class="w-full bg-slate-800/50 border border-white/10 rounded-xl p-3 text-white font-bold outline-none focus:border-pink-500 transition-colors"
                    required value="300">
                </div>
                <div>
                  <label class="block text-xs font-bold text-sky-400 mb-2 uppercase">เวลาสอบรวม (นาที) [0=ไม่จำกัด]</label>
                  <input type="number" name="exam_duration" id="workspace-e-duration"
                    class="w-full bg-slate-800/50 border border-sky-500/20 rounded-xl p-3 text-white font-bold outline-none focus:border-sky-500 transition-colors"
                    required value="0" placeholder="0 = ไม่จำกัด">
                </div>
                <div>
                  <label class="block text-xs font-bold text-pink-400 mb-2 uppercase">รอบการสอบปัจจุบัน</label>
                  <input type="text" name="exam_round" id="workspace-e-round"
                    class="w-full bg-slate-800/50 border border-pink-500/20 rounded-xl p-3 text-white font-bold outline-none focus:border-pink-500 transition-colors"
                    required value="1" placeholder="เช่น 1, 2, แก้ตัว">
                </div>
              </div>

              <div class="flex justify-end pt-4 border-t border-white/5">
                <button type="submit"
                  class="px-8 py-3.5 bg-gradient-to-r from-pink-500 to-sky-400 hover:scale-[1.02] active:scale-[0.98] transition-all text-white font-black rounded-xl text-sm shadow-lg shadow-pink-500/20 cursor-pointer">
                  💾 บันทึกการตั้งค่าวิชาสอบ
                </button>
              </div>
            </form>
          </div>
        </div>

        <!-- SECTION 6: GLOBAL SETTINGS -->
        <div id="section-settings" class="section-content hidden">
          <div class="glass-panel rounded-3xl p-6 border border-white/5 shadow-xl">
            <div class="flex justify-between items-center mb-6">
              <h2 class="text-xl font-black text-white flex items-center gap-2">⚙️ ตั้งค่าระบบส่วนกลาง</h2>
              <a href="/teacher/dashboard"
                class="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold border border-white/5 rounded-xl text-xs transition-all flex items-center justify-center">
                🔙 ย้อนกลับหน้าวิชา
              </a>
            </div>

            <form id="settingsForm" class="space-y-6">
              <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label class="block text-xs font-bold text-slate-400 uppercase mb-2">ชื่อเว็บไซต์ระบบข้อสอบ (Website
                    Name)</label>
                  <input type="text" name="Website Name"
                    class="w-full bg-slate-800/50 border border-white/10 rounded-xl p-3 text-white font-bold outline-none focus:border-sky-400 transition-colors"
                    required>
                </div>
                <div>
                  <label class="block text-xs font-bold text-slate-400 uppercase mb-2">ลิงก์ URL ของโลโก้
                    (ถ้ามี)</label>
                  <input type="text" name="Logo URL"
                    class="w-full bg-slate-800/50 border border-white/10 rounded-xl p-3 text-white font-bold outline-none focus:border-sky-400 transition-colors">
                </div>
                <div class="col-span-1 md:col-span-2">
                  <label class="block text-xs font-bold text-pink-400 uppercase mb-2 font-extrabold">Google Client ID
                    (สำหรับล็อกอินระบบหลังบ้านคุณครู)</label>
                  <input type="text" name="Google Client ID"
                    class="w-full bg-slate-800/50 border border-pink-500/20 rounded-xl p-3 text-white font-bold outline-none focus:border-pink-500 transition-colors">
                </div>
                <div class="col-span-1 md:col-span-2">
                  <label class="block text-xs font-bold text-sky-400 uppercase mb-2 font-extrabold">Gemini API Key
                    (สำหรับตรวจคำตอบอัตนัยด้วย AI)</label>
                  <input type="text" name="Gemini API Key"
                    class="w-full bg-slate-800/50 border border-sky-500/20 rounded-xl p-3 text-white font-bold outline-none focus:border-sky-400 transition-colors"
                    placeholder="AI-generated Key...">
                </div>
                <div>
                  <label class="block text-xs font-bold text-slate-400 uppercase mb-2">รหัสผ่านผู้ดูแลระบบสำรอง (Admin
                    Password)</label>
                  <input type="text" name="Admin Password"
                    class="w-full bg-slate-800/50 border border-white/10 rounded-xl p-3 text-white font-bold outline-none focus:border-sky-400 transition-colors"
                    required>
                </div>
              </div>

              <button type="submit"
                class="w-full py-4 bg-gradient-to-r from-pink-500 to-sky-400 hover:from-pink-600 hover:to-sky-500 text-white font-bold rounded-xl transition-all shadow-lg shadow-pink-500/20">
                💾 บันทึกการตั้งค่าส่วนกลาง
              </button>
            </form>
          </div>
        </div>

      </div>
    </div>
  </main>

  <!-- MODAL: Exam (Subject) Form -->
  <div id="examModal"
    class="fixed inset-0 bg-black/85 backdrop-filter backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
    <div
      class="bg-slate-900 border border-white/10 rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 shadow-2xl">
      <h3 id="exam-modal-title" class="text-lg font-black text-white mb-4">เพิ่ม/แก้ไขรายวิชาสอบ</h3>
      <form id="examForm" class="space-y-4">
        <input type="hidden" name="id" id="form-e-id">

        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">รหัสวิชา</label>
            <input type="text" name="subject_code" id="form-e-code"
              class="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white outline-none focus:border-pink-500"
              required placeholder="เช่น ค31101">
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">ชื่อวิชา</label>
            <input type="text" name="subject_name" id="form-e-name"
              class="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white outline-none focus:border-pink-500"
              required placeholder="เช่น คณิตศาสตร์พื้นฐาน 1">
          </div>
        </div>

        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">ปีการศึกษา</label>
            <input type="text" name="academic_year" id="form-e-year"
              class="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white outline-none focus:border-pink-500"
              required placeholder="เช่น 2569">
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">ภาคเรียนที่ (เทอม)</label>
            <input type="text" name="semester" id="form-e-semester"
              class="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white outline-none focus:border-pink-500"
              required placeholder="เช่น 1 หรือ ฤดูร้อน">
          </div>
        </div>

        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">กลุ่มสาระการเรียนรู้</label>
            <select name="learning_area" id="form-e-area"
              class="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white outline-none">
              <option value="ภาษาไทย">ภาษาไทย</option>
              <option value="คณิตศาสตร์">คณิตศาสตร์</option>
              <option value="วิทยาศาสตร์และเทคโนโลยี">วิทยาศาสตร์และเทคโนโลยี</option>
              <option value="สังคมศึกษา ศาสนา และวัฒนธรรม">สังคมศึกษา ศาสนา และวัฒนธรรม</option>
              <option value="สุขศึกษา และพลศึกษา">สุขศึกษา และพลศึกษา</option>
              <option value="ศิลปะ">ศิลปะ</option>
              <option value="การงานอาชีพ">การงานอาชีพ</option>
              <option value="ภาษาต่างประเทศ">ภาษาต่างประเทศ</option>
              <option value="งานแนะแนว">งานแนะแนว</option>
            </select>
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">ชื่อครูผู้สอน</label>
            <input type="text" name="teacher_name" id="form-e-teacher"
              class="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white outline-none" required
              placeholder="เช่น ครูสมชาย ใจดี">
          </div>
        </div>

        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">ประเภทการสอบ</label>
            <select name="exam_type" id="form-e-type"
              class="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white outline-none">
              <option value="สอบกลางภาค">สอบกลางภาค</option>
              <option value="สอบปลายภาค">สอบปลายภาค</option>
              <option value="สอบเก็บคะแนนย่อย">สอบเก็บคะแนนย่อย</option>
              <option value="ทดสอบก่อนเรียน">ทดสอบก่อนเรียน</option>
              <option value="ทดสอบหลังเรียน">ทดสอบหลังเรียน</option>
            </select>
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">สถานะสอบ</label>
            <select name="exam_status" id="form-e-status"
              class="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white outline-none">
              <option value="Waiting">Waiting (เปิดห้องพักคอย)</option>
              <option value="Started">Started (เริ่มสอบ/ห้ามลงทะเบียนเพิ่ม)</option>
              <option value="Finished">Finished (ปิดระบบ/เสร็จสิ้นการสอบ)</option>
            </select>
          </div>
        </div>

        <div class="grid grid-cols-3 gap-4">
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">จำนวนข้อสอบที่สุ่ม (ข้อ)</label>
            <input type="number" name="num_questions" id="form-e-num"
              class="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white outline-none" required
              value="20">
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">สิทธิ์สอบสูงสุด (ครั้ง)</label>
            <input type="number" name="max_attempts" id="form-e-attempts"
              class="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white outline-none" required
              value="1">
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">เกณฑ์ผ่าน (%)</label>
            <input type="number" name="passing_percentage" id="form-e-pass"
              class="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white outline-none" required
              value="50">
          </div>
        </div>

        <div class="grid grid-cols-4 gap-4">
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">เวลาจำกัด ปรนัย (วินาที/ข้อ)</label>
            <input type="number" name="time_limit_choice" id="form-e-time-c"
              class="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white outline-none" required
              value="60">
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">เวลาจำกัด อัตนัย (วินาที/ข้อ)</label>
            <input type="number" name="time_limit_writing" id="form-e-time-w"
              class="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white outline-none" required
              value="300">
          </div>
          <div>
            <label class="block text-xs font-bold text-sky-400 mb-1">เวลาสอบรวม (นาที) [0=ไม่จำกัด]</label>
            <input type="number" name="exam_duration" id="form-e-duration"
              class="w-full bg-slate-800 border border-sky-500/20 rounded-xl p-3 text-white outline-none focus:border-sky-500"
              required value="0" placeholder="0 = ไม่จำกัด">
          </div>
          <div>
            <label class="block text-xs font-bold text-pink-400 mb-1">รอบการสอบปัจจุบัน</label>
            <input type="text" name="exam_round" id="form-e-round"
              class="w-full bg-slate-800 border border-pink-500/20 rounded-xl p-3 text-white outline-none focus:border-pink-500"
              required value="1" placeholder="เช่น 1, 2, แก้ตัว">
          </div>
        </div>

        <div class="flex gap-3 justify-end pt-4 border-t border-white/5">
          <button type="button" onclick="closeExamModal()"
            class="px-4 py-2 bg-slate-850 hover:bg-slate-800 text-slate-300 font-bold rounded-xl text-sm">ยกเลิก</button>
          <button type="submit"
            class="px-6 py-2 bg-gradient-to-r from-pink-500 to-sky-400 hover:scale-105 transition-all text-white font-bold rounded-xl text-sm">บันทึกวิชาสอบ</button>
        </div>
      </form>
    </div>
  </div>

  <!-- MODAL: Question Edit Form -->
  <div id="questionModal"
    class="fixed inset-0 bg-black/85 backdrop-filter backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
    <div
      class="bg-slate-900 border border-white/10 rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 shadow-2xl">
      <h3 id="modal-title" class="text-lg font-black text-white mb-4">เพิ่ม/แก้ไขข้อสอบ</h3>
      <form id="questionForm" class="space-y-4">
        <input type="hidden" name="id" id="form-q-id">
        <input type="hidden" name="exam_id" id="form-q-exam-id">

        <div>
          <label class="block text-xs font-bold text-slate-400 mb-1">ประเภทข้อสอบ</label>
          <select name="type" id="form-q-type" onchange="toggleFormType(this.value)"
            class="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white outline-none">
            <option value="choice">🔘 ปรนัย (เลือกตอบ)</option>
            <option value="writing">📜 อัตนัย (ข้อเขียน)</option>
          </select>
        </div>

        <div>
          <label class="block text-xs font-bold text-slate-400 mb-1">โจทย์คำถาม</label>
          <textarea name="question" id="form-q-question"
            class="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white outline-none" rows="3"
            required></textarea>
        </div>

        <div>
          <label class="block text-xs font-bold text-slate-400 mb-1">อัปโหลดรูปภาพโจทย์ (ถ้ามี)</label>
          <input type="file" id="form-q-file" onchange="handleImageUpload(this)"
            class="w-full text-sm text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-pink-600 file:text-white hover:file:bg-pink-750">
          <input type="hidden" name="image_url" id="form-q-image-url">
          <div id="image-preview-container" class="mt-2 hidden">
            <img src="" id="image-preview" class="h-20 rounded-lg border border-white/10">
            <button type="button" onclick="removeQuestionImage()"
              class="text-xs text-red-400 hover:text-red-300 font-bold block mt-1">ลบรูปภาพ</button>
          </div>
        </div>

        <div>
          <label class="block text-xs font-bold text-slate-400 mb-1">คะแนนของข้อนี้</label>
          <input type="number" name="points" id="form-q-points"
            class="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white outline-none" required
            value="1">
        </div>

        <!-- Choice options with radio to mark correct answer -->
        <div id="choice-options-wrapper" class="space-y-3">
          <label class="block text-xs font-bold text-slate-400 mb-2">ตัวเลือก <span
              class="text-emerald-400">(คลิกวงกลมเพื่อเลือกข้อที่ถูกต้อง)</span></label>
          <div class="grid grid-cols-1 gap-3">
            <label
              class="flex items-center gap-3 p-3 bg-slate-800/60 border border-white/10 rounded-xl cursor-pointer hover:bg-slate-800 hover:border-white/20 transition-all group"
              id="label-opt-a">
              <input type="radio" name="correct_choice" value="A"
                class="w-5 h-5 accent-emerald-500 cursor-pointer shrink-0">
              <span class="text-xs font-black text-pink-400 shrink-0 w-6">A.</span>
              <input type="text" name="option_a" id="form-q-opt-a"
                class="flex-1 bg-transparent border-none text-white outline-none text-sm font-bold placeholder:text-slate-600"
                placeholder="กรอกตัวเลือก A">
            </label>
            <label
              class="flex items-center gap-3 p-3 bg-slate-800/60 border border-white/10 rounded-xl cursor-pointer hover:bg-slate-800 hover:border-white/20 transition-all group"
              id="label-opt-b">
              <input type="radio" name="correct_choice" value="B"
                class="w-5 h-5 accent-emerald-500 cursor-pointer shrink-0">
              <span class="text-xs font-black text-sky-400 shrink-0 w-6">B.</span>
              <input type="text" name="option_b" id="form-q-opt-b"
                class="flex-1 bg-transparent border-none text-white outline-none text-sm font-bold placeholder:text-slate-600"
                placeholder="กรอกตัวเลือก B">
            </label>
            <label
              class="flex items-center gap-3 p-3 bg-slate-800/60 border border-white/10 rounded-xl cursor-pointer hover:bg-slate-800 hover:border-white/20 transition-all group"
              id="label-opt-c">
              <input type="radio" name="correct_choice" value="C"
                class="w-5 h-5 accent-emerald-500 cursor-pointer shrink-0">
              <span class="text-xs font-black text-amber-400 shrink-0 w-6">C.</span>
              <input type="text" name="option_c" id="form-q-opt-c"
                class="flex-1 bg-transparent border-none text-white outline-none text-sm font-bold placeholder:text-slate-600"
                placeholder="กรอกตัวเลือก C">
            </label>
            <label
              class="flex items-center gap-3 p-3 bg-slate-800/60 border border-white/10 rounded-xl cursor-pointer hover:bg-slate-800 hover:border-white/20 transition-all group"
              id="label-opt-d">
              <input type="radio" name="correct_choice" value="D"
                class="w-5 h-5 accent-emerald-500 cursor-pointer shrink-0">
              <span class="text-xs font-black text-purple-400 shrink-0 w-6">D.</span>
              <input type="text" name="option_d" id="form-q-opt-d"
                class="flex-1 bg-transparent border-none text-white outline-none text-sm font-bold placeholder:text-slate-600"
                placeholder="กรอกตัวเลือก D">
            </label>
          </div>
        </div>
        <input type="hidden" name="answer" id="form-q-answer">

        <!-- Writing answer reference (only visible for writing type) -->
        <div id="writing-answer-wrapper" class="hidden">
          <label id="answer-label" class="block text-xs font-bold text-slate-400 mb-1">คำตอบอ้างอิงแนวทาง
            (สำหรับใช้ตรวจคีย์เวิร์ดเทียบความถูกต้อง)</label>
          <textarea name="writing_answer" id="form-q-writing-answer"
            class="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white outline-none text-sm" rows="3"
            placeholder="กรอกเฉลยอ้างอิงสำหรับข้อเขียน"></textarea>
        </div>

        <div class="flex gap-3 justify-end pt-4 border-t border-white/5">
          <button type="button" onclick="closeQuestionModal()"
            class="px-4 py-2 bg-slate-850 hover:bg-slate-800 text-slate-300 font-bold rounded-xl text-sm">ยกเลิก</button>
          <button type="submit"
            class="px-6 py-2 bg-pink-500 hover:bg-pink-600 text-white font-bold rounded-xl text-sm">บันทึกข้อสอบ</button>
        </div>
      </form>
    </div>
  </div>

  <!-- MODAL: Import Questions -->
  <div id="importModal"
    class="fixed inset-0 bg-black/85 backdrop-filter backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
    <div class="bg-slate-900 border border-white/10 rounded-3xl w-full max-w-xl p-6 shadow-2xl">
      <h3 class="text-lg font-black text-white mb-2">📥 นำเข้าข้อสอบ</h3>
      <p class="text-xs text-slate-400 mb-4 leading-relaxed">
        คัดลอกข้อมูลคำถามจาก Excel/Google Sheets มาวาง โดยคอลัมน์ต้องเรียงลำดับตามนี้:<br>
        <b>[โจทย์คำถาม, ตัวเลือก A, ตัวเลือก B, ตัวเลือก C, ตัวเลือก D, คำตอบ (เฉลย), ประเภท (choice/writing),
          คะแนน]</b>
      </p>
      <textarea id="import-data"
        class="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white font-mono text-xs outline-none focus:border-sky-400"
        rows="8" placeholder="โจทย์	ก	ข	ค	ง	ก	choice	1"></textarea>

      <div class="flex items-center gap-2 mt-4">
        <input type="checkbox" id="import-clear-existing" class="w-4 h-4 rounded border-white/10 text-pink-500">
        <label for="import-clear-existing"
          class="text-xs text-slate-350 select-none">ลบข้อสอบรายวิชานี้ที่เคยมีออกทั้งหมดก่อนนำเข้า</label>
      </div>

      <div class="flex gap-3 justify-end pt-6 border-t border-white/5 mt-4">
        <button type="button" onclick="closeImportModal()"
          class="px-4 py-2 bg-slate-850 hover:bg-slate-800 text-slate-300 font-bold rounded-xl text-sm">ยกเลิก</button>
        <button type="button" onclick="submitImport()"
          class="px-6 py-2 bg-sky-500 hover:bg-sky-600 text-white font-bold rounded-xl text-sm">นำเข้าข้อมูล</button>
      </div>
    </div>
  </div>

  <!-- MODAL: Manual Grading Form -->
  <div id="gradingModal"
    class="fixed inset-0 bg-black/85 backdrop-filter backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
    <div
      class="bg-slate-900 border border-white/10 rounded-3xl w-full max-w-3xl max-h-[85vh] overflow-y-auto p-6 shadow-2xl">
      <h3 class="text-lg font-black text-white mb-2">✍️ ตรวจและบันทึกคะแนนข้อสอบข้อเขียน (อัตนัย)</h3>
      <p id="grade-student-info" class="text-xs text-slate-400 mb-6 font-bold"></p>

      <div id="grading-list" class="space-y-6">
        <!-- Essay items -->
      </div>

      <div class="flex gap-3 justify-end pt-6 border-t border-white/5 mt-6">
        <button type="button" onclick="closeGradingModal()"
          class="px-4 py-2 bg-slate-850 hover:bg-slate-800 text-slate-300 font-bold rounded-xl text-sm">ปิดหน้านี้</button>
        <button type="button" onclick="submitGrading()"
          class="px-6 py-2 bg-pink-500 hover:bg-pink-600 text-white font-bold rounded-xl text-sm">💾
          บันทึกคะแนนตรวจทั้งหมด</button>
      </div>
    </div>
  </div>

  <script>
    var teacherSession = {
      name: "<?= esc($teacherName) ?>",
      email: "<?= esc($teacherEmail) ?>",
      learningArea: "<?= esc($teacherLearning) ?>"
    };

    var currentTab = '<?= esc($currentTab ?? "questions") ?>';
    var activeMonitorInterval;
    var currentEditingResultId = null;
    var globalExamsList = [];
    var questionsMap = {};
    var activeExamId = '<?= esc($activeExamId ?? "") ?>';
    var isInWorkspace = <?= (isset($isInWorkspace) && $isInWorkspace) ? 'true' : 'false' ?>;

    window.onload = async () => {
      await loadGlobalExams();
      if (isInWorkspace) {
        if (activeExamId === 'global') {
          enterGlobalSettings();
        } else {
          enterWorkspace(activeExamId, currentTab);
        }
      } else {
        renderLobbyScreen();
      }
    };

    async function loadGlobalExams() {
      try {
        const response = await fetch('/api/teacher/exams');
        const res = await response.json();
        if (res.success && res.exams) {
          globalExamsList = res.exams;
        }
      } catch (e) {
        console.error("Failed to load exams list", e);
      }
    }

    function renderLobbyScreen() {
      isInWorkspace = false;
      clearInterval(activeMonitorInterval);
      document.getElementById('lobby-screen').classList.remove('hidden');
      document.getElementById('workspace-screen').classList.add('hidden');

      const grid = document.getElementById('exam-cards-grid');
      if (globalExamsList.length === 0) {
        grid.innerHTML = `
                <div class="col-span-full py-16 text-center glass-panel rounded-3xl border border-white/5">
                   <span class="text-4xl">📚</span>
                   <h3 class="text-lg font-bold text-white mt-4">ยังไม่มีรายวิชาสอบในระบบ</h3>
                   <p class="text-xs text-slate-400 mt-2">กรุณากดปุ่ม "เพิ่มวิชาสอบใหม่" ด้านบนเพื่อเริ่มใช้งาน</p>
                </div>
            `;
        return;
      }

      let html = '';
      globalExamsList.forEach(e => {
        let statusColor = 'bg-slate-500/10 text-slate-400 border border-slate-500/20';
        if (e.exam_status === 'Started') {
          statusColor = 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20';
        } else if (e.exam_status === 'Finished') {
          statusColor = 'bg-red-500/10 text-red-400 border border-red-500/20';
        }

        html += `
                <div class="glass-panel rounded-3xl p-6 border border-white/5 hover:border-pink-500/30 transition-all flex flex-col justify-between hover:scale-[1.02] shadow-lg group">
                    <div>
                        <div class="flex justify-between items-start gap-2 mb-3">
                            <span class="text-xs font-bold text-pink-400">${e.subject_code}</span>
                            <span class="px-2 py-0.5 text-[10px] font-bold rounded-lg ${statusColor}">${e.exam_status}</span>
                        </div>
                        <h3 class="text-lg font-bold text-white mb-2 truncate group-hover:text-pink-400 transition-colors" title="${e.subject_name}">${e.subject_name}</h3>
                        <div class="space-y-1 text-xs text-slate-400 font-medium">
                            <p>🏫 กลุ่มสาระฯ: ${e.learning_area}</p>
                            <p>🧑‍🏫 ผู้สอน: ${e.teacher_name}</p>
                            <p>📅 ปีการศึกษา/ภาคเรียน: ${e.academic_year || '-'}/${e.semester || '-'}</p>
                            <p>📝 ประเภทสอบ: ${e.exam_type}</p>
                            <p>📚 ในคลัง: ปรนัย ${e.choice_count || 0} ข้อ &nbsp;/&nbsp; อัตนัย ${e.writing_count || 0} ข้อ</p>
                            <p>🕒 สุ่มสอบ: ${e.num_questions} ข้อ (สิทธิ์สอบ ${e.max_attempts} ครั้ง)</p>
                        </div>
                    </div>
                    <div class="grid grid-cols-3 gap-2 mt-6 pt-4 border-t border-white/5">
                        <a href="/teacher/questions?exam_id=${e.id}" class="col-span-2 py-2.5 bg-gradient-to-r from-pink-500 to-sky-400 hover:from-pink-600 hover:to-sky-500 text-white font-bold rounded-xl text-xs transition-all text-center flex items-center justify-center gap-1">
                            ⚙️ จัดการข้อสอบ
                        </a>
                        <button onclick='editExam(${JSON.stringify(e)})' class="py-2.5 bg-white/5 hover:bg-white/10 text-slate-300 font-bold rounded-xl text-xs border border-white/10 transition-all text-center" title="แก้ไขวิชา">
                            ✏️
                        </button>
                    </div>
                </div>
            `;
      });
      grid.innerHTML = html;
    }

    function enterWorkspace(examId, tabName = 'questions') {
      const exam = globalExamsList.find(e => e.id === examId);
      if (!exam) return;

      activeExamId = examId;
      isInWorkspace = true;

      document.getElementById('lobby-screen').classList.add('hidden');
      document.getElementById('workspace-screen').classList.remove('hidden');

      // Render Active Subject Info in Workspace Sidebar
      document.getElementById('workspace-subject-code').textContent = exam.subject_code;
      document.getElementById('workspace-subject-name').textContent = exam.subject_name;
      document.getElementById('workspace-subject-status').textContent = exam.exam_status;
      document.getElementById('workspace-subject-area').textContent = `${exam.learning_area} (${exam.academic_year || '-'}/${exam.semester || '-'})`;

      // Set status badge style
      const statusEl = document.getElementById('workspace-subject-status');
      statusEl.className = "px-2 py-0.5 text-[10px] font-bold rounded ";
      if (exam.exam_status === 'Started') {
        statusEl.className += "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20";
      } else if (exam.exam_status === 'Finished') {
        statusEl.className += "bg-red-500/10 text-red-400 border border-red-500/20";
      } else {
        statusEl.className += "bg-slate-500/10 text-slate-400 border border-slate-500/20";
      }

      switchTab(tabName);
    }

    function exitWorkspace() {
      window.location.href = '/teacher/dashboard';
    }

    function enterGlobalSettings() {
      activeExamId = 'global';
      isInWorkspace = true;

      document.getElementById('lobby-screen').classList.add('hidden');
      document.getElementById('workspace-screen').classList.remove('hidden');

      document.getElementById('workspace-subject-code').textContent = "SYSTEM";
      document.getElementById('workspace-subject-name').textContent = "การตั้งค่าระบบส่วนกลาง";
      document.getElementById('workspace-subject-status').textContent = "Global";
      document.getElementById('workspace-subject-area').textContent = "Settings";

      switchTab('settings');
    }

    function switchTab(tabName) {
      currentTab = tabName;
      document.querySelectorAll('.section-content').forEach(s => s.classList.add('hidden'));
      document.getElementById(`section-${tabName}`).classList.remove('hidden');

      document.querySelectorAll('[id^="tab-btn-"]').forEach(b => b.classList.remove('active-tab'));
      const activeBtn = document.getElementById(`tab-btn-${tabName}`);
      if (activeBtn) activeBtn.classList.add('active-tab');

      clearInterval(activeMonitorInterval);

      if (tabName === 'settings') {
        loadSettings();
      } else if (tabName === 'monitor') {
        loadMonitor();
        activeMonitorInterval = setInterval(loadMonitor, 3000);
      } else if (tabName === 'questions') {
        loadQuestions();
      } else if (tabName === 'results') {
        loadResults();
      } else if (tabName === 'logs') {
        loadLogs();
      } else if (tabName === 'exam-settings') {
        loadActiveExamSettings();
      }
    }

    async function logout() {
      try {
        await fetch('/api/teacher/logout', { method: 'POST' });
        window.location.href = '/teacher';
      } catch (e) {
        window.location.href = '/teacher';
      }
    }

    function openExamModal() {
      document.getElementById('examForm').reset();
      document.getElementById('form-e-id').value = '';
      document.getElementById('exam-modal-title').textContent = "🏫 เพิ่มรายวิชาสอบใหม่";

      // Auto-fill teacher info from session
      if (teacherSession.name) {
        document.getElementById('form-e-teacher').value = teacherSession.name;
      }
      if (teacherSession.learningArea) {
        const selectEl = document.getElementById('form-e-area');
        const targetArea = teacherSession.learningArea.trim();
        // Try exact match first
        for (let i = 0; i < selectEl.options.length; i++) {
          if (selectEl.options[i].value.trim() === targetArea) {
            selectEl.selectedIndex = i;
            break;
          }
        }
      }

      document.getElementById('examModal').classList.remove('hidden');
    }

    function closeExamModal() {
      document.getElementById('examModal').classList.add('hidden');
    }

    function editExam(e) {
      // Prevent event bubbling if clicked inside card buttons
      event.stopPropagation();
      document.getElementById('exam-modal-title').textContent = "🏫 แก้ไขรายวิชาสอบ";
      document.getElementById('form-e-id').value = e.id;
      document.getElementById('form-e-code').value = e.subject_code;
      document.getElementById('form-e-name').value = e.subject_name;
      document.getElementById('form-e-year').value = e.academic_year || '';
      document.getElementById('form-e-semester').value = e.semester || '';
      document.getElementById('form-e-area').value = e.learning_area;
      document.getElementById('form-e-teacher').value = e.teacher_name;
      document.getElementById('form-e-type').value = e.exam_type;
      document.getElementById('form-e-status').value = e.exam_status;
      document.getElementById('form-e-num').value = e.num_questions;
      document.getElementById('form-e-attempts').value = e.max_attempts;
      document.getElementById('form-e-pass').value = e.passing_percentage;
      document.getElementById('form-e-time-c').value = e.time_limit_choice;
      document.getElementById('form-e-time-w').value = e.time_limit_writing;
      document.getElementById('form-e-duration').value = e.exam_duration || '0';
      document.getElementById('form-e-round').value = e.exam_round || '1';
      document.getElementById('examModal').classList.remove('hidden');
    }

    document.getElementById('examForm').onsubmit = async (e) => {
      e.preventDefault();
      const form = e.target;
      const formData = new FormData(form);

      Swal.fire({ title: 'กำลังบันทึกรายวิชา...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });

      try {
        const response = await fetch('/api/teacher/exams/save', {
          method: 'POST',
          body: formData
        });
        const res = await response.json();
        Swal.close();
        if (res.success) {
          Swal.fire('สำเร็จ', 'บันทึกข้อมูลรายวิชาสอบเรียบร้อยแล้ว', 'success');
          closeExamModal();
          await loadGlobalExams();
          if (isInWorkspace) {
            // Update header in workspace if current editing
            const updated = globalExamsList.find(item => item.id === activeExamId);
            if (updated) {
              document.getElementById('workspace-subject-code').textContent = updated.subject_code;
              document.getElementById('workspace-subject-name').textContent = updated.subject_name;
              document.getElementById('workspace-subject-status').textContent = updated.exam_status;
            }
          } else {
            renderLobbyScreen();
          }
        } else {
          Swal.fire('ล้มเหลว', res.message || 'เกิดข้อผิดพลาด', 'error');
        }
      } catch (err) {
        Swal.close();
        Swal.fire('ล้มเหลว', 'เกิดข้อผิดพลาดการเชื่อมต่อ', 'error');
      }
    };

    // --- Tab 1.5: Exam Settings (Workspace Specific) ---

    function loadActiveExamSettings() {
      const exam = globalExamsList.find(e => e.id === activeExamId);
      if (!exam) return;

      document.getElementById('workspace-e-id').value = exam.id;
      document.getElementById('workspace-e-code').value = exam.subject_code;
      document.getElementById('workspace-e-name').value = exam.subject_name;
      document.getElementById('workspace-e-year').value = exam.academic_year || '';
      document.getElementById('workspace-e-semester').value = exam.semester || '';
      document.getElementById('workspace-e-area').value = exam.learning_area;
      document.getElementById('workspace-e-teacher').value = exam.teacher_name;
      document.getElementById('workspace-e-type').value = exam.exam_type;
      document.getElementById('workspace-e-status').value = exam.exam_status;
      document.getElementById('workspace-e-num').value = exam.num_questions;
      document.getElementById('workspace-e-attempts').value = exam.max_attempts;
      document.getElementById('workspace-e-pass').value = exam.passing_percentage;
      document.getElementById('workspace-e-time-c').value = exam.time_limit_choice;
      document.getElementById('workspace-e-time-w').value = exam.time_limit_writing;
      document.getElementById('workspace-e-duration').value = exam.exam_duration || '0';
      document.getElementById('workspace-e-round').value = exam.exam_round || '1';
    }

    const activeExamSettingsFormEl = document.getElementById('activeExamSettingsForm');
    if (activeExamSettingsFormEl) {
      activeExamSettingsFormEl.onsubmit = async (e) => {
        e.preventDefault();
        const form = e.target;
        const formData = new FormData(form);

        Swal.fire({ title: 'กำลังบันทึกตั้งค่าวิชาสอบ...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });

        try {
          const response = await fetch('/api/teacher/exams/save', {
            method: 'POST',
            body: formData
          });
          const res = await response.json();
          Swal.close();
          if (res.success) {
            Swal.fire('สำเร็จ', 'บันทึกข้อมูลวิชาสอบเรียบร้อยแล้ว', 'success');
            await loadGlobalExams();

            // Update header details dynamically
            const updated = globalExamsList.find(item => item.id === activeExamId);
            if (updated) {
              document.getElementById('workspace-subject-code').textContent = updated.subject_code;
              document.getElementById('workspace-subject-name').textContent = updated.subject_name;
              document.getElementById('workspace-subject-status').textContent = updated.exam_status;

              // Set status badge style
              const statusEl = document.getElementById('workspace-subject-status');
              statusEl.className = "px-2 py-0.5 text-[10px] font-bold rounded ";
              if (updated.exam_status === 'Started') {
                statusEl.className += "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20";
              } else if (updated.exam_status === 'Finished') {
                statusEl.className += "bg-red-500/10 text-red-400 border border-red-500/20";
              } else {
                statusEl.className += "bg-slate-500/10 text-slate-400 border border-slate-500/20";
              }
            }
          } else {
            Swal.fire('ล้มเหลว', res.message || 'เกิดข้อผิดพลาด', 'error');
          }
        } catch (err) {
          Swal.close();
          Swal.fire('ล้มเหลว', 'เกิดข้อผิดพลาดในการเชื่อมต่อ', 'error');
        }
      };
    }

    // --- Tab 2: Settings (Global) ---
    async function loadSettings() {
      try {
        const response = await fetch('/api/teacher/settings');
        const res = await response.json();
        if (res.success && res.settings) {
          const form = document.getElementById('settingsForm');
          for (let key in res.settings) {
            const input = form.querySelector(`[name="${key}"]`);
            if (input) {
              input.value = res.settings[key];
            }
          }
        }
      } catch (e) {
        console.error("Failed to load settings", e);
      }
    }

    document.getElementById('settingsForm').onsubmit = async (e) => {
      e.preventDefault();
      const form = e.target;
      const formData = new FormData(form);
      const settings = {};
      formData.forEach((value, key) => {
        settings[key] = value;
      });

      Swal.fire({ title: 'กำลังบันทึกการตั้งค่า...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });

      const postData = new FormData();
      postData.append('settings', JSON.stringify(settings));

      try {
        const response = await fetch('/api/teacher/settings', {
          method: 'POST',
          body: postData
        });
        const res = await response.json();
        Swal.close();
        if (res.success) {
          Swal.fire('สำเร็จ', 'บันทึกการตั้งค่าเรียบร้อยแล้ว', 'success');
          loadSettings();
        } else {
          Swal.fire('ล้มเหลว', res.message || 'เกิดข้อผิดพลาด', 'error');
        }
      } catch (err) {
        Swal.close();
        Swal.fire('ล้มเหลว', 'เกิดข้อผิดพลาดในการเชื่อมต่อ', 'error');
      }
    };

    // Prevent default submit reload on question form
    const qFormEl = document.getElementById('questionForm');
    if (qFormEl) {
      qFormEl.onsubmit = (e) => {
        e.preventDefault();
        saveQuestion();
      };
    }

    function escapeHtml(text) {
      if (!text) return '';
      return String(text)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
    }

    function deleteExam(id) {
      event.stopPropagation();
      Swal.fire({
        title: 'ต้องการลบวิชาสอบนี้?',
        text: 'คำเตือน: การลบวิชาจะล้างประวัติการสอบ คำถาม และข้อมูลห้องสอบที่เกี่ยวข้องของวิชานี้ทั้งหมด!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        confirmButtonText: 'ยืนยันลบวิชาสอบ',
        cancelButtonText: 'ยกเลิก'
      }).then(async (result) => {
        if (result.isConfirmed) {
          const formData = new FormData();
          formData.append('id', id);
          try {
            const response = await fetch('/api/teacher/exams/delete', { method: 'POST', body: formData });
            const res = await response.json();
            if (res.success) {
              Swal.fire('สำเร็จ', 'ลบวิชาสอบเรียบร้อยแล้ว', 'success');
              await loadGlobalExams();
              if (isInWorkspace && activeExamId === id) {
                exitWorkspace();
              }
            } else {
              Swal.fire('ล้มเหลว', res.message || 'ลบไม่สำเร็จ', 'error');
            }
          } catch (e) {
            Swal.fire('ล้มเหลว', 'เกิดข้อผิดพลาดในการเชื่อมต่อ', 'error');
          }
        }
      });
    }

    // --- Tab 3: Questions list ---
    async function loadQuestions() {
      try {
        const response = await fetch(`/api/teacher/questions?exam_id=${activeExamId}`);
        const res = await response.json();
        const choiceList = document.getElementById('choice-questions-list');
        const writingList = document.getElementById('writing-questions-list');

        if (!choiceList || !writingList) return;

        // Clear old map
        questionsMap = {};

        if (res.success && res.questions) {
          // Populate questionsMap
          res.questions.forEach(q => {
            questionsMap[q.id] = q;
          });

          const choiceQuestions = res.questions.filter(q => q.type === 'choice');
          const writingQuestions = res.questions.filter(q => q.type === 'writing');

          // Render Choice Table
          if (choiceQuestions.length === 0) {
            choiceList.innerHTML = `<tr><td colspan="4" class="py-8 text-center text-slate-500">ไม่มีข้อสอบประเภทปรนัย (ตัวเลือก) ในวิชานี้</td></tr>`;
          } else {
            let html = '';
            choiceQuestions.forEach((q, index) => {
              let optionsHtml = '';
              if (q.choices) {
                const choices = JSON.parse(q.choices);
                optionsHtml = `<div class="mt-2 text-xs text-slate-400 space-y-1">`;
                choices.forEach((c) => {
                  const isCorrect = (c === q.correct_answer) ? 'text-emerald-400 font-extrabold' : 'text-slate-400';
                  optionsHtml += `<div class="${isCorrect}">- ${escapeHtml(c)}</div>`;
                });
                optionsHtml += `</div>`;
              }

              html += `
                            <tr class="hover:bg-white/5 transition-colors">
                                <td class="py-4 px-4 text-white font-bold leading-relaxed max-w-xl">
                                    <div class="flex items-start gap-3">
                                        <span class="px-2 py-0.5 bg-slate-800 text-slate-400 rounded-lg text-[10px]">ข้อที่ ${index + 1}</span>
                                        <div>
                                            ${q.image_url ? `<img src="${q.image_url}" class="max-h-24 object-contain mb-2 block rounded" />` : ''}
                                            <span>${escapeHtml(q.question_text)}</span>
                                            ${optionsHtml}
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-4 text-xs font-bold text-slate-350">${escapeHtml(q.correct_answer || '')}</td>
                                <td class="py-4 px-4">
                                    <input type="number" min="0" step="0.5" value="${q.points}"
                                        onchange="updateQuestionPoints('${q.id}', this.value)"
                                        class="w-16 bg-slate-800 border border-white/10 rounded-lg px-2 py-1 text-center text-white font-bold text-sm outline-none focus:border-pink-500 transition-colors" />
                                </td>
                                <td class="py-4 px-4 text-right space-x-2">
                                    <button onclick="editQuestion('${q.id}')" class="px-3 py-1 bg-sky-500/10 hover:bg-sky-500 text-sky-400 hover:text-white rounded-lg text-xs font-bold border border-sky-400/25 hover:border-transparent transition-all">
                                        แก้ไข ✏️
                                    </button>
                                    <button onclick="deleteQuestion('${q.id}')" class="px-3 py-1 bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white rounded-lg text-xs font-bold border border-red-500/25 hover:border-transparent transition-all">
                                        ลบ 🗑️
                                    </button>
                                </td>
                            </tr>
                        `;
            });
            choiceList.innerHTML = html;
          }

          // Render Writing Table
          if (writingQuestions.length === 0) {
            writingList.innerHTML = `<tr><td colspan="4" class="py-8 text-center text-slate-500">ไม่มีข้อสอบประเภทอัตนัย (เขียนตอบ) ในวิชานี้</td></tr>`;
          } else {
            let html = '';
            writingQuestions.forEach((q, index) => {
              html += `
                            <tr class="hover:bg-white/5 transition-colors">
                                <td class="py-4 px-4 text-white font-bold leading-relaxed max-w-xl">
                                    <div class="flex items-start gap-3">
                                        <span class="px-2 py-0.5 bg-slate-800 text-slate-400 rounded-lg text-[10px]">ข้อที่ ${index + 1}</span>
                                        <div>
                                            ${q.image_url ? `<img src="${q.image_url}" class="max-h-24 object-contain mb-2 block rounded" />` : ''}
                                            <span>${escapeHtml(q.question_text)}</span>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-4 text-xs font-bold text-slate-350 max-w-sm leading-relaxed">${escapeHtml(q.correct_answer || '(ไม่มีเฉลยอ้างอิง)')}</td>
                                <td class="py-4 px-4">
                                    <input type="number" min="0" step="0.5" value="${q.points}"
                                        onchange="updateQuestionPoints('${q.id}', this.value)"
                                        class="w-16 bg-slate-800 border border-white/10 rounded-lg px-2 py-1 text-center text-white font-bold text-sm outline-none focus:border-pink-500 transition-colors" />
                                </td>
                                <td class="py-4 px-4 text-right space-x-2">
                                    <button onclick="editQuestion('${q.id}')" class="px-3 py-1 bg-sky-500/10 hover:bg-sky-500 text-sky-400 hover:text-white rounded-lg text-xs font-bold border border-sky-400/25 hover:border-transparent transition-all">
                                        แก้ไข ✏️
                                    </button>
                                    <button onclick="deleteQuestion('${q.id}')" class="px-3 py-1 bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white rounded-lg text-xs font-bold border border-red-500/25 hover:border-transparent transition-all">
                                        ลบ 🗑️
                                    </button>
                                </td>
                            </tr>
                        `;
            });
            writingList.innerHTML = html;
          }
        }
      } catch (e) {
        console.error(e);
      }
    }

    function clearAllQuestions() {
      Swal.fire({
        title: 'ต้องการล้างคลังข้อสอบทั้งหมดของวิชานี้?',
        text: 'ข้อมูลคำถามทุกข้อภายใต้วิชานี้จะถูกลบถาวร!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        confirmButtonText: 'ล้างข้อมูลทั้งหมด',
        cancelButtonText: 'ยกเลิก'
      }).then(async (result) => {
        if (result.isConfirmed) {
          const formData = new FormData();
          formData.append('exam_id', activeExamId);
          try {
            const response = await fetch('/api/teacher/questions/clear', { method: 'POST', body: formData });
            const res = await response.json();
            if (res.success) {
              Swal.fire('สำเร็จ', 'ล้างคลังคำถามของวิชานี้แล้ว', 'success');
              loadQuestions();
            }
          } catch (e) {
            Swal.fire('ล้มเหลว', 'ล้มเหลว', 'error');
          }
        }
      });
    }

    function openQuestionModal(type = 'choice') {
      document.getElementById('modal-title').textContent = "➕ เพิ่มคำถามข้อสอบ";
      document.getElementById('form-q-id').value = '';
      document.getElementById('form-q-exam-id').value = activeExamId;
      document.getElementById('form-q-type').value = type;
      document.getElementById('form-q-question').value = '';
      document.getElementById('form-q-points').value = '1';
      document.getElementById('form-q-answer').value = '';
      document.getElementById('form-q-writing-answer').value = '';
      document.getElementById('form-q-image-url').value = '';
      document.getElementById('image-preview-container').classList.add('hidden');

      // Clear choice options and radio
      document.getElementById('form-q-opt-a').value = '';
      document.getElementById('form-q-opt-b').value = '';
      document.getElementById('form-q-opt-c').value = '';
      document.getElementById('form-q-opt-d').value = '';
      document.querySelectorAll('input[name="correct_choice"]').forEach(r => r.checked = false);

      toggleFormType(type);
      document.getElementById('questionModal').classList.remove('hidden');
    }

    function closeQuestionModal() {
      document.getElementById('questionModal').classList.add('hidden');
    }

    function toggleFormType(type) {
      const choiceWrapper = document.getElementById('choice-options-wrapper');
      const writingWrapper = document.getElementById('writing-answer-wrapper');
      if (type === 'writing') {
        if (choiceWrapper) choiceWrapper.classList.add('hidden');
        if (writingWrapper) writingWrapper.classList.remove('hidden');
      } else {
        if (choiceWrapper) choiceWrapper.classList.remove('hidden');
        if (writingWrapper) writingWrapper.classList.add('hidden');
      }
      highlightCorrectChoice();
    }

    function highlightCorrectChoice() {
      const radios = document.querySelectorAll('input[name="correct_choice"]');
      radios.forEach(r => {
        const label = r.closest('label');
        if (!label) return;
        if (r.checked) {
          label.classList.remove('border-white/10', 'bg-slate-800/60');
          label.classList.add('border-emerald-500/50', 'bg-emerald-500/10', 'ring-1', 'ring-emerald-500/30');
        } else {
          label.classList.remove('border-emerald-500/50', 'bg-emerald-500/10', 'ring-1', 'ring-emerald-500/30');
          label.classList.add('border-white/10', 'bg-slate-800/60');
        }
      });
    }

    // Attach highlight listener to radio buttons
    document.querySelectorAll('input[name="correct_choice"]').forEach(radio => {
      radio.addEventListener('change', highlightCorrectChoice);
    });

    function editQuestion(qOrId) {
      let q = qOrId;
      if (typeof qOrId === 'string') {
        q = questionsMap[qOrId];
      }
      if (!q) return;

      document.getElementById('modal-title').textContent = "✏️ แก้ไขคำถามข้อสอบ";
      document.getElementById('form-q-id').value = q.id;
      document.getElementById('form-q-exam-id').value = q.exam_id;
      document.getElementById('form-q-type').value = q.type;
      document.getElementById('form-q-question').value = q.question_text;
      document.getElementById('form-q-points').value = q.points;
      document.getElementById('form-q-image-url').value = q.image_url || '';

      if (q.image_url) {
        document.getElementById('image-preview').src = q.image_url;
        document.getElementById('image-preview-container').classList.remove('hidden');
      } else {
        document.getElementById('image-preview-container').classList.add('hidden');
      }

      if (q.type === 'choice') {
        document.getElementById('form-q-opt-a').value = q.option_a || '';
        document.getElementById('form-q-opt-b').value = q.option_b || '';
        document.getElementById('form-q-opt-c').value = q.option_c || '';
        document.getElementById('form-q-opt-d').value = q.option_d || '';
        // Set the radio to the correct answer
        document.querySelectorAll('input[name="correct_choice"]').forEach(r => r.checked = false);
        const ca = (q.correct_answer || '').trim();
        let matched = false;
        // Try matching by letter (A/B/C/D)
        if (['A', 'B', 'C', 'D'].includes(ca.toUpperCase())) {
          const r = document.querySelector(`input[name="correct_choice"][value="${ca.toUpperCase()}"]`);
          if (r) { r.checked = true; matched = true; }
        }
        // If no letter match, try matching by option text
        if (!matched) {
          const optionMap = { 'A': q.option_a, 'B': q.option_b, 'C': q.option_c, 'D': q.option_d };
          for (const [letter, text] of Object.entries(optionMap)) {
            if (text && text.trim() === ca) {
              const r = document.querySelector(`input[name="correct_choice"][value="${letter}"]`);
              if (r) { r.checked = true; matched = true; break; }
            }
          }
        }
        document.getElementById('form-q-answer').value = q.correct_answer;
        document.getElementById('form-q-writing-answer').value = '';
      } else {
        // Writing type
        document.getElementById('form-q-answer').value = q.correct_answer;
        document.getElementById('form-q-writing-answer').value = q.correct_answer || '';
        document.querySelectorAll('input[name="correct_choice"]').forEach(r => r.checked = false);
      }

      toggleFormType(q.type);
      document.getElementById('questionModal').classList.remove('hidden');
    }

    async function saveQuestion() {
      const id = document.getElementById('form-q-id').value;
      const examId = document.getElementById('form-q-exam-id').value;
      const type = document.getElementById('form-q-type').value;
      const questionText = document.getElementById('form-q-question').value;
      const points = document.getElementById('form-q-points').value;
      const imageUrl = document.getElementById('form-q-image-url').value;

      // Determine the answer based on question type
      let answer = '';
      if (type === 'choice') {
        const selectedRadio = document.querySelector('input[name="correct_choice"]:checked');
        if (!selectedRadio) {
          Swal.fire('คำเตือน', 'กรุณาเลือกข้อที่ถูกต้อง (คลิกวงกลมหน้าตัวเลือก)', 'warning');
          return;
        }
        // Map radio value (A/B/C/D) to the actual option text
        const letterToInput = {
          'A': 'form-q-opt-a',
          'B': 'form-q-opt-b',
          'C': 'form-q-opt-c',
          'D': 'form-q-opt-d'
        };
        answer = document.getElementById(letterToInput[selectedRadio.value]).value.trim();
      } else {
        answer = document.getElementById('form-q-writing-answer').value;
      }

      if (!questionText.trim()) {
        Swal.fire('คำเตือน', 'กรุณากรอกโจทย์คำถาม', 'warning');
        return;
      }

      const formData = new FormData();
      if (id) formData.append('id', id);
      formData.append('exam_id', examId);
      formData.append('type', type);
      formData.append('question', questionText);
      formData.append('points', points);
      formData.append('answer', answer);
      formData.append('image_url', imageUrl);

      if (type === 'choice') {
        const choices = [
          document.getElementById('form-q-opt-a').value.trim(),
          document.getElementById('form-q-opt-b').value.trim(),
          document.getElementById('form-q-opt-c').value.trim(),
          document.getElementById('form-q-opt-d').value.trim()
        ];
        formData.append('options', JSON.stringify(choices));
      }

      Swal.fire({ title: 'กำลังบันทึกข้อสอบ...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });

      try {
        const response = await fetch('/api/teacher/questions/save', {
          method: 'POST',
          body: formData
        });
        const res = await response.json();
        Swal.close();
        if (res.success) {
          Swal.fire('สำเร็จ', 'บันทึกคำถามเรียบร้อยแล้ว', 'success');
          closeQuestionModal();
          loadQuestions();
        } else {
          Swal.fire('ล้มเหลว', res.message || 'บันทึกไม่สำเร็จ', 'error');
        }
      } catch (e) {
        Swal.close();
        Swal.fire('ล้มเหลว', 'ข้อผิดพลาดระบบ', 'error');
      }
    }

    function deleteQuestion(id) {
      Swal.fire({
        title: 'ต้องการลบคำถามข้อนี้?',
        text: 'การลบคำถามข้อนี้จะไม่สามารถกู้คืนได้!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        confirmButtonText: 'ยืนยันลบ',
        cancelButtonText: 'ยกเลิก'
      }).then(async (result) => {
        if (result.isConfirmed) {
          const formData = new FormData();
          formData.append('id', id);
          try {
            const response = await fetch('/api/teacher/questions/delete', { method: 'POST', body: formData });
            const res = await response.json();
            if (res.success) {
              Swal.fire('สำเร็จ', 'ลบข้อสอบเรียบร้อยแล้ว', 'success');
              loadQuestions();
            } else {
              Swal.fire('ล้มเหลว', res.message || 'ลบไม่สำเร็จ', 'error');
            }
          } catch (e) {
            Swal.fire('ล้มเหลว', 'เกิดข้อผิดพลาดในการเชื่อมต่อ', 'error');
          }
        }
      });
    }

    async function updateQuestionPoints(id, points) {
      const formData = new FormData();
      formData.append('id', id);
      formData.append('points', points);
      try {
        const response = await fetch('/api/teacher/questions/update-points', {
          method: 'POST',
          body: formData
        });
        const res = await response.json();
        if (!res.success) {
          Swal.fire('ล้มเหลว', res.message || 'อัปเดตคะแนนไม่สำเร็จ', 'error');
        }
      } catch (e) {
        console.error(e);
      }
    }

    // --- Tab 4: Import Questions ---
    function openImportModal() {
      document.getElementById('import-data').value = '';
      document.getElementById('import-clear-existing').checked = false;
      document.getElementById('importModal').classList.remove('hidden');
    }

    function closeImportModal() {
      document.getElementById('importModal').classList.add('hidden');
    }

    async function submitImport() {
      const rawText = document.getElementById('import-data').value;
      const clearExisting = document.getElementById('import-clear-existing').checked;

      if (!rawText.trim()) {
        Swal.fire('คำเตือน', 'กรุณาวางข้อมูลดิบก่อนนำเข้า', 'warning');
        return;
      }

      const rows = rawText.split('\n').map(line => {
        let parts = [];
        if (line.includes('\t')) {
          parts = line.split('\t');
        } else if (line.includes(',')) {
          parts = line.split(',');
        } else {
          parts = [line];
        }
        return parts.map(col => col.trim());
      }).filter(r => r.length > 1 || (r.length === 1 && r[0] !== ''));
      Swal.fire({ title: 'กำลังนำเข้าข้อมูลคำถาม...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });

      const formData = new FormData();
      formData.append('exam_id', activeExamId);
      formData.append('rows', JSON.stringify(rows));
      formData.append('clearExisting', clearExisting);

      try {
        const response = await fetch('/api/teacher/questions/import', {
          method: 'POST',
          body: formData
        });
        const res = await response.json();
        Swal.close();
        if (res.success) {
          Swal.fire('สำเร็จ', `นำเข้าข้อมูลเรียบร้อยแล้ว จำนวน ${res.count} ข้อ`, 'success');
          closeImportModal();
          loadQuestions();
        } else {
          Swal.fire('ล้มเหลว', res.message || 'เกิดข้อผิดพลาด', 'error');
        }
      } catch (err) {
        Swal.close();
        Swal.fire('ล้มเหลว', 'การเชื่อมต่อผิดพลาด', 'error');
      }
    }

    // --- Tab 5: Lobby Monitor ---
    async function loadMonitor() {
      try {
        const response = await fetch(`/api/teacher/monitor?exam_id=${activeExamId}`);
        const res = await response.json();
        const container = document.getElementById('monitor-list');
        const countEl = document.getElementById('active-players-count');
        const badgeEl = document.getElementById('monitor-status-badge');

        if (res.lobby_mode) {
          currentLobbyModeSetting = res.lobby_mode;
          updateLobbyModeButton();
        }

        if (res.join_policy) {
          updateJoinPolicyUI(res.join_policy);
        }

        if (badgeEl && res.exam_status) {
          if (res.exam_status === 'Waiting') {
            badgeEl.className = "px-3.5 py-1.5 text-xs font-black rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20 shadow-sm";
            badgeEl.textContent = "⏳ ห้องรอสอบ (พักคอย)";
          } else if (res.exam_status === 'Started') {
            badgeEl.className = "px-3.5 py-1.5 text-xs font-black rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 animate-pulse shadow-sm";
            badgeEl.textContent = "🚀 กำลังสอบอยู่ (Exam Started)";
          } else if (res.exam_status === 'Finished') {
            badgeEl.className = "px-3.5 py-1.5 text-xs font-black rounded-xl bg-red-500/10 text-red-400 border border-red-500/20 shadow-sm";
            badgeEl.textContent = "🛑 ปิดระบบสอบแล้ว (Finished)";
          }
        }

        // Dynamically highlight active status button and dim others
        const btnStarted = document.querySelector("button[onclick*='Started']");
        const btnFinished = document.querySelector("button[onclick*='Finished']");
        const btnWaiting = document.querySelector("button[onclick*='Waiting']");

        if (btnStarted && btnFinished && btnWaiting) {
          // Reset classes
          btnStarted.className = "w-full py-4 px-6 rounded-2xl text-sm font-black transition-all cursor-pointer flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-[0.98]";
          btnFinished.className = "w-full py-4 px-6 rounded-2xl text-sm font-black transition-all cursor-pointer flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-[0.98]";
          btnWaiting.className = "w-full py-4 px-6 rounded-2xl text-sm font-black transition-all cursor-pointer flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-[0.98]";

          if (res.exam_status === 'Started') {
            btnStarted.classList.add("bg-gradient-to-r", "from-emerald-500", "to-teal-500", "text-white", "shadow-lg", "shadow-emerald-500/30");
            btnFinished.classList.add("bg-white/5", "text-red-450/40", "border", "border-white/5", "opacity-40", "hover:opacity-90");
            btnWaiting.classList.add("bg-white/5", "text-amber-450/40", "border", "border-white/5", "opacity-40", "hover:opacity-90");
          } else if (res.exam_status === 'Finished') {
            btnFinished.classList.add("bg-gradient-to-r", "from-red-500", "to-rose-600", "text-white", "shadow-lg", "shadow-red-500/25");
            btnStarted.classList.add("bg-white/5", "text-emerald-450/40", "border", "border-white/5", "opacity-40", "hover:opacity-90");
            btnWaiting.classList.add("bg-white/5", "text-amber-450/40", "border", "border-white/5", "opacity-40", "hover:opacity-90");
          } else { // Waiting
            btnWaiting.classList.add("bg-gradient-to-r", "from-amber-500", "to-orange-500", "text-white", "shadow-lg", "shadow-amber-500/30");
            btnStarted.classList.add("bg-white/5", "text-emerald-450/40", "border", "border-white/5", "opacity-40", "hover:opacity-90");
            btnFinished.classList.add("bg-white/5", "text-red-450/40", "border", "border-white/5", "opacity-40", "hover:opacity-90");
          }
        }

        if (res.success && res.students) {
          countEl.textContent = `${res.students.length} คนกำลังรอในห้อง`;
          if (res.students.length === 0) {
            container.innerHTML = `<tr><td colspan="5" class="py-12 text-center text-slate-500 font-bold">ไม่มีนักเรียนในหน้าพักคอยขณะนี้</td></tr>`;
            return;
          }

          let html = '';
          res.students.forEach(s => {
            const initials = s.name.substring(0, 2);
            html += `
                        <tr class="hover:bg-white/5 transition-all duration-300">
                            <!-- ชื่อ-นามสกุล -->
                            <td class="py-4 px-4 font-bold text-white">
                                <div class="flex items-center gap-3">
                                    <div class="w-9 h-9 rounded-full bg-gradient-to-tr from-pink-500/20 to-sky-500/20 border border-white/10 flex items-center justify-center text-xs font-black text-slate-200">
                                        ${initials}
                                    </div>
                                    <div class="flex flex-col">
                                        <span class="text-sm font-black text-white">${s.name}</span>
                                        <span class="text-[10px] text-pink-400 font-extrabold font-mono mt-0.5">ID: ${s.student_code || '-'}</span>
                                    </div>
                                </div>
                            </td>
                            <!-- เลขที่/ห้อง -->
                            <td class="py-4 px-4">
                                <div class="flex items-center gap-2">
                                    <span class="px-2.5 py-1 rounded-xl bg-sky-500/10 text-sky-400 border border-sky-500/20 text-xs font-extrabold">ม.${s.room}</span>
                                    <span class="px-2.5 py-1 rounded-xl bg-slate-800 text-slate-350 border border-white/5 text-xs font-extrabold">เลขที่ ${s.student_number}</span>
                                </div>
                            </td>
                            <!-- อีเมล -->
                            <td class="py-4 px-4 text-xs font-mono text-slate-400 font-semibold">${s.email}</td>
                            <!-- สถานะ -->
                            <td class="py-4 px-4 text-xs">
                                <div class="flex items-center gap-1.5">
                                    <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shadow-sm shadow-emerald-500"></span>
                                    <span class="text-[11px] text-emerald-450 font-bold tracking-wider">ออนไลน์</span>
                                </div>
                            </td>
                            <!-- ดำเนินการ -->
                            <td class="py-4 px-4 text-right">
                                <button onclick="deleteStudent('${s.email}')" class="px-3.5 py-1.5 bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white rounded-xl text-xs font-bold border border-red-500/20 hover:border-transparent transition-all duration-200 flex items-center gap-1 ml-auto cursor-pointer">
                                    <span>เอาออก</span> 🗑️
                                </button>
                            </td>
                        </tr>
                    `;
          });
          container.innerHTML = html;
        }
      } catch (e) {
        console.error("Monitor error", e);
      }
    }

    var currentLobbyModeSetting = 'game';

    async function toggleLobbyGameMode() {
      const newMode = currentLobbyModeSetting === 'game' ? 'simple' : 'game';
      const formData = new FormData();
      const settings = { 'Lobby Mode': newMode };
      formData.append('settings', JSON.stringify(settings));

      try {
        const response = await fetch('/api/teacher/settings', { method: 'POST', body: formData });
        const res = await response.json();
        if (res.success) {
          currentLobbyModeSetting = newMode;
          updateLobbyModeButton();
          Swal.fire({
            icon: 'success',
            title: 'สลับโหมดห้องพักคอยแล้ว',
            text: newMode === 'game' ? 'เปลี่ยนเป็นโหมดเกมยิงอุกกาบาต' : 'เปลี่ยนเป็นโหมดรายชื่อธรรมดา',
            timer: 1500,
            showConfirmButton: false
          });
        }
      } catch (e) {
        console.error(e);
      }
    }

    function updateLobbyModeButton() {
      const btn = document.getElementById('btn-toggle-lobby-mode');
      if (!btn) return;
      if (currentLobbyModeSetting === 'game') {
        btn.className = "w-full py-4 px-6 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-650 hover:to-rose-650 active:scale-[0.98] text-white font-black rounded-2xl text-sm transition-all shadow-lg shadow-pink-500/30 flex items-center justify-center gap-2 hover:scale-[1.02] cursor-pointer";
        btn.innerHTML = "🎮 โหมดพักคอย: เกมยิงอุกกาบาต";
      } else {
        btn.className = "w-full py-4 px-6 bg-gradient-to-r from-sky-500 to-blue-500 hover:from-sky-600 hover:to-blue-650 active:scale-[0.98] text-white font-black rounded-2xl text-sm transition-all shadow-lg shadow-sky-500/30 flex items-center justify-center gap-2 hover:scale-[1.02] cursor-pointer";
        btn.innerHTML = "📄 โหมดพักคอย: รายชื่อธรรมดา";
      }
    }

    async function changeJoinPolicy(policy) {
      const formData = new FormData();
      formData.append('id', activeExamId);
      formData.append('join_policy', policy);

      try {
        const response = await fetch('/api/teacher/exams/update-policy', {
          method: 'POST',
          body: formData
        });
        const res = await response.json();
        if (res.success) {
          updateJoinPolicyUI(policy);
          Swal.fire({
            icon: 'success',
            title: 'เปลี่ยนนโยบายการเข้าสอบสำเร็จ',
            text: policy === 'anytime' ? 'นักเรียนสามารถกดเข้าสอบได้โดยตรงตลอดเวลา' : 'นักเรียนต้องสแตนด์บายในห้องพักคอยก่อนสอบเท่านั้น',
            timer: 2000,
            showConfirmButton: false
          });
        } else {
          Swal.fire('ล้มเหลว', res.message || 'บันทึกไม่สำเร็จ', 'error');
        }
      } catch (e) {
        console.error(e);
        Swal.fire('ล้มเหลว', 'การเชื่อมต่อผิดพลาด', 'error');
      }
    }

    function updateJoinPolicyUI(policy) {
      const btnAnytime = document.getElementById('btn-policy-anytime');
      const btnLobby = document.getElementById('btn-policy-lobby');
      if (!btnAnytime || !btnLobby) return;

      if (policy === 'lobby_first') {
        btnLobby.className = "w-full py-3.5 px-5 bg-gradient-to-r from-pink-500 to-rose-500 text-white font-bold rounded-2xl text-xs transition-all text-left flex flex-col gap-1 cursor-pointer border border-pink-500/20 shadow-lg shadow-pink-500/10 scale-[1.01]";
        btnAnytime.className = "w-full py-3.5 px-5 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-350 font-bold rounded-2xl text-xs transition-all text-left flex flex-col gap-1 cursor-pointer opacity-50 hover:opacity-90";
      } else {
        btnAnytime.className = "w-full py-3.5 px-5 bg-gradient-to-r from-sky-500 to-blue-500 text-white font-bold rounded-2xl text-xs transition-all text-left flex flex-col gap-1 cursor-pointer border border-sky-500/20 shadow-lg shadow-sky-500/10 scale-[1.01]";
        btnLobby.className = "w-full py-3.5 px-5 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-350 font-bold rounded-2xl text-xs transition-all text-left flex flex-col gap-1 cursor-pointer opacity-50 hover:opacity-90";
      }
    }

    async function deleteStudent(email) {
      Swal.fire({
        title: 'เอาผู้เรียนออกจากคิว?',
        text: 'การกระทำนี้จะลบผู้ใช้ออกจากห้องสอบรายวิชานี้ชั่วคราว',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        confirmButtonText: 'เอาออก',
        cancelButtonText: 'ยกเลิก'
      }).then(async (result) => {
        if (result.isConfirmed) {
          const formData = new FormData();
          formData.append('email', email);
          formData.append('exam_id', activeExamId);
          try {
            const response = await fetch('/api/teacher/monitor/delete', { method: 'POST', body: formData });
            const res = await response.json();
            if (res.success) {
              Swal.fire('สำเร็จ', 'นำนักเรียนออกจากห้องพักคอยแล้ว', 'success');
              loadMonitor();
            }
          } catch (e) {
            Swal.fire('ล้มเหลว', 'เกิดข้อผิดพลาด', 'error');
          }
        }
      });
    }

    async function changeExamStatusDirect(status) {
      let statusText = 'เริ่มการสอบ';
      let statusDesc = 'นักเรียนในคิวทุกคนจะเริ่มการนับถอยหลังและเข้าทำข้อสอบทันที!';
      let confirmBtn = 'เริ่มสอบเลย 🚀';

      if (status === 'Finished') {
        statusText = 'ปิดระบบสอบ';
        statusDesc = 'นักเรียนจะไม่สามารถกดส่งคำตอบเพิ่มหรือเข้าระบบสอบได้อีก!';
        confirmBtn = 'ปิดการสอบ 🛑';
      } else if (status === 'Waiting') {
        statusText = 'เปิดห้องพักคอย/รีเซ็ต';
        statusDesc = 'ระบบจะล้างรายชื่อนักเรียนที่กำลังรออยู่ในล็อบบี้ทั้งหมดเพื่อให้เข้ามาใหม่!';
        confirmBtn = 'ยืนยัน ⏳';
      }

      Swal.fire({
        title: `ยืนยันต้องการ "${statusText}"?`,
        text: statusDesc,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: status === 'Finished' ? '#ef4444' : '#10b981',
        confirmButtonText: confirmBtn,
        cancelButtonText: 'ยกเลิก'
      }).then(async (result) => {
        if (result.isConfirmed) {
          const formData = new FormData();
          formData.append('id', activeExamId);
          formData.append('status', status);

          Swal.fire({ title: 'กำลังปรับปรุงสถานะ...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });

          try {
            const response = await fetch('/api/teacher/exams/update-status', {
              method: 'POST',
              body: formData
            });
            const res = await response.json();
            Swal.close();
            if (res.success) {
              Swal.fire('สำเร็จ', `อัปเดตสถานะเป็น "${statusText}" เรียบร้อยแล้ว`, 'success');
              loadMonitor();
            } else {
              Swal.fire('ล้มเหลว', res.message || 'เกิดข้อผิดพลาด', 'error');
            }
          } catch (e) {
            Swal.close();
            Swal.fire('ล้มเหลว', 'เกิดข้อผิดพลาดในการเชื่อมต่อ', 'error');
          }
        }
      });
    }

    // --- Tab 6: Results List & AI Grading ---
    var resultsData = [];
    // --- Tab 6: Results List & AI Grading ---
    var resultsData = [];
    async function loadResults() {
      const exam = globalExamsList.find(e => e.id === activeExamId);
      if (exam) {
        const h2 = document.querySelector('#section-results h2');
        if (h2) {
          h2.innerHTML = `📊 ผลการสอบและตรวจคำตอบอัตนัย <span class="text-xs font-normal text-slate-400 block sm:inline sm:ml-2">ปีการศึกษา ${exam.academic_year || '-'} ภาคเรียนที่ ${exam.semester || '-'}</span>`;
        }
      }
      try {
        const response = await fetch(`/api/teacher/results?exam_id=${activeExamId}`);
        const res = await response.json();

        if (res.success && res.results) {
          resultsData = res.results;
          updateRoundFilterOptions(res.results);
          renderResultsTable();
        }
      } catch (e) {
        console.error(e);
      }
    }

    function updateRoundFilterOptions(results) {
      const filterSelect = document.getElementById('results-filter-round');
      if (!filterSelect) return;
      const currentVal = filterSelect.value;

      // Find unique rounds
      const rounds = ['ALL'];
      results.forEach(r => {
        const rnd = r.exam_round || '1';
        if (!rounds.includes(rnd)) {
          rounds.push(rnd);
        }
      });

      // Clear and rebuild options
      filterSelect.innerHTML = '';
      rounds.forEach(rnd => {
        const opt = document.createElement('option');
        opt.value = rnd;
        opt.textContent = rnd === 'ALL' ? 'แสดงทุกรอบ' : `รอบที่ ${rnd}`;
        filterSelect.appendChild(opt);
      });

      // Restore value if still exists
      if (rounds.includes(currentVal)) {
        filterSelect.value = currentVal;
      } else {
        filterSelect.value = 'ALL';
      }
    }

    function renderResultsTable() {
      const filterSelect = document.getElementById('results-filter-round');
      const selectedRound = filterSelect ? filterSelect.value : 'ALL';
      const container = document.getElementById('results-list');
      if (!container) return;

      const filtered = resultsData.filter(r => {
        if (selectedRound === 'ALL') return true;
        return (r.exam_round || '1') === selectedRound;
      });

      if (filtered.length === 0) {
        container.innerHTML = `<tr><td colspan="7" class="py-8 text-center text-slate-500">ไม่มีผู้สอบส่งคำตอบในรอบที่เลือก</td></tr>`;
        return;
      }

      let html = '';
      filtered.forEach(r => {
        const answers = JSON.parse(r.answers_json || '[]');
        let needsGrading = false;
        answers.forEach(a => {
          if (a.type === 'writing' && a.isCorrect === 'รอตรวจ') {
            needsGrading = true;
          }
        });

        const gradingBadge = needsGrading ?
          '<span class="px-2 py-0.5 text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded font-bold ml-2">รอตรวจ</span>' :
          '<span class="px-2 py-0.5 text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded font-bold ml-2">ครบแล้ว</span>';

        let cheatingStatus = '<span class="text-emerald-400 font-bold">ปกติ</span>';
        if (parseInt(r.cheating_count) >= 3 || r.cheating_flag === 'YES') {
          cheatingStatus = '<span class="text-red-400 font-black">สุ่มเสี่ยง / ระงับ</span>';
        }

        html += `
                <tr class="hover:bg-white/5 transition-colors">
                    <td class="py-4 px-4 font-bold text-white">
                        ${r.name || ''}
                        <span class="block text-[10px] text-pink-400 font-extrabold font-mono mt-0.5">ID: ${r.student_code || '-'}</span>
                        <span class="block text-xs text-slate-500 font-mono">${r.email || ''}</span>
                    </td>
                    <td class="py-4 px-4 text-xs font-bold text-slate-350">
                        ม.${r.room || ''} เลขที่ ${r.student_number || ''}
                    </td>
                    <td class="py-4 px-4 font-bold text-pink-400">
                        ${r.score} คะแนน ${gradingBadge}
                    </td>
                    <td class="py-4 px-4 text-sky-400 font-bold">${r.exam_round || '1'}</td>
                    <td class="py-4 px-4 text-slate-400 font-bold">${r.total_time_spent} วินาที</td>
                    <td class="py-4 px-4 text-xs font-bold">
                        ${cheatingStatus} (${r.cheating_count} ครั้ง)
                    </td>
                    <td class="py-4 px-4 text-right space-x-1.5">
                        <button onclick="editScoreDirect('${r.id}', '${r.name}', ${r.score})" class="px-3 py-1 bg-sky-500/10 hover:bg-sky-500/20 text-sky-400 rounded-lg text-xs font-bold border border-sky-400/25 transition-all">
                            แก้ไขคะแนน ✏️
                        </button>
                        <button onclick="openGradingModal('${r.id}')" class="px-3 py-1 bg-pink-500/10 hover:bg-pink-500/20 text-pink-400 rounded-lg text-xs font-bold border border-pink-500/25 transition-all">
                            ตรวจอัตนัย ✍️
                        </button>
                        <button onclick="deleteResult('${r.id}')" class="px-3 py-1 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg text-xs font-bold border border-red-500/25 transition-all">
                            ลบ 🗑️
                        </button>
                    </td>
                </tr>
            `;
      });
      container.innerHTML = html;
    }

    function filterResultsByRound(val) {
      renderResultsTable();
    }

    function printExamResults() {
      const exam = globalExamsList.find(e => e.id === activeExamId);
      if (!exam) {
        Swal.fire('ข้อผิดพลาด', 'ไม่พบรายละเอียดวิชาสอบ', 'error');
        return;
      }

      const filterSelect = document.getElementById('results-filter-round');
      const selectedRound = filterSelect ? filterSelect.value : 'ALL';

      const filtered = resultsData.filter(r => {
        if (selectedRound === 'ALL') return true;
        return (r.exam_round || '1') === selectedRound;
      });

      if (filtered.length === 0) {
        Swal.fire('ข้อผิดพลาด', 'ไม่มีข้อมูลผลการสอบที่จะพิมพ์สำหรับรอบนี้', 'warning');
        return;
      }

      const printWindow = window.open('', '_blank');
      
      let htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>ประกาศผลคะแนนสอบ - ${exam.subject_code} ${exam.subject_name}</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Sarabun:wght@400;600;700;800&display=swap');
          body {
            font-family: 'Sarabun', sans-serif;
            background: #fff;
            color: #000;
            margin: 2cm;
            line-height: 1.6;
          }
          .header {
            text-align: center;
            margin-bottom: 25px;
          }
          .header h1 {
            font-size: 20px;
            font-weight: 800;
            margin: 0 0 5px 0;
          }
          .header h2 {
            font-size: 16px;
            font-weight: 700;
            margin: 0 0 5px 0;
          }
          .header p {
            font-size: 13px;
            margin: 0;
          }
          .meta-table {
            width: 100%;
            margin-bottom: 20px;
            font-size: 14px;
            border-collapse: collapse;
          }
          .meta-table td {
            padding: 4px 0;
          }
          .results-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
            margin-bottom: 30px;
          }
          .results-table th, .results-table td {
            border: 1px solid #000;
            padding: 8px 10px;
            text-align: center;
          }
          .results-table th {
            background-color: #f2f2f2;
            font-weight: 700;
          }
          .results-table td.name {
            text-align: left;
          }
          .passed {
            font-weight: 600;
            color: #10b981;
          }
          .failed {
            color: #ef4444;
          }
          .footer {
            margin-top: 50px;
            float: right;
            width: 300px;
            text-align: center;
            font-size: 14px;
          }
          @media print {
            body {
              margin: 1cm;
            }
            .no-print {
              display: none;
            }
            .passed {
              color: #000 !important;
              font-weight: 800;
            }
            .failed {
              color: #000 !important;
            }
          }
        </style>
      </head>
      <body>
        <div class="no-print" style="margin-bottom: 20px; text-align: right;">
          <button onclick="window.print();" style="padding: 10px 20px; background-color: #0284c7; color: white; border: none; font-weight: bold; border-radius: 8px; cursor: pointer; font-family: inherit; font-size: 14px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);">🖨️ สั่งพิมพ์ใบประกาศผลสอบ (Print)</button>
        </div>

        <div class="header">
          <h1>ประกาศผลคะแนนการสอบออนไลน์</h1>
          <h2>รายวิชา ${exam.subject_code} ${exam.subject_name}</h2>
          <p>กลุ่มสาระการเรียนรู้ ${exam.learning_area} | ประเภทการสอบ: ${exam.exam_type}</p>
        </div>

        <table class="meta-table">
          <tr>
            <td style="width: 50%"><strong>ปีการศึกษา:</strong> ${exam.academic_year || '-'} <strong>ภาคเรียนที่:</strong> ${exam.semester || '-'}</td>
            <td style="width: 50%; text-align: right;"><strong>ผู้สอน:</strong> ${exam.teacher_name}</td>
          </tr>
          <tr>
            <td style="width: 50%"><strong>รอบการสอบ:</strong> ${selectedRound === 'ALL' ? 'ทุกรอบการสอบ' : 'รอบที่ ' + selectedRound}</td>
            <td style="width: 50%; text-align: right;"><strong>เกณฑ์ผ่าน:</strong> ${exam.passing_percentage}% (${Math.ceil(exam.num_questions * exam.passing_percentage / 100)} / ${exam.num_questions} คะแนน)</td>
          </tr>
        </table>

        <table class="results-table">
          <thead>
            <tr>
              <th style="width: 8%">ลำดับที่</th>
              <th style="width: 15%">เลขประจำตัว</th>
              <th>ชื่อ - นามสกุล</th>
              <th style="width: 15%">ห้อง / เลขที่</th>
              <th style="width: 10%">รอบสอบ</th>
              <th style="width: 15%">คะแนนที่ได้ (${exam.num_questions} คะแนน)</th>
              <th style="width: 15%">ผลการประเมิน</th>
            </tr>
          </thead>
          <tbody>
      `;

      filtered.forEach((r, index) => {
        const fullScore = parseInt(exam.num_questions);
        const passScore = Math.ceil(fullScore * parseInt(exam.passing_percentage) / 100);
        const studentScore = parseFloat(r.score);
        const isPassed = studentScore >= passScore;
        const evaluation = isPassed ? '<span class="passed">ผ่าน (Pass)</span>' : '<span class="failed">ไม่ผ่าน (Fail)</span>';

        htmlContent += `
            <tr>
              <td>${index + 1}</td>
              <td>${r.student_code || '-'}</td>
              <td class="name">${r.name}</td>
              <td>ม.${r.room || ''} / เลขที่ ${r.student_number || ''}</td>
              <td>รอบที่ ${r.exam_round || '1'}</td>
              <td><strong>${r.score}</strong></td>
              <td>${evaluation}</td>
            </tr>
        `;
      });

      htmlContent += `
          </tbody>
        </table>

        <div class="footer">
          <p>ลงชื่อ..........................................................ผู้สอน</p>
          <p style="margin-top: 10px;">( ${exam.teacher_name} )</p>
          <p style="margin-top: 5px;">วันที่พิมพ์ประกาศ: ${new Date().toLocaleDateString('th-TH')}</p>
        </div>
      </body>
      </html>
      `;

      printWindow.document.write(htmlContent);
      printWindow.document.close();
    }

    function deleteResult(id) {
      Swal.fire({
        title: 'ต้องการลบผลการสอบนี้?',
        text: 'การลบผลการสอบจะล้างสิทธิ์ครั้งนั้นทำให้นักเรียนสอบใหม่ได้',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        confirmButtonText: 'ลบผลสอบ',
        cancelButtonText: 'ยกเลิก'
      }).then(async (result) => {
        if (result.isConfirmed) {
          const formData = new FormData();
          formData.append('id', id);
          try {
            const response = await fetch('/api/teacher/results/delete', { method: 'POST', body: formData });
            const res = await response.json();
            if (res.success) {
              Swal.fire('สำเร็จ', 'ลบผลการสอบเรียบร้อยแล้ว', 'success');
              loadResults();
            }
          } catch (e) {
            Swal.fire('ล้มเหลว', 'ล้มเหลว', 'error');
          }
        }
      });
    }

    async function loadLogs() {
      try {
        const response = await fetch('/api/teacher/logs');
        const res = await response.json();
        const container = document.getElementById('logs-list');
        if (res.success && res.logs) {
          if (res.logs.length === 0) {
            container.innerHTML = `<tr><td colspan="4" class="py-8 text-center text-slate-500">ไม่มีประวัติความเสี่ยงในระบบขณะนี้</td></tr>`;
            return;
          }

          let html = '';
          res.logs.forEach(l => {
            html += `
                        <tr class="hover:bg-white/5 transition-colors">
                            <td class="py-3 px-4 text-xs font-mono text-slate-405">${l.timestamp}</td>
                            <td class="py-3 px-4 font-bold text-white">${l.student_email}</td>
                            <td class="py-3 px-4 text-xs text-red-400 font-bold">${l.error_message}</td>
                            <td class="py-3 px-4 text-[10px] text-slate-500 font-mono">${l.screen_resolution || 'ไม่ทราบ'}</td>
                        </tr>
                    `;
          });
          container.innerHTML = html;
        }
      } catch (e) {
        console.error(e);
      }
    }

    async function clearLogs() {
      Swal.fire({
        title: 'ต้องการล้างบันทึกความเสี่ยงทั้งหมด?',
        text: 'ข้อมูลประวัติความเสี่ยงและพฤติกรรมน่าสงสัยทั้งหมดจะถูกลบถาวร!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        confirmButtonText: 'ล้างข้อมูลทั้งหมด',
        cancelButtonText: 'ยกเลิก'
      }).then(async (result) => {
        if (result.isConfirmed) {
          Swal.fire({ title: 'กำลังล้างบันทึกความเสี่ยง...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
          try {
            const response = await fetch('/api/teacher/logs/clear', { method: 'POST' });
            const res = await response.json();
            Swal.close();
            if (res.success) {
              Swal.fire('สำเร็จ', 'ล้างบันทึกความเสี่ยงเรียบร้อยแล้ว', 'success');
              loadLogs();
            } else {
              Swal.fire('ล้มเหลว', res.message || 'เกิดข้อผิดพลาด', 'error');
            }
          } catch (e) {
            Swal.close();
            Swal.fire('ล้มเหลว', 'เกิดข้อผิดพลาดในการเชื่อมต่อ', 'error');
          }
        }
      });
    }

    // --- Tab 4: Import Questions ---
    function openImportModal() {
      document.getElementById('import-data').value = '';
      document.getElementById('import-clear-existing').checked = false;
      document.getElementById('importModal').classList.remove('hidden');
    }

    function closeImportModal() {
      document.getElementById('importModal').classList.add('hidden');
    }

    async function submitImport() {
      const rawText = document.getElementById('import-data').value;
      const clearExisting = document.getElementById('import-clear-existing').checked;

      if (!rawText.trim()) {
        Swal.fire('คำเตือน', 'กรุณาวางข้อมูลดิบก่อนนำเข้า', 'warning');
        return;
      }

      const rows = rawText.split('\n').map(line => {
        let parts = [];
        if (line.includes('\t')) {
          parts = line.split('\t');
        } else if (line.includes(',')) {
          parts = line.split(',');
        } else {
          parts = [line];
        }
        return parts.map(col => col.trim());
      }).filter(r => r.length > 1 || (r.length === 1 && r[0] !== ''));
      Swal.fire({ title: 'กำลังนำเข้าข้อมูลคำถาม...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });

      const formData = new FormData();
      formData.append('exam_id', activeExamId);
      formData.append('rows', JSON.stringify(rows));
      formData.append('clearExisting', clearExisting);

      try {
        const response = await fetch('/api/teacher/questions/import', {
          method: 'POST',
          body: formData
        });
        const res = await response.json();
        Swal.close();
        if (res.success) {
          Swal.fire('สำเร็จ', `นำเข้าข้อมูลเรียบร้อยแล้ว จำนวน ${res.count} ข้อ`, 'success');
          closeImportModal();
          loadQuestions();
        } else {
          Swal.fire('ล้มเหลว', res.message || 'เกิดข้อผิดพลาด', 'error');
        }
      } catch (err) {
        Swal.close();
        Swal.fire('ล้มเหลว', 'การเชื่อมต่อผิดพลาด', 'error');
      }
    }


    function editScoreDirect(id, studentName, currentScore) {
      Swal.fire({
        title: 'แก้ไขคะแนนสอบรวม',
        text: `ป้อนคะแนนรวมใหม่สำหรับ: ${studentName}`,
        input: 'number',
        inputValue: currentScore,
        inputAttributes: {
          min: 0,
          step: 0.5
        },
        showCancelButton: true,
        confirmButtonText: 'บันทึก 💾',
        cancelButtonText: 'ยกเลิก',
        inputValidator: (value) => {
          if (value === '' || isNaN(value) || parseFloat(value) < 0) {
            return 'กรุณากรอกคะแนนสอบที่ถูกต้อง!'
          }
        }
      }).then(async (result) => {
        if (result.isConfirmed) {
          const formData = new FormData();
          formData.append('id', id);
          formData.append('score', result.value);

          Swal.fire({ title: 'กำลังบันทึกคะแนน...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });

          try {
            const response = await fetch('/api/teacher/results/update-score-direct', {
              method: 'POST',
              body: formData
            });
            const res = await response.json();
            Swal.close();
            if (res.success) {
              Swal.fire('สำเร็จ', 'อัปเดตคะแนนเรียบร้อยแล้ว', 'success');
              loadResults();
            } else {
              Swal.fire('ล้มเหลว', res.message || 'บันทึกไม่สำเร็จ', 'error');
            }
          } catch (e) {
            Swal.close();
            Swal.fire('ล้มเหลว', 'เกิดข้อผิดพลาดในการเชื่อมต่อ', 'error');
          }
        }
      });
    }

    // --- Tab 6: Grading Modal (Manual & AI Grading) ---
    async function openGradingModal(resultId) {
      currentEditingResultId = resultId;
      const record = resultsData.find(r => r.id === resultId);
      if (!record) return;

      document.getElementById('grade-student-info').textContent = `นักเรียน: ${record.student_name} | ห้อง: ม.${record.student_room} เลขที่ ${record.student_number}`;
      const container = document.getElementById('grading-list');
      container.innerHTML = '<p class="text-slate-400 py-6 text-center">กำลังโหลดข้อมูลข้อสอบเขียน...</p>';

      document.getElementById('gradingModal').classList.remove('hidden');

      const answers = JSON.parse(record.answers_json || '[]');
      const writingAnswers = answers.filter(a => a.type === 'writing');

      if (writingAnswers.length === 0) {
        container.innerHTML = '<p class="text-slate-500 py-6 text-center">รายวิชานี้ไม่มีข้อสอบประเภทอัตนัย (ข้อเขียน)</p>';
        return;
      }

      let html = '';
      writingAnswers.forEach((wa, index) => {
        const currentPoints = wa.isCorrect === 'รอตรวจ' ? 0 : parseFloat(wa.isCorrect || 0);

        html += `
                <div class="p-5 bg-white/5 rounded-2xl border border-white/5 relative" data-q-id="${wa.questionId}" data-max-points="${wa.points}">
                    <div class="flex justify-between items-start mb-2">
                        <span class="px-2 py-0.5 bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[10px] font-bold rounded">
                            คำถามข้อเขียนที่ ${index + 1}
                        </span>
                        <span class="text-xs text-slate-400 font-bold">คะแนนเต็ม ${wa.points} คะแนน</span>
                    </div>
                    <p class="text-white font-bold text-sm mb-4 leading-relaxed">${wa.question || ''}</p>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div class="p-3 bg-red-500/5 border border-red-500/15 rounded-xl">
                            <span class="text-[10px] font-bold text-red-400 block mb-1">คำตอบของนักเรียน:</span>
                            <p class="text-white text-xs font-bold whitespace-pre-wrap">${wa.selected || '(ไม่ได้ตอบ)'}</p>
                        </div>
                        <div class="p-3 bg-emerald-500/5 border border-emerald-500/15 rounded-xl">
                            <span class="text-[10px] font-bold text-emerald-400 block mb-1">เฉลยอ้างอิง:</span>
                            <p class="text-white text-xs font-bold whitespace-pre-wrap">${wa.correct || '(ไม่มีคำเฉลยอ้างอิง)'}</p>
                        </div>
                    </div>

                    <div class="flex items-center gap-3">
                        <label class="text-xs font-bold text-slate-400">ให้คะแนนที่ทำได้:</label>
                        <input type="number" step="0.5" max="${wa.points}" value="${currentPoints}" class="w-24 bg-slate-800 border border-white/10 rounded-lg p-2 text-white font-bold text-center outline-none focus:border-pink-500" data-score-input>
                        <span class="text-slate-500 text-xs">/ ${wa.points} คะแนน</span>
                        
                        <button type="button" onclick="autoGradeWithGemini(this, '${wa.questionId}')" class="ml-auto px-3.5 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:scale-102 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md shadow-purple-950/40">
                            ✨ ใช้ AI (Gemini) ช่วยตรวจ
                        </button>
                    </div>
                </div>
            `;
      });
      container.innerHTML = html;
    }

    function closeGradingModal() {
      document.getElementById('gradingModal').classList.add('hidden');
    }

    async function autoGradeWithGemini(btn, questionId) {
      const parent = btn.closest('[data-q-id]');
      const studentAnswer = parent.querySelector('.bg-red-500\\/5 p').textContent;
      const correctAnswer = parent.querySelector('.bg-emerald-500\\/5 p').textContent;
      const questionText = parent.querySelector('p.text-white').textContent;
      const maxPoints = parseFloat(parent.getAttribute('data-max-points'));
      const scoreInput = parent.querySelector('[data-score-input]');

      btn.disabled = true;
      const originalText = btn.innerHTML;
      btn.innerHTML = '⚡ กำลังตรวจด้วย AI...';

      try {
        const formData = new FormData();
        formData.append('question', questionText);
        formData.append('studentAnswer', studentAnswer);
        formData.append('correctAnswer', correctAnswer);
        formData.append('maxPoints', maxPoints);

        const response = await fetch('/api/exam/ai-grade', {
          method: 'POST',
          body: formData
        });

        const data = await response.json();
        btn.disabled = false;
        btn.innerHTML = originalText;

        if (data.success) {
          scoreInput.value = data.score;
          Swal.fire({
            icon: 'success',
            title: 'AI ตรวจเสร็จสิ้น',
            text: `เหตุผลวิเคราะห์: ${data.explanation || 'ให้คะแนนสำเร็จ'}`,
            confirmButtonColor: '#ec4899'
          });
        } else {
          Swal.fire('ล้มเหลว', data.message || 'AI ไม่สามารถตอบคำถามได้', 'error');
        }
      } catch (err) {
        btn.disabled = false;
        btn.innerHTML = originalText;
        Swal.fire('ล้มเหลว', 'เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์', 'error');
      }
    }

    async function submitGrading() {
      const container = document.getElementById('grading-list');
      const items = container.querySelectorAll('[data-q-id]');
      const record = resultsData.find(r => r.id === currentEditingResultId);
      if (!record) return;

      const answers = JSON.parse(record.answers_json || '[]');
      const writingScores = {};
      let totalNewScore = 0;

      answers.forEach(a => {
        if (a.type === 'choice') {
          if (a.isCorrect === 'ถูกต้อง') {
            totalNewScore += parseFloat(a.points || 1);
          }
        }
      });

      items.forEach(item => {
        const qId = item.getAttribute('data-q-id');
        const scoreVal = parseFloat(item.querySelector('[data-score-input]').value || 0);
        writingScores[qId] = scoreVal;
        totalNewScore += scoreVal;
      });

      Swal.fire({ title: 'กำลังบันทึกผลคะแนน...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });

      const formData = new FormData();
      formData.append('id', currentEditingResultId);
      formData.append('totalScore', totalNewScore);
      formData.append('writingScores', JSON.stringify(writingScores));

      try {
        const response = await fetch('/api/teacher/results/update-score', {
          method: 'POST',
          body: formData
        });
        const res = await response.json();
        Swal.close();
        if (res.success) {
          Swal.fire('สำเร็จ', 'บันทึกคะแนนรวมการตรวจเรียบร้อยแล้ว', 'success');
          closeGradingModal();
          loadResults();
        } else {
          Swal.fire('ล้มเหลว', res.message || 'บันทึกไม่สำเร็จ', 'error');
        }
      } catch (e) {
        Swal.close();
        Swal.fire('ล้มเหลว', 'ข้อผิดพลาดระบบ', 'error');
      }
    }

    // --- Tab 7: Logs ---
    async function loadLogs() {
      try {
        const response = await fetch('/api/teacher/logs');
        const res = await response.json();
        const container = document.getElementById('logs-list');
        if (res.success && res.logs) {
          if (res.logs.length === 0) {
            container.innerHTML = `<tr><td colspan="4" class="py-8 text-center text-slate-500">ไม่มีประวัติความเสี่ยงในระบบขณะนี้</td></tr>`;
            return;
          }

          let html = '';
          res.logs.forEach(l => {
            html += `
                        <tr class="hover:bg-white/5 transition-colors">
                            <td class="py-3 px-4 text-xs font-mono text-slate-400">${l.timestamp}</td>
                            <td class="py-3 px-4 font-bold text-white">${l.student_email}</td>
                            <td class="py-3 px-4 text-xs text-red-400 font-bold">${l.error_message}</td>
                            <td class="py-3 px-4 text-[10px] text-slate-500 font-mono">${l.screen_resolution || 'ไม่ทราบ'}</td>
                        </tr>
                    `;
          });
          container.innerHTML = html;
        }
      } catch (e) {
        console.error(e);
      }
    }
  </script>
</body>

</html>